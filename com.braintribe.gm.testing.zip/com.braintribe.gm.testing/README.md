# !! DEAD !!

This group has been deprecated and is now completely abandoned. All artifacts have been moved to `com.braintribe.gm`.
Please update your dependencies!
