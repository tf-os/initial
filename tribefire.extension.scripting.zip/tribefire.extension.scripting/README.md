# Scripting extension

With this extension you can incorporate scipting into your tribefire workflow. The extension is made with the maximum flexibility, however, by default only Groovy (4.0.1) is
provided by default. It is very straightforward to deploy other script languages. 

Just include `scripting-extension-aggregator` and try it out. 

Scripting is included in service processing. Choose one of the `ScriptedService*Processors` for your task. 