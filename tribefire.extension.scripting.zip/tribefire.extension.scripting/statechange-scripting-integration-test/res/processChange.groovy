person = $context.entity;
$context.entity.setState("Property \"" + $context.getAffectedProperty().getName() + "\" was changed to \"" + person.role.toUpperCase() + "\""); 
