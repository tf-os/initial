return paramd.toLowerCase();
