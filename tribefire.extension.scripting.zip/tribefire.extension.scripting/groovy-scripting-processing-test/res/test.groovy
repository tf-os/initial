return param.toLowerCase();
