// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.scripting.imp;

import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.util.UUID;

import com.braintribe.model.deployment.Deployable;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.processing.session.api.persistence.PersistenceGmSession;
import com.braintribe.model.resource.Resource;
import com.braintribe.product.rat.imp.impl.deployable.BasicDeployableImp;
import com.braintribe.utils.IOTools;

import tribefire.extension.scripting.model.deployment.HasScript;
import tribefire.extension.scripting.model.deployment.Script;

public class ScriptedProcessorImp<T extends HasScript & Deployable> extends BasicDeployableImp<T> {

	public ScriptedProcessorImp(PersistenceGmSession session, T instance) {
		super(session, instance);
	}

	public ScriptedProcessorImp<T> addScript(EntityType<? extends Script> entityType, String script) {
		logger.info("Creating Script of type [" + entityType.getShortName() + "] \nScript: '" + script + "'");

		Script scriptEntity = session().create(entityType);
		
		Resource r = session().resources().create().name(entityType.getShortName() + "-script-" + UUID.randomUUID().toString()).store(o -> {
			OutputStreamWriter writer = new OutputStreamWriter(o, "UTF-8");
			try(Reader reader = new StringReader(script)) {
				IOTools.pump(reader, writer);
			}
		});
		
		scriptEntity.setSource(r);

		instance.setScript(scriptEntity);

		return this;
	}
}
