## LDAP Cartridge
Using the LDAP cartridge allows you to, for example, connect to an Active Directory server for authentication and user and group maintenance purposes.

<!--For information about using the LDAP cartridge, see [LDAP cartridge tutorials](back_end.html#ldap-cartridge)-->
