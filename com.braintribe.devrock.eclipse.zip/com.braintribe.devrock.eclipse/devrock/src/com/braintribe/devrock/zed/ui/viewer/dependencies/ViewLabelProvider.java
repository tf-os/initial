// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.devrock.zed.ui.viewer.dependencies;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.eclipse.jface.viewers.CellLabelProvider;
import org.eclipse.jface.viewers.DelegatingStyledCellLabelProvider.IStyledLabelProvider;
import org.eclipse.jface.viewers.StyledString;
import org.eclipse.jface.viewers.StyledString.Styler;
import org.eclipse.jface.viewers.ViewerCell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;

import com.braintribe.cfg.Configurable;
import com.braintribe.common.lcd.Pair;
import com.braintribe.devrock.api.ui.commons.UiSupport;
import com.braintribe.devrock.api.ui.fonts.StyledTextHandler;
import com.braintribe.devrock.api.ui.fonts.StyledTextSequenceData;
import com.braintribe.devrock.api.ui.stylers.Stylers;
import com.braintribe.devrock.zarathud.model.common.ReferenceNode;
import com.braintribe.devrock.zarathud.model.dependency.DependencyAnalysisNode;
import com.braintribe.devrock.zarathud.model.dependency.DependencyKind;
import com.braintribe.utils.lcd.LazyInitialized;

public class ViewLabelProvider extends CellLabelProvider implements IStyledLabelProvider {
	private static final String STYLER_EMPHASIS = "emphasis";
	private static final String STYLER_STANDARD = "standard";
	private static final String STYLER_FORWARD = "forward";
	private static final String STYLER_EXCESS = "excess";
	private static final String STYLER_CONFIRMED = "confirmed";
	private static final String STYLER_MISSING = "missing";
	private static final String REFERENCE_DELIMITER = " \u21E2 ";
	
	private UiSupport uiSupport;
	private String uiSupportStylersKey;
	
	private LazyInitialized<Map<String, Styler>> stylerMap = new LazyInitialized<>( this::setupUiSupport);
	private Image confirmedImage;
	private Image missingImage;
	private Image excessImage;
	private Image forwardImage;
	
	private StyledTextHandler styledStringStyler;
	{
		styledStringStyler = new StyledTextHandler();
		styledStringStyler.setStylerMapSupplier(stylerMap);
		styledStringStyler.setDelimiterStyleSupplier( () -> Stylers.KEY_DEFAULT);
	}
	
	@Configurable
	public void setUiSupport(UiSupport uiSupport) {
		this.uiSupport = uiSupport;					
	}
	
	@Configurable
	public void setUiSupportStylersKey(String uiSupportStylersKey) {
		this.uiSupportStylersKey = uiSupportStylersKey;
	}
		
	private Map<String,Styler> setupUiSupport() {		
		
		confirmedImage = uiSupport.images().addImage(STYLER_CONFIRMED, ViewLabelProvider.class, "passed.png");
		missingImage = uiSupport.images().addImage(STYLER_MISSING, ViewLabelProvider.class, "add.gif");
		excessImage = uiSupport.images().addImage(STYLER_EXCESS, ViewLabelProvider.class, "remove.gif");
		forwardImage = uiSupport.images().addImage(STYLER_FORWARD, ViewLabelProvider.class, "filter_obj.gif");
		
		
		Stylers stylers = uiSupport.stylers(uiSupportStylersKey);
		stylers.addStandardStylers();
		Map<String,Styler> map = new HashMap<>();
		map.put(STYLER_MISSING, stylers.standardStyler(Stylers.KEY_BOLD));
		map.put(STYLER_CONFIRMED, stylers.standardStyler(Stylers.KEY_DEFAULT));
		map.put(STYLER_EXCESS, stylers.addStyler(STYLER_EXCESS, null, SWT.COLOR_DARK_GRAY, null, null));
		map.put(STYLER_FORWARD, stylers.addStyler(STYLER_FORWARD, null, SWT.COLOR_GRAY, null, null));
		map.put(STYLER_STANDARD, stylers.standardStyler(Stylers.KEY_DEFAULT));
		map.put(STYLER_EMPHASIS, stylers.standardStyler(Stylers.KEY_BOLD));
		return map;
	}

	@Override
	public Image getImage(Object obj) {
		if (obj instanceof DependencyAnalysisNode) { 
			DependencyAnalysisNode node = (DependencyAnalysisNode) obj;
			switch (node.getKind()) {
				case confirmed:
					return confirmedImage;				
				case excess:
					return excessImage;				
				case missing:
					return missingImage;
				case forward:
					return forwardImage;
				default:
					break;			
			}
		}
		return null;
	}
	
	

	@Override
	public String getToolTipText(Object element) {
		if (element instanceof DependencyAnalysisNode) {
			DependencyAnalysisNode node = (DependencyAnalysisNode) element;
			String text = node.getIdentification().asString();
			String suffix = null;
			String referenceCount = null;
			switch (node.getKind()) {
				case confirmed:
					suffix = STYLER_CONFIRMED;
					break;
				case excess:
					suffix = STYLER_EXCESS;
					break;
				case missing:
					suffix = STYLER_MISSING;
					referenceCount = "" + node.getReferences().size();
					break;
				case forward:
					if (node.getIncompleteForwardReference()) {
						suffix = "forwarded (missing)";
					}
					else {
						suffix = "forwarded";
					}
				default:
					break;			
			}
			if (suffix != null) {
				if (referenceCount != null) {
					text = text + " (" + suffix + ", number of references : " + referenceCount + ")";
				}
				else {
					text = text + " (" + suffix + ")";
				}
				if (node.getKind() == DependencyKind.missing || (node.getKind() == DependencyKind.forward && node.getIncompleteForwardReference())) {
					return text + "\n use context menu to insert to pom"; 
				}
				return text;
			}
			else {
				return text;
			}
			
		}
		else if (element instanceof ReferenceNode) {
			ReferenceNode node = (ReferenceNode) element;
			String text = node.getSource().getName() + REFERENCE_DELIMITER + node.getTarget().getName();
			int count = node.getCount();
			if (count > 1) {
				text += " (" + count + ")";
			}
			return text;
		}
		return super.getToolTipText(element);
	}

	@Override
	public StyledString getStyledText(Object obj) {
		if (obj instanceof DependencyAnalysisNode) { 
			DependencyAnalysisNode node = (DependencyAnalysisNode) obj;
			String stylerKey = null;
			switch (node.getKind()) {
				case confirmed:
					stylerKey = STYLER_CONFIRMED;
					break;
				case excess:
					stylerKey = STYLER_EXCESS;
					break;
				case missing:
					stylerKey = STYLER_MISSING;
					break;
				case forward:
					if (node.getIncompleteForwardReference()) {
						stylerKey = STYLER_EMPHASIS;
					}
					else {
						stylerKey = STYLER_FORWARD;
					}
					break;
				default:
					break;			
			}	
			String text = node.getIdentification().asString();		
			if (stylerKey != null) {
				
				return new StyledString( text, stylerMap.get().get(stylerKey));
			}
			else {
				return new StyledString( text);
			}
						
		}
		else if (obj instanceof ReferenceNode){
			ReferenceNode node = (ReferenceNode) obj;
			int count = node.getCount();
			
			List<Pair<String, List<StyledTextSequenceData>>> pairs = new ArrayList<>();
			pairs.add(getStyledTextForType(node.getSource().getName()));	
			pairs.add( styledStringStyler.build( REFERENCE_DELIMITER, STYLER_STANDARD));
			pairs.add(getStyledTextForType(node.getTarget().getName()));
		
			if (count > 1) {
				pairs.add( styledStringStyler.build(" (" + count + ")", STYLER_STANDARD));
				
			}			
			Pair<String,List<StyledTextSequenceData>> merged = styledStringStyler.merge(pairs);
			return StyledTextHandler.applyRanges(merged);
		}
		return null;
	}

	@Override
	public void update(ViewerCell arg0) {	
	}
	
	/**
	 * builds the styled text data for a type (in form of a {@link String}
	 * @param type - the fully qualified type as a {@link String}
	 * @return - a {@link Pair} of {@link String} with associated {@link StyledTextSequenceData}
	 */
	private Pair<String, List<StyledTextSequenceData>> getStyledTextForType( String type) {
		String [] split = type.split("\\.");
		List<Pair<String,List<StyledTextSequenceData>>> pairs = new ArrayList<>();
		for (int i = 0; i < split.length - 1; i++) {
			pairs.add( styledStringStyler.build(split[i], STYLER_STANDARD));
		}
		pairs.add( styledStringStyler.build( split[ split.length -1], STYLER_EMPHASIS));
		return styledStringStyler.merge(pairs, ".");
	}

}
