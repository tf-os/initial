// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.devrock.zed.ui.transposer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.braintribe.devrock.zarathud.model.common.ReferenceNode;
import com.braintribe.devrock.zarathud.model.dependency.DependencyAnalysisNode;
import com.braintribe.devrock.zarathud.model.dependency.DependencyKind;
import com.braintribe.devrock.zed.ui.ZedViewingContext;
import com.braintribe.model.artifact.essential.VersionedArtifactIdentification;
import com.braintribe.zarathud.model.data.Artifact;
import com.braintribe.zarathud.model.forensics.ArtifactForensicsResult;
import com.braintribe.zarathud.model.forensics.DependencyForensicsResult;
import com.braintribe.zarathud.model.forensics.data.ArtifactReference;

/**
 * transposes a {@link DependencyForensicsResult} into a list of nodes
 * it contains :
 * a) the correct dependencies, i.e. declared and missing
 * b) the excessive dependencies, i.e. superfluous dependencies
 * c) the forward dependencies, i.e. virtual dependencies  
 *
 */
public class DependencyAnalysisContentTransposer {

	/**
	 * @param context
	 * @param forensics
	 * @return
	 */
	public static List<DependencyAnalysisNode> transpose(ZedViewingContext context, DependencyForensicsResult forensics) {
		List<DependencyAnalysisNode> result = new ArrayList<>();		
		List<String> missingDeclarationNames = forensics.getMissingDeclarations().stream().map( a -> a.toVersionedStringRepresentation()).collect(Collectors.toList());
		List<String> forwaredDeclarationNames = forensics.getForwardedReferences().values().stream().map( a -> a.toVersionedStringRepresentation()).collect(Collectors.toList());
		Map<String,ArtifactForensicsResult> referenceMap = new HashMap<>();
		forensics.getMissingArtifactDetails().forEach( afr -> referenceMap.put( afr.getArtifact().toVersionedStringRepresentation(), afr));
				
		// add required dependencies / means : declared and missing
		List<Artifact> requiredDeclarations = forensics.getRequiredDeclarations();
		for (Artifact artifact : requiredDeclarations) {
			// a) drop runtime
			if (artifact.getArtifactId().equals("rt")) { 
				continue;
			}
			DependencyAnalysisNode transposedArtifact;
			if (missingDeclarationNames.contains( artifact.toVersionedStringRepresentation())) {
				transposedArtifact = transpose(artifact, DependencyKind.missing);							
				enhance(transposedArtifact, referenceMap);
			}
			else {				
				if (forwaredDeclarationNames.contains( artifact.toVersionedStringRepresentation())) {
					continue;
				}
				transposedArtifact = transpose(artifact, DependencyKind.confirmed);								 
			}
			result.add(transposedArtifact);
		}
		
		// add excessive dependencies
		List<Artifact> excessDeclarations = forensics.getExcessDeclarations();
		for (Artifact artifact : excessDeclarations) {
			DependencyAnalysisNode transposedArtifact = transpose(artifact, DependencyKind.excess);			
			result.add(transposedArtifact);
		}
		// add forward dependencies
 		Map<ArtifactReference, Artifact> forwaredDeclarations = forensics.getForwardedReferences();
		Map<String, DependencyAnalysisNode> namedArtifact = new HashMap<>();
		Map<String,ReferenceNode> namedReference = new HashMap<>();
		for (Map.Entry<ArtifactReference, Artifact> entry : forwaredDeclarations.entrySet()) {
			Artifact artifact = entry.getValue();						
			String artifactKey = artifact.toVersionedStringRepresentation();
			DependencyAnalysisNode node = namedArtifact.get(artifactKey);
			if (node == null) {
				node = transpose(artifact, DependencyKind.forward);
				namedArtifact.put( artifactKey, node);
				result.add( node);
			}													
			ArtifactReference reference = entry.getKey();
			String referenceKey = reference.getSource().getName() + ":" + reference.getTarget().getName();
			ReferenceNode referenceNode = namedReference.get(referenceKey);
			if (referenceNode == null) {
				referenceNode = CommonContentTransposer.transpose(reference);
				node.getReferences().add(referenceNode);
				namedReference.put(referenceKey, referenceNode);
			}
			else {
				referenceNode.setCount( referenceNode.getCount() + 1);
			}
		}	
		
		result.sort( new Comparator<DependencyAnalysisNode>() {
			@Override
			public int compare(DependencyAnalysisNode o1, DependencyAnalysisNode o2) {				
				return o1.getIdentification().compareTo(o2.getIdentification());
			}			
		});
		
		return result;		
	}
		
	
	/**
	 * @param artifact
	 * @param kind
	 * @return
	 */
	private static DependencyAnalysisNode transpose( Artifact artifact, DependencyKind kind) {
		DependencyAnalysisNode node = DependencyAnalysisNode.T.create();		
		node.setIdentification( VersionedArtifactIdentification.create( artifact.getGroupId(), artifact.getArtifactId(), artifact.getVersion()));
		node.setKind(kind);
		if (kind == DependencyKind.forward && artifact.getIsIncomplete()) {
			node.setIncompleteForwardReference( true);
		}
		return node;		
	}
	
	/**
	 * @param node
	 * @param referenceData
	 * @return
	 */
	private static DependencyAnalysisNode enhance(DependencyAnalysisNode node, Map<String,ArtifactForensicsResult> referenceData) {
		
		String key = node.getIdentification().asString();
		ArtifactForensicsResult afr = referenceData.get(key);
		if (afr == null) {		
			return node;
		}
		

		Map<String,ReferenceNode> namedReference = new HashMap<>();
		List<ArtifactReference> references = afr.getReferences();
		for (ArtifactReference reference : references) {			
			String referenceKey = reference.getSource().getName() + ":" + reference.getTarget().getName();
			ReferenceNode referenceNode = namedReference.get(referenceKey);
			if (referenceNode == null) {
				referenceNode = CommonContentTransposer.transpose(reference);
				namedReference.put(referenceKey, referenceNode);
				node.getReferences().add(referenceNode);
			}
			else {
				referenceNode.setCount( referenceNode.getCount() + 1);
			}
		}
			
		return node;
	}
	
}
