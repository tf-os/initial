// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.devrock.zed.ui.transposer;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.braintribe.devrock.zarathud.model.common.EntityNode;
import com.braintribe.devrock.zarathud.model.common.FieldNode;
import com.braintribe.devrock.zarathud.model.common.FingerPrintNode;
import com.braintribe.devrock.zarathud.model.common.MethodNode;
import com.braintribe.devrock.zarathud.model.model.EnumEntityNode;
import com.braintribe.devrock.zarathud.model.model.GenericEntityNode;
import com.braintribe.devrock.zarathud.model.model.ModelAnalysisNode;
import com.braintribe.devrock.zarathud.model.model.PropertyNode;
import com.braintribe.devrock.zed.forensics.fingerprint.HasFingerPrintTokens;
import com.braintribe.devrock.zed.ui.ZedViewingContext;
import com.braintribe.model.generic.GenericEntity;
import com.braintribe.zarathud.model.data.FieldEntity;
import com.braintribe.zarathud.model.data.InterfaceEntity;
import com.braintribe.zarathud.model.data.MethodEntity;
import com.braintribe.zarathud.model.data.TypeReferenceEntity;
import com.braintribe.zarathud.model.data.ZedEntity;
import com.braintribe.zarathud.model.data.natures.HasFieldsNature;
import com.braintribe.zarathud.model.data.natures.HasMethodsNature;
import com.braintribe.zarathud.model.forensics.FingerPrint;
import com.braintribe.zarathud.model.forensics.ModelForensicsResult;
import com.braintribe.zarathud.model.forensics.data.ModelEntityReference;
import com.braintribe.zarathud.model.forensics.data.ModelEnumReference;
import com.braintribe.zarathud.model.forensics.data.ModelPropertyReference;

/**
 * transposer for the model analysis tab
 *
 */
public class ModelAnalysisContentTransposer implements HasFingerPrintTokens{
	
	/**
	 * @param context
	 * @param forensics
	 * @return
	 */
	public static ModelAnalysisNode transpose( ZedViewingContext context, ModelForensicsResult forensics) {
		
		ModelAnalysisNode maNode = ModelAnalysisNode.T.create();
		List<ModelEntityReference> modelEntityReferences = forensics.getModelEntityReferences();
		List<ModelEnumReference> modelEnumReferences = forensics.getModelEnumEntities();
		List<GenericEntity> data = new ArrayList<>( modelEntityReferences.size() + modelEnumReferences.size());
		
		data.addAll(modelEntityReferences);
		for (ModelEntityReference mer : modelEntityReferences) {
			data.addAll(mer.getPropertyReferences());
			// add methods et al ..
			data.addAll( mer.getConformOtherMethods());
			data.addAll( mer.getNonConformOtherMethods());
		}
		
		data.addAll(modelEnumReferences);
		
		
		List<FingerPrint> fingerPrintsOfIssues = forensics.getFingerPrintsOfIssues();
		TransposerRegistry tr = new TransposerRegistry(fingerPrintsOfIssues, data);
		
		List<FingerPrintNode> transposedFingerPrints = transpose(context, fingerPrintsOfIssues, tr);
		transposedFingerPrints.sort( new Comparator<FingerPrintNode>() {
			@Override
			public int compare(FingerPrintNode o1, FingerPrintNode o2) {			
				return o1.getMessage().compareTo( o2.getMessage());
			}			
		});
		
		maNode.getChildren().addAll(transposedFingerPrints);
		
		return maNode;
	}
	
	/**
	 * transposes the fingerprints 
	 * @param context - the {@link ZedViewingContext}
	 * @param fingerprints - a {@link List} of {@link FingerPrint}
	 * @param tr - the {@link TransposerRegistry}
	 * @return - a {@link List} of {@link FingerPrintNode}
	 */
	private static List<FingerPrintNode> transpose(ZedViewingContext context, List<FingerPrint> fingerprints, TransposerRegistry tr) {
		List<FingerPrintNode> nodes = new ArrayList<>( fingerprints.size());
		
		for (FingerPrint fp : fingerprints) {
			GenericEntity target = tr.getMatch(fp);
			nodes.add( transpose( context, fp, target));
			
		}
		
		return nodes;
	}
	
	/**
	 * transposes a single {@link FingerPrint} linked to its target
	 * @param context - the {@link ZedViewingContext}
	 * @param fp - the {@link FingerPrint}
	 * @param target - the {@link GenericEntity} target 
	 * @return - the instrumented {@link FingerPrintNode}
	 */
	private static FingerPrintNode transpose(ZedViewingContext context, FingerPrint fp, GenericEntity target) {
		FingerPrintNode node = CommonContentTransposer.transpose(context, fp);
		if (target != null) {
			if (target instanceof ModelEntityReference) {
				GenericEntityNode entityNode = transpose(context, (ModelEntityReference) target, node);
				node.getChildren().add(entityNode);				
			}
			else if (target instanceof ModelPropertyReference) {
				PropertyNode propertyNode = transpose(context, (ModelPropertyReference) target, node);
				node.getChildren().add(propertyNode);
			}
			else if (target instanceof MethodEntity) {
				MethodNode methodNode = transpose(context, (MethodEntity) target, node);				
				node.getChildren().add(methodNode);
			}
			else if (target instanceof ModelEnumReference) {
				EnumEntityNode enumNode = transpose( context, (ModelEnumReference) target, node);
				node.getChildren().add( enumNode);
				
			}			
			else if (target instanceof FieldEntity) {
				FieldNode fieldNode = transpose( context, (FieldEntity) target, node);
				node.getChildren().add( fieldNode);
			}
		}
		return node;
	}

	/**
	 * @param context
	 * @param target
	 * @param relatedFingerPrintNode
	 * @return
	 */
	private static FieldNode transpose(ZedViewingContext context, FieldEntity target, FingerPrintNode relatedFingerPrintNode) {
		FieldNode node = FieldNode.T.create();
		node.setName( target.getName());
		node.setRelatedFingerPrint(relatedFingerPrintNode);
		HasFieldsNature owner = target.getOwner();
		if (owner instanceof ZedEntity) {
			node.getChildren().add( transpose( context, (ZedEntity) owner, relatedFingerPrintNode));
		}
		return node;
	}

	/**
	 * @param context
	 * @param target
	 * @param relatedFingerPrintNode
	 * @return
	 */
	private static EnumEntityNode transpose(ZedViewingContext context, ModelEnumReference target, FingerPrintNode relatedFingerPrintNode) {
		EnumEntityNode node = EnumEntityNode.T.create();
		node.setRelatedFingerPrint( relatedFingerPrintNode);
		node.setName( target.getEnumEntity().getName());
		return node;
	}

	/**
	 * transpose a single GenericEntity
	 * @param context - the {@link ZedViewingContext}
	 * @param mer - the {@link ModelEntityReference}
	 * @return - an {@link GenericEntityNode}
	 */
	private static GenericEntityNode transpose( ZedViewingContext context, ModelEntityReference mer, FingerPrintNode relatedFingerPrintNode) {
		GenericEntityNode geNode = GenericEntityNode.T.create();
		geNode.setRelatedFingerPrint( relatedFingerPrintNode);
		geNode.setName(mer.getType().getName());
		return geNode;
	}

	/**
	 * transposes a {@link ZedEntity}
	 * @param context - the {@link ZedViewingContext}
	 * @param ze - the {@link ZedEntity}
	 * @return - the {@link EntityNode}
	 */
	private static EntityNode transpose( ZedViewingContext context, ZedEntity ze, FingerPrintNode relatedFingerPrintNode) {
		EntityNode en = EntityNode.T.create();
		en.setName( ze.getName());
		en.setRelatedFingerPrint( relatedFingerPrintNode);
		en.setModuleName( ze.getModuleName());		
		return en;
	}
	
	/**
	 * transposes a {@link MethodEntity}
	 * @param context - the {@link ZedViewingContext}
	 * @param me - the {@link MethodEntity}
	 * @return - the {@link MethodNode}
	 */
	private static MethodNode transpose(ZedViewingContext context, MethodEntity me, FingerPrintNode relatedFingerPrintNode) {
		MethodNode mn = MethodNode.T.create();
		
		TypeReferenceEntity returnType = me.getReturnType();
		mn.setReturnType( transpose(context, returnType.getReferencedType(), relatedFingerPrintNode));
		
		List<TypeReferenceEntity> argumentTypes = me.getArgumentTypes();
		mn.getParameterTypes().addAll(argumentTypes.stream().map( tf -> tf.getReferencedType()).map( z -> transpose( context, z, relatedFingerPrintNode)).collect( Collectors.toList()));
				
		mn.setName(me.getName());
						
		HasMethodsNature owner = me.getOwner();
		if (owner instanceof ModelEntityReference) {
			mn.getChildren().add( transpose(context, (ModelEntityReference) owner, relatedFingerPrintNode));	
		}
		
		return mn;
	}

	/**
	 * transposes a {@link ModelPropertyReference}
	 * @param context - the {@link ZedViewingContext}
	 * @param mpr - the {@link ModelPropertyReference}
	 * @return - the {@link PropertyNode}
	 */
	private static PropertyNode transpose(ZedViewingContext context, ModelPropertyReference mpr, FingerPrintNode relatedFingerPrintNode) {
		PropertyNode pn = PropertyNode.T.create();
		String name = mpr.getName();
		pn.setName( name);
		pn.setType( mpr.getType().getName());
		
		// find literal 
		InterfaceEntity ie = (InterfaceEntity) mpr.getOwner().getType();
		
		FieldEntity tag  = null;
		for (FieldEntity fe : ie.getFields()) {
			if (fe.getName().equalsIgnoreCase( name)) {
				tag = fe;
				break;
			}			
		}
		if (tag != null) {
			Object initializer = tag.getInitializer();
			if (initializer instanceof String) {
				pn.setLiteral( (String) initializer);				
			}
		}
		
		ModelEntityReference owner = mpr.getOwner();		
		pn.getChildren().add( transpose(context, owner, relatedFingerPrintNode));				
		return pn;
	}
	
	

}
