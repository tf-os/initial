// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.devrock.preferences.pages.main;

import org.eclipse.jface.preference.PreferencePage;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.FontData;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

import com.braintribe.devrock.api.storagelocker.StorageLockerSlots;
import com.braintribe.devrock.api.ui.editors.BooleanEditor;
import com.braintribe.devrock.api.ui.editors.IntegerEditor;
import com.braintribe.devrock.bridge.eclipse.environment.BasicStorageLocker;
import com.braintribe.devrock.plugin.DevrockPlugin;

public class DevrockTitlePage extends PreferencePage implements IWorkbenchPreferencePage {

	private static final String DEVROCK_PREFERENCES = "Braintribe's Devrock Eclipse support";

	private final Image banner;
	private Font bigFont;
	private BooleanEditor activateAutoWorkspaceUpdate;
	private BooleanEditor selectiveWorkspaceUpdate;
	private BooleanEditor activateResolutionViewerYaml;
	private BooleanEditor storeSettingsOfResolutionViewer;
	private BooleanEditor terminalTabInitial;
	private BooleanEditor requireHigherVersionInFlexibleAssignment;
	private IntegerEditor maxResultInRemoteDependencyImport;

	
	public DevrockTitlePage() {
		setDescription(DEVROCK_PREFERENCES);
		
		ImageDescriptor imageDescriptor = ImageDescriptor.createFromFile( DevrockTitlePage.class, "bt.banner.png");
		banner = imageDescriptor.createImage();		
	}

	@Override
	public void init(IWorkbench arg0) {
		// NO OP
	}

	@Override
	protected Control createContents(Composite parent) {
		Font initialFont = parent.getFont();
		FontData [] fontDataBig = initialFont.getFontData();
		for (FontData data : fontDataBig) {
			data.setHeight( data.getHeight() + (data.getHeight() / 5));				
		}
		bigFont = new Font( getShell().getDisplay(), fontDataBig);
		
		Composite composite = new Composite(parent, SWT.NONE);
		
		GridLayout layout = new GridLayout();
		layout.numColumns = 4;
		composite.setLayout( layout);
		

		// TODO: perhaps a view of the loaded Devrock plugin?
		Composite choicesComposite = new Composite( composite, SWT.NONE);
		choicesComposite.setLayout(layout);
		choicesComposite.setLayoutData(new GridData( SWT.LEFT, SWT.CENTER, true, true, 4, 1));
		
		Label choicesLabel = new Label( choicesComposite, SWT.NONE);
		choicesLabel.setText("Miscellaneous choices");
		choicesLabel.setFont(bigFont);
		choicesLabel.setLayoutData(new GridData( SWT.LEFT, SWT.CENTER, false, false, 4, 1));
		
		// AC stuff 
		activateAutoWorkspaceUpdate = new BooleanEditor();
		activateAutoWorkspaceUpdate.setLabelToolTip( "Changes the behavior of the workspace resource change listener");
		activateAutoWorkspaceUpdate.setCheckToolTip( "If checked, the containers will react to changes of the workspace, otherwise manual synchronizing is required");
		Composite control = activateAutoWorkspaceUpdate.createControl(choicesComposite, "Automatically update containers on detected changes in workspace");
		control.setLayoutData(new GridData( SWT.FILL, SWT.CENTER, true, false, 4, 1));
		boolean autoUpdate = DevrockPlugin.envBridge().storageLocker().getValue( StorageLockerSlots.SLOT_AUTO_UPDATE_WS, true);
		activateAutoWorkspaceUpdate.setSelection( autoUpdate);
		
		selectiveWorkspaceUpdate = new BooleanEditor();
		selectiveWorkspaceUpdate.setLabelToolTip("Changes the behavior of the default workspace sync");
		selectiveWorkspaceUpdate.setCheckToolTip( "If checked and projects are selected, it will sync these. Otherwise it will sync the workspace");
		control = selectiveWorkspaceUpdate.createControl(choicesComposite, "Selective workspace synchronization");		
		control.setLayoutData(new GridData( SWT.FILL, SWT.CENTER, true, false, 4, 1));
		boolean selectivity = DevrockPlugin.envBridge().storageLocker().getValue( StorageLockerSlots.SLOT_SELECTIVE_WS_SYNCH, false);
		selectiveWorkspaceUpdate.setSelection( selectivity);
		
		//requireHigherVersionInFlexibleAssignment
		requireHigherVersionInFlexibleAssignment = new BooleanEditor();
		requireHigherVersionInFlexibleAssignment.setLabelToolTip("Changes how non-matching projects of dependencies in debug-module projects are handled");
		requireHigherVersionInFlexibleAssignment.setCheckToolTip( "If checked, the project must have at least the same version as requested. Otherwise it only has to match a derived standard range");
		control = requireHigherVersionInFlexibleAssignment.createControl(choicesComposite, "Strict version interpretation for debug-module dependency-projects");		
		control.setLayoutData(new GridData( SWT.FILL, SWT.CENTER, true, false, 4, 1));
		boolean requireHigherVersion = DevrockPlugin.envBridge().storageLocker().getValue( StorageLockerSlots.SLOT_AC_REQUIRE_HIGHER_VERSION, false);
		requireHigherVersionInFlexibleAssignment.setSelection( requireHigherVersion);
		
		
		// resolution viewer 
		activateResolutionViewerYaml = new BooleanEditor();
		activateResolutionViewerYaml.setLabelToolTip( "Add a YAML display tab to the resolution viewer - careful : big files put a heavy tax on Eclipse!");
		activateResolutionViewerYaml.setCheckToolTip( "If checked, the resolution viewer shows the YAML of the resolution as a tab (you were warned)");
		control = activateResolutionViewerYaml.createControl(choicesComposite, "Add a YAML display tab to the resolution viewer (for powerful computers only)");
		control.setLayoutData(new GridData( SWT.FILL, SWT.CENTER, true, false, 4, 1));
		boolean enableViewerButton = DevrockPlugin.instance().storageLocker().getValue( StorageLockerSlots.SLOT_ARTIFACT_VIEWER_YAML_ENABLED, false);
		activateResolutionViewerYaml.setSelection(enableViewerButton);
		
		storeSettingsOfResolutionViewer = new BooleanEditor();
		storeSettingsOfResolutionViewer.setLabelToolTip( "Whether remember your last choices of view possiblities in the resolution viewer");
		storeSettingsOfResolutionViewer.setCheckToolTip( "If checked, the resolution viewer will remember your view choices for each tab (plus one for all detail tabs)");
		control = storeSettingsOfResolutionViewer.createControl(choicesComposite, "Store view settings on resolution viewer tabs");
		control.setLayoutData(new GridData( SWT.FILL, SWT.CENTER, true, false, 4, 1));
		boolean storeSettings = DevrockPlugin.instance().storageLocker().getValue( StorageLockerSlots.SLOT_ARTIFACT_VIEWER_STORE_VIEW_SETTINGS, false);
		storeSettingsOfResolutionViewer.setSelection(storeSettings);
		
		terminalTabInitial = new BooleanEditor();
		terminalTabInitial.setLabelToolTip( "Whether to initially open the terminal-tab or the solutions-tab when the resolution-viewer is openend");
		terminalTabInitial.setCheckToolTip( "If checked, the resolution viewer will show the 'terminal-tab' when opened. Otherwise will activate the 'solutions-tab'");
		control = terminalTabInitial.createControl(choicesComposite, "Open the 'terminal-tab' at resolution-viewer start-up");
		control.setLayoutData(new GridData( SWT.FILL, SWT.CENTER, true, false, 4, 1));
		boolean terminalInitials = DevrockPlugin.instance().storageLocker().getValue( StorageLockerSlots.SLOT_ARTIFACT_VIEWER_INITIAL_TAG_TERMINAL, true);
		terminalTabInitial.setSelection( terminalInitials);
		
		
		
		
		// dependency importer
		maxResultInRemoteDependencyImport = new IntegerEditor();
		maxResultInRemoteDependencyImport.setLabelToolTip( "The maximum number of hits shown in the 'Quick Remote Dependency Import'");		
		control = maxResultInRemoteDependencyImport.createControl(choicesComposite, "Maximum artifacts in dependency selection dialog");
		control.setLayoutData(new GridData( SWT.FILL, SWT.CENTER, true, false, 4, 1));
		int maxResult = DevrockPlugin.instance().storageLocker().getValue( StorageLockerSlots.SLOT_MAX_RESULT, 100);
		maxResultInRemoteDependencyImport.setSelection(maxResult);
		
		
		composite.pack();
		return composite;
	}


	@Override
	public void dispose() {
		bigFont.dispose();
		banner.dispose();
	}
	
	private void saveToLocker() {
		BasicStorageLocker storageLocker = DevrockPlugin.envBridge().storageLocker();

		boolean activateAutoUpdate = activateAutoWorkspaceUpdate.getSelection();
		storageLocker.setValue(StorageLockerSlots.SLOT_AUTO_UPDATE_WS, activateAutoUpdate);
		
		boolean selectiveUpdate = selectiveWorkspaceUpdate.getSelection();
		storageLocker.setValue(StorageLockerSlots.SLOT_SELECTIVE_WS_SYNCH, selectiveUpdate);
		
		boolean requireHigherVersion = requireHigherVersionInFlexibleAssignment.getSelection();
		storageLocker.setValue(StorageLockerSlots.SLOT_AC_REQUIRE_HIGHER_VERSION, requireHigherVersion);
		
		boolean enableResolutionViewerYaml = activateResolutionViewerYaml.getSelection();		
		storageLocker.setValue(StorageLockerSlots.SLOT_ARTIFACT_VIEWER_YAML_ENABLED, enableResolutionViewerYaml);
		
		boolean storeResolutionViewerSettings = storeSettingsOfResolutionViewer.getSelection();		
		storageLocker.setValue(StorageLockerSlots.SLOT_ARTIFACT_VIEWER_STORE_VIEW_SETTINGS, storeResolutionViewerSettings);
		
		boolean openTerminalTabSettings = terminalTabInitial.getSelection();		
		storageLocker.setValue(StorageLockerSlots.SLOT_ARTIFACT_VIEWER_INITIAL_TAG_TERMINAL, openTerminalTabSettings);
				
		Integer maxResult = maxResultInRemoteDependencyImport.getSelection();
		if (maxResult != null) {
			storageLocker.setValue(StorageLockerSlots.SLOT_MAX_RESULT, maxResult);	
		}
	}

	@Override
	protected void performApply() {
		saveToLocker();
		super.performApply();
	}

	@Override
	public boolean performOk() {
		saveToLocker();
		return super.performOk();
	}
	
	
}
