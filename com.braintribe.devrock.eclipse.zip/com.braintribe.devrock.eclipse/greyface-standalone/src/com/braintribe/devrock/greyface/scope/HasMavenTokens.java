// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.devrock.greyface.scope;

import java.io.File;

public interface HasMavenTokens {
	public static final String REMOTE_SETTINGS = "${M2_HOME}" + File.separator + "conf" + File.separator + "settings.xml";
	public static final String LOCAL_SETTINGS = "${user.home}" + File.separator + ".m2" + File.separator + "settings.xml";
}
