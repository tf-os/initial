# Configuration
As malaclypse's configuration comes from different sources than the plugins' configurations, it's not part of *this* documentation. See the pertinent section in the documentation of the mc-core (com.braintribe.devrock:mc-core-documentation).


## Miscellaneous switches

- Automatically update containers on detected changes in the workspace<br/> If this switch is set, the containers will be automatically synchronized if any (pertinent) changes are detected in the workspace. If this switch is not set, you have to manually synchronize the containers using the respective commands. Default is automatic synchronization.

> If activated, changes to the workspace (closing/deleting, opening/importing) lead to a re-synchronization of all artifacts in the workspace with a container attached, while changes to a pom of a project leads to the re-synchronization of the respective project. 
This process will trigger the 'JDT' compiler which automatically rebuilds the projects touched (and their dependencies within the workspace)


- Selective workspace synchronization<br/> If this switch is set, the 'workspace synchronization' command turns to be sensitive to the selection in the package explorer, so that only the containers of the currently selected projects are synchronize. If the switch is not set, the command will automatically update the containers of all projects in the workspace.


><b>Finally, if you are wanting to make sure that your '-pc' artifact is taken rather than a newly published artifact, please remember the '.pc-bias' file. It is a feature of 'mc-core' itself and is documented in its proper documentation, see 'configuration/filtering'.</b>

## Source repository 

The source repository configuration allows you to specify the directories for the source look-up. Depending on how your basic configuration is set-up, it will already have some configured source repositories.

You can add a new source directory. Each such a directory is added by its path and a 'unique' key. You can edit and even delete the reference. However, the entries coming from the dev-env are not editable. 

![picture of the source repository configuration](preferences.sources.jpg "preferences")


Other than that, some switches are available here:

### version manipulation modes

You can influence the dependencies copy and paste functions, i.e. you can specify how these features should handle the version part of a dependency. 


 - keep as is
 
   The version is kept exactly as it is encountered (either in the pom file during copy to the clipboard or while inserting it into a pom file), so 'a.b.c:x#1.0.15' will remain 'a.b.c:x#1.0.15'

 - auto rangify
 
   The version is automatically turned into a 'fuzzy' version, i.e. into a 'minor auto range'. For instance the version 'a.b.c:x#1.0.15' will be used as 'a.b.c:x#[1.0, 1.1)' 

> Note : this feature is currently based on the 'major/minor' scheme. If we move to 'major'-only scheme, it will require an update of this feature. 
   

 - variable reference 
 
   The version is removed and replaced by a variable whose name is derived from the groupId of the dependency. So if you are copying/pasting 'a.b.c:x#1.0', the expression will be turned into 'a.b.c:x${V.a.b.c}'.


> Note: there is no process to ensure the variable exists, neither be checking nor creating it. You need to make sure on your own that variable is either declared locally in the respective pom file itself or in a pom in the parent-chain.

## QI behavior

Per default, the QI processor will only show you artifacts whose project can be imported into the workspace. What that means depends on the content of your workspace and - if you activated the support for working sets - what (if any) working set is currently selected.

- show all scanned artifacts (do not filter any)<br/>
   If set, the QI dialog will show all artifacts that matched the query. The artifacts that cannot be imported (because they a) exist in the workspace or b) in the current working set) are shown in a different color than the ones that can be imported. Default is off, so only artifacts are shown that can be imported. 
   
> Obviously, this only acts when you run the QI in order to import the project. If you use it to inject dependencies into another project, you can of course select any shown artifact. 

- Allow selection of project if a working set is selected <br/>
If set, and a working set is currently selected in the package explorer, artifacts are only filtered-out if they exist in this working set (as they can be imported - or rather - referenced in the working set no matter whether they already are part of the workspace in another working set). Default is off. 
    

## Virtual Environment
The virtual environment is used to override environment variables or system properties. Obviously, only malaclypse underneath reacts to it - so you can influence how and where malaclypse's configuration is taken and how it is compiled.

![picture of the virtual environment configuration](preferences.environment.jpg "environment")


- global activation switch<br/> The Virtual Environment can be globally switched on or off, globally in that sense that it deactives all overrides of environment variables and system properties. 


For each environment variable or system property you can enter the name and its current value is immediately shown. You then can enter the overriding value.

- local activation switch<br/> Every override has its own activation switch, so you can de-/activate any entry separately. 


- nulling a variable<br/> In some cases, you may not want to override a variable or property, but rather 'null' it (so to say make it non-existing in the VE). In that case, just leave the 'value' empty. 


