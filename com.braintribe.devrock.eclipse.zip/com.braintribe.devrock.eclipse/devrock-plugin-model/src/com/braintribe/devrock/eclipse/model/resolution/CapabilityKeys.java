// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.devrock.eclipse.model.resolution;

import com.braintribe.model.generic.base.EnumBase;
import com.braintribe.model.generic.reflection.EnumType;
import com.braintribe.model.generic.reflection.EnumTypes;

public enum CapabilityKeys implements EnumBase {
	saveResolution, // adds a 'save resolution button' to tab
	shortNotation,  // show 'js-style' short notations for ranges 
	visibleGroups, // show groups
	visibleArtifactNature, // show artifact nature as icons
	visibleDependencies, // show dependencies as structural element (hide dep-info in node)
	parents, parentDependers, // show parents and their dependers 
	imports, importDependers, // show imports and their imports and users 
	dependencies, dependers,  // show dependencies (top down) and dependers (bottom up)
	filter, // allow filtering the contents
	search,  // add search feature (currently ignored by the viewer)
	detail, // allow double-clicking to create a new tab 
	parts, // show parts of the artifact
	coalesce, // combine duplicates
	open; // open pom files
		
	final EnumType T = EnumTypes.T(CapabilityKeys.class);
	
	@Override
	public EnumType type() {
		return T;
	}
}
