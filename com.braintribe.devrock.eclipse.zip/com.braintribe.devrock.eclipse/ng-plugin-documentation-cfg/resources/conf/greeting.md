# Devrock Eclipse Plugin documentation

The Devrock Plugins for Eclipse are intended to help a developer to work with the projects and build system that is used to build Tribefire, its extentions etc. But it can also be used to handle any Eclipse projects that are compatible. 