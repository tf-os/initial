// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.devrock.ac.commands.dynamic;

import java.util.Set;
import java.util.stream.Collectors;

import org.eclipse.core.resources.IProject;
import org.eclipse.jface.action.ContributionItem;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;

import com.braintribe.devrock.ac.container.plugin.ArtifactContainerPlugin;
import com.braintribe.devrock.ac.container.updater.ProjectUpdater;
import com.braintribe.devrock.api.selection.SelectionExtracter;
import com.braintribe.devrock.api.ui.commons.UiSupport;
import com.braintribe.devrock.plugin.DevrockPlugin;
import com.braintribe.devrock.plugin.DevrockPluginStatus;
import com.braintribe.logging.Logger;


/**
 * dynamic command to show the properties of a selected project's container
 *
 */
public class DynamicBuildProjectsCommandItem extends ContributionItem {
	private static Logger log = Logger.getLogger(DynamicBuildProjectsCommandItem.class);
	
	private UiSupport uisupport = ArtifactContainerPlugin.instance().uiSupport();	
	private Image image;
	
	public DynamicBuildProjectsCommandItem() {
		//ImageDescriptor dsc = org.eclipse.jface.resource.ImageDescriptor.createFromFile( DynamicBuildProjectsCommandItem.class, "refresh-classpath.png");
		image = uisupport.images().addImage( "ac-cmd-build-prjs", DynamicBuildProjectsCommandItem.class, "refresh-classpath.png");		
	}
	
	public DynamicBuildProjectsCommandItem(String id) {
		super( id);
	}
	
	@Override
	public void fill(Menu menu, int index) {	
		long before = System.currentTimeMillis();
		Set<IProject> selectedProjects = SelectionExtracter.selectedProjects( SelectionExtracter.currentSelection());
		if (selectedProjects == null || selectedProjects.size() == 0)
			return;
		
		MenuItem menuItem = new MenuItem(menu, SWT.CHECK, index);
		if (selectedProjects.size() > 1) {
			menuItem.setText("Refresh the classpath containers of (" + selectedProjects.size() + " selected projects)");
			String txt = selectedProjects.stream().map(ip -> ip.getName()).collect( Collectors.joining(", "));
			menuItem.setToolTipText( "Refreshes the classpath containers of the following projects: " + txt);
		}
		else {			
			IProject ip = selectedProjects.stream().findFirst().orElse(null);
			menuItem.setText("Refresh the classpath containers of the selected project: " + ip.getName());
			menuItem.setToolTipText( "Refreshes the classpath containers of the following project: " + ip.getName());
		}
		
	    menuItem.setImage(  image);
	    
	    menuItem.addSelectionListener(new SelectionAdapter() {
	            public void widgetSelected(SelectionEvent e) {
	            	try {	        			
	            		ProjectUpdater updater = new ProjectUpdater();
	        			updater.setSelectedProjects( selectedProjects);
	        			updater.runAsJob();
					} catch (Exception e1) {
						DevrockPluginStatus status = new DevrockPluginStatus("cannot run refresh on projects", e1);
						DevrockPlugin.instance().log(status);
					}
	            }
	        });		
	    if (log.isDebugEnabled()) {
	    	long after = System.currentTimeMillis();
	    	log.debug( getClass().getName() + " : " + (after - before));
	    }
	}

	@Override
	public void dispose() {
		//image.dispose();
		super.dispose();
	}
	
	
	
	

}
