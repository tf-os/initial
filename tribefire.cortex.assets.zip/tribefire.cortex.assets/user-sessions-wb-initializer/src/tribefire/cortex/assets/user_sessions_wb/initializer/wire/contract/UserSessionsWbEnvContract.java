// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.cortex.assets.user_sessions_wb.initializer.wire.contract;

import com.braintribe.wire.impl.properties.PropertyLookups;

import tribefire.cortex.initializer.support.wire.contract.PropertyLookupContract;

/**
 * @see PropertyLookupContract
 * @see PropertyLookups
 */
public interface UserSessionsWbEnvContract extends PropertyLookupContract {
	// Empty; For an example see the super-type (PropertyLookupContract); More info also in PropertyLookups
}
