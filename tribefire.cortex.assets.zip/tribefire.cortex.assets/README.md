# tribefire.cortex.assets
