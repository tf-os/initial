# hibernate-leadership-edr2cc-module

## bindHardwired()

Binds an enricher which sets the correct (backwards compatible) `Hibernate` mapping for `tribefire-leadership`.

This is separate from [hibernate-accesses-edr2cc-module](../hibernate-accesses-edr2cc-module/readme.md) as it brings a dependency to the `leadership-module`.