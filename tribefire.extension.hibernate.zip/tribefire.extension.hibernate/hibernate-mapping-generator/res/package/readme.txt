Run the HibernateMappingGenerator using one of the run scripts. Expected arguments are:

1) model.xml file path
2) output folder
3) table name prefix
4) all upper case? (true/false)
5) the target database, e.g. "mssql"
6) json hints file path
 