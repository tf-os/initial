java -Djava.util.logging.config.file=logging.properties -Xmx2000M -cp lib/* com.braintribe.model.processing.deployment.hibernate.HbmGeneratorMain $@
