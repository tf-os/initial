// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.processing.deployment.hibernate.mapping.exception;

public class HbmXmlGeneratingServiceException extends RuntimeException {

	private static final long serialVersionUID = -820172865406092354L;

	public HbmXmlGeneratingServiceException(String message) {
		super(message);
	}

	public HbmXmlGeneratingServiceException(Throwable cause) {
		super(cause);
	}

	public HbmXmlGeneratingServiceException(String message, Throwable cause) {
		super(cause != null && cause.getMessage() != null && !cause.getMessage().isEmpty() ? message + ": " + cause.getMessage() : message, cause);
	}

}
