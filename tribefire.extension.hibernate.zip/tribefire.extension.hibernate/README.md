# tribefire.extension.hibernate

## Main module:

* [hibernate-module](hibernate-module/readme.md)

## See also:
* [hibernate-accesses-edr2cc-module](hibernate-accesses-edr2cc-module/readme.md)
* [hibernate-leadership-edr2cc-module](hibernate-leadership-edr2cc-module/readme.md)
* [hibernate-shared-md-priming](hibernate-shared-md-priming/readme.md)