// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.transport.messaging.rabbitmq;

import com.braintribe.transport.messaging.api.Messaging;
import com.braintribe.transport.messaging.api.MessagingContext;

/**
 * <p>
 * Rabbit MQ implementation of the GenericModel-based messaging system.
 * 
 * @see Messaging
 */
public class RabbitMqMessaging implements Messaging<com.braintribe.model.messaging.rabbitmq.RabbitMqMessaging> {

	@Override
	public RabbitMqConnectionProvider createConnectionProvider(com.braintribe.model.messaging.rabbitmq.RabbitMqMessaging denotation,
			MessagingContext context) {

		RabbitMqConnectionProvider rabbitMqConnectionProvider = new RabbitMqConnectionProvider();
		rabbitMqConnectionProvider.setConnectionConfiguration(denotation);
		rabbitMqConnectionProvider.setMessagingContext(context);

		return rabbitMqConnectionProvider;

	}

}
