// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.processing.web.rest.model;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

public interface TestEntityWithStringProperties extends GenericEntity {

	static EntityType<TestEntityWithStringProperties> T = EntityTypes.T(TestEntityWithStringProperties.class);

	String getProperty1();
	void setProperty1(String property1);

	String getProperty2();
	void setProperty2(String property2);

	String getProperty3();
	void setProperty3(String property3);
}
