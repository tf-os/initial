// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.processing.resource.server.test.wire.contract;

import java.util.List;

import javax.servlet.Filter;

import com.braintribe.codec.marshaller.api.ConfigurableMarshallerRegistry;
import com.braintribe.model.processing.resource.server.WebStreamingServer;
import com.braintribe.model.processing.resource.server.test.commons.TestAuthenticatingUserSessionProvider;
import com.braintribe.model.processing.resource.server.test.commons.TestAuthorizationContext;
import com.braintribe.model.processing.resource.server.test.commons.TestPersistenceGmSessionFactory;
import com.braintribe.model.processing.resource.server.test.commons.TestResourceAccessFactory;
import com.braintribe.model.processing.resource.streaming.access.RemoteResourceAccessFactory;
import com.braintribe.model.processing.session.impl.persistence.BasicPersistenceGmSession;
import com.braintribe.model.processing.smood.Smood;
import com.braintribe.model.usersession.UserSession;
import com.braintribe.provider.ThreadLocalStackedHolder;
import com.braintribe.wire.api.context.WireContext;
import com.braintribe.wire.api.space.WireSpace;

public interface MainContract extends WireSpace {

	static WireContext<MainContract> context() {
		// @formatter:off
		WireContext<MainContract> wireContext = 
				com.braintribe.wire.api.Wire
					.context(MainContract.class)
						.bindContracts(MainContract.class.getName().replace(".contract."+MainContract.class.getSimpleName(), ""))
					.build();
		return wireContext;
		// @formatter:on
	}

	TestAuthenticatingUserSessionProvider userSessionProvider();

	TestAuthorizationContext userSessionIdProvider();

	RemoteResourceAccessFactory remoteResourceAccessFactory();

	ThreadLocalStackedHolder<UserSession> userSessionHolder();

	List<Filter> filters();

	WebStreamingServer servlet();

	Smood access();

	BasicPersistenceGmSession gmSession();

	TestResourceAccessFactory resourceAccessFactory();

	TestPersistenceGmSessionFactory sessionFactory();

	ConfigurableMarshallerRegistry marshallerRegistry();

}
