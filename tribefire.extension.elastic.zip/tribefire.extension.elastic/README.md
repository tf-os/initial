# tribefire.extension.elastic

This is the last version to be based on Elastic 5.4 and also provides an embedded Elastic service. Future versions will be client-only, with newer Elastic versions.
