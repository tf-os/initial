// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.transport.jms.util;

import javax.jms.ExceptionListener;
import javax.jms.JMSException;

import com.braintribe.logging.Logger;

public class JmsExceptionListener implements ExceptionListener {

	protected Logger logger = null;

	public JmsExceptionListener(Logger logger) {
		this.logger = logger;
	}

	@Override
	public void onException(JMSException e) {
		if (e != null) {
			logger.error(e.getMessage(), e);
			Exception linkedException = e.getLinkedException();
			if (linkedException != null) {
				logger.error(linkedException.getMessage(), linkedException);
			}
		}
	}

	public static String getBuildVersion() {
		return "$Build_Version$ $Id: JmsExceptionListener.java 92413 2016-03-15 08:30:06Z roman.kurmanowytsch $";
	}
}
