package com.braintribe.asm;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;

public class OpcodesTest {

	@Test
	public void testJava17Support() {

		assertThat(Opcodes.V17).isEqualTo(61);

	}

}
