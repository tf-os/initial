// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.service.expert.hellosign;

import java.io.File;
import java.io.FileInputStream;

import com.braintribe.logging.Logger;
import com.braintribe.model.resource.Resource;
import com.hellosign.sdk.HelloSignClient;
import com.hellosign.sdk.HelloSignException;
import com.hellosign.sdk.resource.SignatureRequest;

import tribefire.extension.docsign.model.deployment.repository.configuration.HelloSignSpecification;
import tribefire.extension.docsign.model.service.DownloadESignatureContent;
import tribefire.extension.docsign.model.service.ESignatureContentResult;

public class DownloadESignatureContentExpert extends HelloSignExpert<DownloadESignatureContent, ESignatureContentResult> {

	private static final Logger logger = Logger.getLogger(DownloadESignatureContentExpert.class);

	@Override
	public ESignatureContentResult process() {
		try {
			SignatureRequest response = client.getSignatureRequest(request.getESignatureId());
			if (response.isComplete()) {
				File pdf = client.getFiles(request.getESignatureId());
				if (pdf != null) {
					Resource callResource = Resource.createTransient(() -> new FileInputStream(pdf));
					callResource.setMimeType("application/pdf");
					callResource.setName(pdf.getName());
					callResource.setFileSize(pdf.length());

					//@formatter:off
					return responseBuilder(ESignatureContentResult.T, request)
						.responseEnricher(r -> 
							r.setResource(callResource)
						).build();
					//@formatter:on
				} else {
					throw new IllegalArgumentException("Retreived document is null!");
				}
			} else {
				throw new IllegalArgumentException("Requested document is not completely signed!");
			}
		} catch (HelloSignException e) {
			logger.error("Error executing HelloSign GET FILE request!", e);
			throw new IllegalArgumentException(e.getMessage());
		}
	}

	// ***************************************************************************************************
	// Initialization
	// ***************************************************************************************************

	public static DownloadESignatureContentExpert forDownloadESignatureContentExpert(HelloSignSpecification provider, DownloadESignatureContent request) {
		return createExpert(DownloadESignatureContentExpert::new, (expert) -> {
			expert.setClient(new HelloSignClient(provider.getApiKey()));
			expert.setRequest(request);
		});
	}

}
