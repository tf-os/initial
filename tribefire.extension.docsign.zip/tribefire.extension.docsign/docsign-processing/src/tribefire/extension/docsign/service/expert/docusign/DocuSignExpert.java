// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.service.expert.docusign;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.braintribe.logging.Logger;
import com.docusign.esign.api.EnvelopesApi;
import com.docusign.esign.api.FoldersApi;
import com.docusign.esign.client.ApiClient;
import com.docusign.esign.client.ApiException;
import com.docusign.esign.client.Configuration;
import com.docusign.esign.client.auth.OAuth;
import com.docusign.esign.client.auth.OAuth.UserInfo;
import com.docusign.esign.model.ConsoleViewRequest;
import com.docusign.esign.model.Envelope;
import com.docusign.esign.model.ViewUrl;

import tribefire.extension.docsign.model.SignerResponse;
import tribefire.extension.docsign.model.service.DocsignRequest;
import tribefire.extension.docsign.model.service.DocsignResult;
import tribefire.extension.docsign.model.service.ESignatureResult;
import tribefire.extension.docsign.service.expert.BaseExpert;

public abstract class DocuSignExpert<S extends DocsignRequest, T extends DocsignResult> extends BaseExpert<S, T> {

	private static final Logger logger = Logger.getLogger(DocuSignExpert.class);

	protected UserInfo userInfo;
	protected EnvelopesApi envelopesApi;
	protected FoldersApi foldersApi;
	protected String accountId;

	// ***************************************************************************************************
	// Configuration
	// ***************************************************************************************************

	public void setUserInfo(UserInfo userInfo) {
		this.userInfo = userInfo;
	}

	public void setEnvelopesApi(EnvelopesApi envelopesApi) {
		this.envelopesApi = envelopesApi;
	}

	public void setFoldersApi(FoldersApi foldersApi) {
		this.foldersApi = foldersApi;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	// ***************************************************************************************************
	// Factory Helpers
	// ***************************************************************************************************

	protected static void configureExpert(DocuSignExpert expert, String clientId, String userId, String rsaKey, Boolean legallyBinding)
			throws ApiException, IOException {
		ApiClient apiClient = new ApiClient(legallyBinding ? ApiClient.PRODUCTION_REST_BASEPATH : ApiClient.DEMO_REST_BASEPATH);

		// String oauthLoginUrl = apiClient.getJWTUri("999a6b63-2128-400f-8ad5-15b8d2f38520", "http://localhost",
		// "account-d.docusign.com");
		// Desktop.getDesktop().browse(URI.create(oauthLoginUrl));

		List<String> scopes = new ArrayList<String>();
		scopes.add(OAuth.Scope_SIGNATURE);
		scopes.add(OAuth.Scope_IMPERSONATION);

		OAuth.OAuthToken oAuthToken = null;
		try {
			oAuthToken = apiClient.requestJWTUserToken(clientId, userId, scopes, rsaKey.getBytes(), 3600);
		} catch (NullPointerException npe) {
			throw new IllegalArgumentException("Provided RSA key is no valid!");
		}
		apiClient.setAccessToken(oAuthToken.getAccessToken(), oAuthToken.getExpiresIn());

		UserInfo userInfo = apiClient.getUserInfo(oAuthToken.getAccessToken());
		apiClient.setBasePath(userInfo.getAccounts().get(0).getBaseUri() + "/restapi");
		Configuration.setDefaultApiClient(apiClient);
		String accountId = userInfo.getAccounts().get(0).getAccountId();

		EnvelopesApi envelopesApi = new EnvelopesApi(apiClient);
		FoldersApi foldersApi = new FoldersApi(apiClient);

		expert.setUserInfo(userInfo);
		expert.setEnvelopesApi(envelopesApi);
		expert.setFoldersApi(foldersApi);
		expert.setAccountId(accountId);
		expert.setTestMode(!legallyBinding);
	}

	// -----------------------------------------------------------------------
	// HELPERS
	// -----------------------------------------------------------------------

	protected void toSignatureRequestResult(Envelope envelope, ESignatureResult signatureResult) {
		signatureResult.setESignatureId(envelope.getEnvelopeId());
		signatureResult.setSubject(envelope.getEmailSubject());
		signatureResult.setMessage(envelope.getEmailBlurb());
		signatureResult.setIsComplete("completed".equalsIgnoreCase(envelope.getStatus()));
		try {
			signatureResult.setCreatedAt(new SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.SSSSSSS'Z'").parse(envelope.getCreatedDateTime()));
		} catch (ParseException e) {
			logger.error("Error parsing date: " + envelope.getCreatedDateTime(), e);
		}

		try {
			ConsoleViewRequest viewRequest = new ConsoleViewRequest();
			viewRequest.setEnvelopeId(envelope.getEnvelopeId());

			ViewUrl viewUrl = envelopesApi.createConsoleView(accountId, viewRequest);
			signatureResult.setDetailsUrl(viewUrl.getUrl());
		} catch (ApiException e) {
			logger.error("Error creating view URL!", e);
		}

		List<String> carbonCopies = new ArrayList<String>();
		envelope.getRecipients().getCarbonCopies().stream().forEach(carbonCopy -> {
			carbonCopies.add(carbonCopy.getEmail());
		});
		signatureResult.setCCs(carbonCopies);

		List<SignerResponse> signatures = new ArrayList<SignerResponse>();
		envelope.getRecipients().getSigners().stream().forEach(signature -> {
			SignerResponse signatureResponse = SignerResponse.T.create();
			signatureResponse.setSignatureId(signature.getRecipientId());
			signatureResponse.setName(signature.getName());
			signatureResponse.setEmail(signature.getEmail());
			signatureResponse.setStatusCode(signature.getStatus());
			signatureResponse.setOrder(Integer.valueOf(signature.getRoutingOrder()));
			signatures.add(signatureResponse);
		});
		signatureResult.setSigners(signatures);
	}

}
