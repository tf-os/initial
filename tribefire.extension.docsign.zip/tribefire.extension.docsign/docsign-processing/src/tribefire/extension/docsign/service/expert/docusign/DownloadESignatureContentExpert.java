// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.service.expert.docusign;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import com.braintribe.logging.Logger;
import com.braintribe.model.resource.Resource;
import com.braintribe.utils.FileTools;
import com.docusign.esign.client.ApiException;
import com.docusign.esign.model.Envelope;

import tribefire.extension.docsign.model.deployment.repository.configuration.DocuSignSpecification;
import tribefire.extension.docsign.model.service.DownloadESignatureContent;
import tribefire.extension.docsign.model.service.ESignatureContentResult;

public class DownloadESignatureContentExpert extends DocuSignExpert<DownloadESignatureContent, ESignatureContentResult> {

	private static final Logger logger = Logger.getLogger(DownloadESignatureContentExpert.class);

	@Override
	public ESignatureContentResult process() {
		try {
			Envelope envelope = envelopesApi.getEnvelope(accountId, request.getESignatureId());
			if ("completed".equalsIgnoreCase(envelope.getStatus())) {
				byte[] pdfBytes = envelopesApi.getDocument(accountId, request.getESignatureId(), "combined");

				if (pdfBytes.length > 0) {
					try {
						File pdf = File.createTempFile("ds_", "pdf");
						FileTools.writeBytesToFile(pdf, pdfBytes);
						Resource callResource = Resource.createTransient(() -> new FileInputStream(pdf));
						callResource.setMimeType("application/pdf");
						callResource.setName(pdf.getName());
						callResource.setFileSize(pdf.length());

				//@formatter:off
				return responseBuilder(ESignatureContentResult.T, request)
					.responseEnricher(r -> 
						r.setResource(callResource)
					).build();
				//@formatter:on
					} catch (Exception e) {
						logger.error("Error executing DocuSign GET FILE request!", e);
						throw new IllegalArgumentException(e.getMessage());
					}
				} else {
					throw new IllegalArgumentException("Retreived document is null!");
				}
			} else {
				throw new IllegalArgumentException("Requested document is not completely signed!");
			}
		} catch (IllegalArgumentException | ApiException e) {
			logger.error("Error executing DocuSign GET FILE request!", e);
			throw new IllegalArgumentException(e.getMessage());
		}
	}

	// ***************************************************************************************************
	// Initialization
	// ***************************************************************************************************

	public static DownloadESignatureContentExpert forDownloadESignatureContentExpert(DocuSignSpecification provider,
			DownloadESignatureContent request) {
		return createExpert(DownloadESignatureContentExpert::new, (expert) -> {
			try {
				configureExpert(expert, provider.getClientId(), provider.getUserId(), provider.getRsaKey(), provider.getLegallyBinding());
				expert.setRequest(request);
			} catch (ApiException | IOException e) {
				logger.error("Error configuring DocuSign expert!", e);
				throw new IllegalArgumentException(e.getMessage());
			}
		});
	}

}
