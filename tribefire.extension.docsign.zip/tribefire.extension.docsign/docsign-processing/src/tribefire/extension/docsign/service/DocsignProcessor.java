// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

import com.braintribe.cfg.Configurable;
import com.braintribe.cfg.Required;
import com.braintribe.logging.Logger;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.notification.HasNotifications;
import com.braintribe.model.notification.Level;
import com.braintribe.model.notification.Notification;
import com.braintribe.model.processing.accessrequest.api.AccessRequestContext;
import com.braintribe.model.processing.accessrequest.api.AccessRequestProcessor;
import com.braintribe.model.processing.accessrequest.api.AccessRequestProcessors;
import com.braintribe.model.processing.notification.api.builder.Notifications;
import com.braintribe.model.processing.notification.api.builder.NotificationsBuilder;
import com.braintribe.utils.CommonTools;

import tribefire.extension.docsign.model.deployment.repository.configuration.DocuSignSpecification;
import tribefire.extension.docsign.model.deployment.repository.configuration.HelloSignSpecification;
import tribefire.extension.docsign.model.deployment.repository.configuration.ProviderSpecification;
import tribefire.extension.docsign.model.service.CancelESignature;
import tribefire.extension.docsign.model.service.DocsignRequest;
import tribefire.extension.docsign.model.service.DocsignResult;
import tribefire.extension.docsign.model.service.DownloadESignatureContent;
import tribefire.extension.docsign.model.service.ESignatureContentResult;
import tribefire.extension.docsign.model.service.ESignatureList;
import tribefire.extension.docsign.model.service.ESignatureListResult;
import tribefire.extension.docsign.model.service.ESignatureResult;
import tribefire.extension.docsign.model.service.GetESignature;
import tribefire.extension.docsign.model.service.RemoveESignature;
import tribefire.extension.docsign.model.service.SendESignatureReminder;
import tribefire.extension.docsign.model.service.SendForESignature;
import tribefire.extension.docsign.model.service.SuccessResult;
import tribefire.extension.docsign.model.service.UpdateESignature;
import tribefire.extension.docsign.service.base.ResponseBuilder;
import tribefire.extension.docsign.service.expert.hellosign.CancelSignatureRequestExpert;
import tribefire.extension.docsign.service.expert.hellosign.GetESignatureExpert;
import tribefire.extension.docsign.service.expert.hellosign.DownloadESignatureContentExpert;
import tribefire.extension.docsign.service.expert.hellosign.ListESignatureExpert;
import tribefire.extension.docsign.service.expert.hellosign.RemoveESignatureExpert;
import tribefire.extension.docsign.service.expert.hellosign.SendForESignatureExpert;
import tribefire.extension.docsign.service.expert.hellosign.SendESignatureReminderExpert;
import tribefire.extension.docsign.service.expert.hellosign.UpdateESignatureExpert;

public class DocsignProcessor implements AccessRequestProcessor<DocsignRequest, DocsignResult> {

	private static final Logger logger = Logger.getLogger(DocsignProcessor.class);

	private List<ProviderSpecification> providerSpecification;

	@Configurable
	@Required
	public void setProviderSpecifications(List<ProviderSpecification> providerSpecification) {
		this.providerSpecification = providerSpecification;
	}

	// -----------------------------------------------------------------------
	// DISPATCHING
	// -----------------------------------------------------------------------

	private AccessRequestProcessor<DocsignRequest, DocsignResult> delegate = AccessRequestProcessors.dispatcher(dispatching -> {
		dispatching.register(GetESignature.T, this::getESignature);
		dispatching.register(ESignatureList.T, this::listESignature);
		dispatching.register(SendForESignature.T, this::sendForESignature);
		dispatching.register(SendESignatureReminder.T, this::sendESignatureReminder);
		dispatching.register(UpdateESignature.T, this::updateESignature);
		dispatching.register(CancelESignature.T, this::cancelESignature);
		dispatching.register(RemoveESignature.T, this::removeESignature);
		dispatching.register(DownloadESignatureContent.T, this::downloadESignatureContent);
	});

	@Override
	public DocsignResult process(AccessRequestContext<DocsignRequest> context) {
		return delegate.process(context);
	}

	// -----------------------------------------------------------------------
	// SERVICE METHODS
	// -----------------------------------------------------------------------

	public ESignatureResult getESignature(AccessRequestContext<GetESignature> context) {
		logger.info(() -> "Executing '" + this.getClass().getSimpleName() + "' - " + context.getRequest().type().getTypeName());

		GetESignature request = context.getRequest();

		ProviderSpecification provider = getProvider(request);
		if (provider instanceof HelloSignSpecification) {
			return GetESignatureExpert.forGetESignatureRequest((HelloSignSpecification) provider, request).process();
		} else if (provider instanceof DocuSignSpecification) {
			return tribefire.extension.docsign.service.expert.docusign.GetESignatureExpert.forGetESignature((DocuSignSpecification) provider, request)
					.process();
		} else {
			throw new IllegalStateException("ProviderSpecification: '" + providerSpecification + "' not supported");
		}
	}

	public ESignatureListResult listESignature(AccessRequestContext<ESignatureList> context) {
		logger.info(() -> "Executing '" + this.getClass().getSimpleName() + "' - " + context.getRequest().type().getTypeName());

		ESignatureList request = context.getRequest();

		ProviderSpecification provider = getProvider(request);
		if (provider instanceof HelloSignSpecification) {
			return ListESignatureExpert.forListESignatureExpert((HelloSignSpecification) provider, request).process();
		} else if (provider instanceof DocuSignSpecification) {
			return tribefire.extension.docsign.service.expert.docusign.ListESignatureExpert
					.forListESignatureExpert((DocuSignSpecification) provider, request).process();
		} else {
			throw new IllegalStateException("ProviderSpecification: '" + providerSpecification + "' not supported");
		}
	}

	public ESignatureResult sendForESignature(AccessRequestContext<SendForESignature> context) {
		logger.info(() -> "Executing '" + this.getClass().getSimpleName() + "' - " + context.getRequest().type().getTypeName());

		SendForESignature request = context.getRequest();

		ProviderSpecification provider = getProvider(request);
		if (provider instanceof HelloSignSpecification) {
			return SendForESignatureExpert.forSendForESignatureExpert((HelloSignSpecification) provider, request).process();
		} else if (provider instanceof DocuSignSpecification) {
			return tribefire.extension.docsign.service.expert.docusign.SendForESignatureExpert
					.forSendForESignatureExpert((DocuSignSpecification) provider, request).process();
		} else {
			throw new IllegalStateException("ProviderSpecification: '" + providerSpecification + "' not supported");
		}
	}

	public ESignatureResult sendESignatureReminder(AccessRequestContext<SendESignatureReminder> context) {
		logger.info(() -> "Executing '" + this.getClass().getSimpleName() + "' - " + context.getRequest().type().getTypeName());

		SendESignatureReminder request = context.getRequest();

		ProviderSpecification provider = getProvider(request);
		if (provider instanceof HelloSignSpecification) {
			return SendESignatureReminderExpert.forSendESignatureReminderExpert((HelloSignSpecification) provider, request).process();
		} else if (provider instanceof DocuSignSpecification) {
			return tribefire.extension.docsign.service.expert.docusign.SendESignatureReminderExpert
					.forSendESignatureReminderExpert((DocuSignSpecification) provider, request).process();
		} else {
			throw new IllegalStateException("ProviderSpecification: '" + providerSpecification + "' not supported");
		}
	}

	public ESignatureResult updateESignature(AccessRequestContext<UpdateESignature> context) {
		logger.info(() -> "Executing '" + this.getClass().getSimpleName() + "' - " + context.getRequest().type().getTypeName());

		UpdateESignature request = context.getRequest();

		ProviderSpecification provider = getProvider(request);
		if (provider instanceof HelloSignSpecification) {
			return UpdateESignatureExpert.forUpdateESignatureExpert((HelloSignSpecification) provider, request).process();
		} else if (provider instanceof DocuSignSpecification) {
			return tribefire.extension.docsign.service.expert.docusign.UpdateESignatureExpert
					.forUpdateESignatureExpert((DocuSignSpecification) provider, request).process();
		} else {
			throw new IllegalStateException("ProviderSpecification: '" + providerSpecification + "' not supported");
		}
	}

	public SuccessResult cancelESignature(AccessRequestContext<CancelESignature> context) {
		logger.info(() -> "Executing '" + this.getClass().getSimpleName() + "' - " + context.getRequest().type().getTypeName());

		CancelESignature request = context.getRequest();

		ProviderSpecification provider = getProvider(request);
		if (provider instanceof HelloSignSpecification) {
			return CancelSignatureRequestExpert.forCancelSignatureRequestExpert((HelloSignSpecification) provider, request).process();
		} else if (provider instanceof DocuSignSpecification) {
			return tribefire.extension.docsign.service.expert.docusign.CancelSignatureRequestExpert
					.forCancelSignatureRequestExpert((DocuSignSpecification) provider, request).process();
		} else {
			throw new IllegalStateException("ProviderSpecification: '" + providerSpecification + "' not supported");
		}
	}

	public SuccessResult removeESignature(AccessRequestContext<RemoveESignature> context) {
		logger.info(() -> "Executing '" + this.getClass().getSimpleName() + "' - " + context.getRequest().type().getTypeName());

		RemoveESignature request = context.getRequest();

		ProviderSpecification provider = getProvider(request);
		if (provider instanceof HelloSignSpecification) {
			return RemoveESignatureExpert.forRemoveESignatureExpert((HelloSignSpecification) provider, request).process();
		} else if (provider instanceof DocuSignSpecification) {
			return tribefire.extension.docsign.service.expert.docusign.RemoveESignatureExpert
					.forRemoveESignatureExpert((DocuSignSpecification) provider, request).process();
		} else {
			throw new IllegalStateException("ProviderSpecification: '" + providerSpecification + "' not supported");
		}
	}

	public ESignatureContentResult downloadESignatureContent(AccessRequestContext<DownloadESignatureContent> context) {
		logger.info(() -> "Executing '" + this.getClass().getSimpleName() + "' - " + context.getRequest().type().getTypeName());

		DownloadESignatureContent request = context.getRequest();

		ProviderSpecification provider = getProvider(request);
		if (provider instanceof HelloSignSpecification) {
			return DownloadESignatureContentExpert.forDownloadESignatureContentExpert((HelloSignSpecification) provider, request).process();
		} else if (provider instanceof DocuSignSpecification) {
			return tribefire.extension.docsign.service.expert.docusign.DownloadESignatureContentExpert
					.forDownloadESignatureContentExpert((DocuSignSpecification) provider, request).process();
		} else {
			throw new IllegalStateException("ProviderSpecification: '" + providerSpecification + "' not supported");
		}
	}

	// -----------------------------------------------------------------------
	// HELPERS
	// -----------------------------------------------------------------------

	private ProviderSpecification getProvider(DocsignRequest request) {
		List<ProviderSpecification> requestProviderSpecifications = request.getProviderSpecifications();
		List<ProviderSpecification> actualProviderSpecifications = new ArrayList<>();
		if (CommonTools.isEmpty(requestProviderSpecifications)) {
			// use the provider specifications from the module
			actualProviderSpecifications.addAll(this.providerSpecification);
		} else {
			// use provider specifications from the request
			actualProviderSpecifications.addAll(requestProviderSpecifications);
		}

		if (actualProviderSpecifications.isEmpty()) {
			throw new IllegalArgumentException("At least one provider specification needs to be set. Either per request or on the processor");
		}

		for (ProviderSpecification provider : actualProviderSpecifications) {
			if (provider instanceof HelloSignSpecification) {
				return provider;
				// return HelloSignExpert.forContext((HelloSignSpecification) provider);
			} else if (provider instanceof DocuSignSpecification) {
				return provider;
				// return DocuSignExpert.forContext((DocuSignSpecification) provider);
			} else {
				throw new IllegalStateException("ProviderSpecification: '" + providerSpecification + "' not supported");
			}
		}
		return null;
	}

	// -----------------------------------------------------------------------
	// FOR NOTIFICATIONS
	// -----------------------------------------------------------------------

	protected <T extends HasNotifications> ResponseBuilder<T> responseBuilder(EntityType<T> responseType, DocsignRequest request) {

		return new ResponseBuilder<T>() {
			private List<Notification> localNotifications = new ArrayList<>();
			private boolean ignoreCollectedNotifications = false;
			private Consumer<T> enricher;
			private NotificationsBuilder notificationsBuilder = null;
			private List<Notification> notifications = new ArrayList<>();

			@Override
			public ResponseBuilder<T> notifications(Supplier<List<Notification>> notificationsSupplier) {
				notifications = notificationsSupplier.get();
				return this;
			}
			@Override
			public ResponseBuilder<T> notifications(Consumer<NotificationsBuilder> consumer) {
				this.notificationsBuilder = Notifications.build();
				consumer.accept(notificationsBuilder);
				return this;
			}

			@Override
			public ResponseBuilder<T> ignoreCollectedNotifications() {
				this.ignoreCollectedNotifications = true;
				return this;
			}

			@Override
			public ResponseBuilder<T> responseEnricher(Consumer<T> enricher) {
				this.enricher = enricher;
				return this;
			}

			@Override
			public T build() {

				T response = responseType.create();
				if (enricher != null) {
					this.enricher.accept(response);
				}
				if (request.getSendNotifications()) {
					response.setNotifications(localNotifications);
					if (!ignoreCollectedNotifications) {

						if (notificationsBuilder != null) {
							notifications.addAll(notificationsBuilder.list());
						}

						Collections.reverse(notifications);
						response.getNotifications().addAll(notifications);
					}
				}
				return response;
			}
		};

	}

	protected <T extends HasNotifications> T prepareSimpleNotification(EntityType<T> responseEntityType, DocsignRequest request, Level level,
			String msg) {

		//@formatter:off
		T result = responseBuilder(responseEntityType, request)
				.notifications(builder -> 
					builder	
					.add()
						.message()
							.level(level)
							.message(msg)
						.close()
					.close()
				).build();
		//@formatter:on
		return result;
	}

	// -----------------------------------------------------------------------
	// GETTER & SETTER
	// -----------------------------------------------------------------------

}
