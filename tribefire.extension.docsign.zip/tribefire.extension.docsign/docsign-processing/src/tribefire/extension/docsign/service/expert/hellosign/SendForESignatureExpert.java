// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.service.expert.hellosign;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import org.apache.commons.lang3.StringUtils;

import com.braintribe.logging.Logger;
import com.braintribe.utils.FileTools;
import com.hellosign.sdk.HelloSignClient;
import com.hellosign.sdk.HelloSignException;
import com.hellosign.sdk.resource.SignatureRequest;
import com.hellosign.sdk.resource.support.FormField;
import com.hellosign.sdk.resource.support.types.FieldType;

import tribefire.extension.docsign.model.deployment.repository.configuration.HelloSignSpecification;
import tribefire.extension.docsign.model.service.ESignatureResult;
import tribefire.extension.docsign.model.service.SendForESignature;

public class SendForESignatureExpert extends HelloSignExpert<SendForESignature, ESignatureResult> {

	private static final Logger logger = Logger.getLogger(SendForESignatureExpert.class);

	@Override
	public ESignatureResult process() {
		SignatureRequest signatureRequest = new SignatureRequest();
		// using TEST mode for the development
		signatureRequest.setTestMode(this.testMode);

		signatureRequest.setTitle(request.getTitle());
		signatureRequest.setSubject(request.getSubject());
		signatureRequest.setMessage(request.getMessage());

		if (request.getSigners() != null && !request.getSigners().isEmpty()) {
			request.getSigners().stream().forEach((signatore) -> {
				try {
					signatureRequest.addSigner(signatore.getEmailAddress(), signatore.getName());
				} catch (HelloSignException e) {
					logger.error("Error adding HelloSign signer!", e);
					throw new IllegalArgumentException(e.getMessage());
				}
			});
		} else {
			throw new IllegalArgumentException("At least one signer must exist!");
		}

		if (request.getCCs() != null && !request.getCCs().isEmpty()) {
			request.getCCs().stream().forEach((cc) -> signatureRequest.addCC(cc.getEmailAddress()));
		}

		if (request.getFiles() != null && !request.getFiles().isEmpty()) {
			request.getFiles().stream().forEach((file) -> {
				try (InputStream in = file.openStream()) {
					Path filePath = Files.createTempFile(FileTools.getNameWithoutExtension(file.getName()), FileTools.getExtension(file.getName()));
					Files.copy(in, filePath, StandardCopyOption.REPLACE_EXISTING);

					signatureRequest.addFile(filePath.toFile());

				} catch (IOException | HelloSignException e) {
					logger.error("Error adding HelloSign document!", e);
					throw new IllegalArgumentException(e.getMessage());
				}
			});
		} else {
			throw new IllegalArgumentException("At least one document must exist!");
		}

		if (request.getFormFields() != null && !request.getFormFields().isEmpty()) {
			request.getFormFields().stream().forEach((formField) -> {
				FormField helloSignFormField = new FormField(FieldType.getEnum(formField.getType()), formField.getName(), formField.getSigner(),
						formField.getX(), formField.getY(), formField.getHeight(), formField.getWidth(), formField.getPage());
				helloSignFormField.setIsRequired(formField.getRequired());
				if (StringUtils.isNotBlank(formField.getValidationType())) {
					helloSignFormField.setValidationType(getFormFieldValidatioTypeEnum(formField.getValidationType()));
				}
				try {
					signatureRequest.getDocuments().get(formField.getDocument()).addFormField(helloSignFormField);
				} catch (HelloSignException e) {
					logger.error("Error adding HelloSign document form field!", e);
					throw new IllegalArgumentException(e.getMessage());
				}
			});
		}

		try {
			SignatureRequest response = client.sendSignatureRequest(signatureRequest);
			//@formatter:off
			return responseBuilder(ESignatureResult.T, request)
				.responseEnricher(r -> {
					toSignatureRequestResult(response, r);
				})
				.build();
			//@formatter:on
		} catch (HelloSignException e) {
			logger.error("Error executing HelloSign SEND request!", e);
			throw new IllegalArgumentException(e.getMessage());
		}
	}

	// ***************************************************************************************************
	// Initialization
	// ***************************************************************************************************

	public static SendForESignatureExpert forSendForESignatureExpert(HelloSignSpecification provider, SendForESignature request) {
		return createExpert(SendForESignatureExpert::new, (expert) -> {
			expert.setClient(new HelloSignClient(provider.getApiKey()));
			expert.setTestMode(!provider.getLegallyBinding());
			expert.setRequest(request);
		});
	}

}
