// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.service.expert.hellosign;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.hellosign.sdk.HelloSignClient;
import com.hellosign.sdk.resource.SignatureRequest;
import com.hellosign.sdk.resource.support.types.ValidationType;

import tribefire.extension.docsign.model.SignerResponse;
import tribefire.extension.docsign.model.service.DocsignRequest;
import tribefire.extension.docsign.model.service.DocsignResult;
import tribefire.extension.docsign.model.service.ESignatureResult;
import tribefire.extension.docsign.service.expert.BaseExpert;

public abstract class HelloSignExpert<S extends DocsignRequest, T extends DocsignResult> extends BaseExpert<S, T> {

	protected HelloSignClient client;

	public void setClient(HelloSignClient client) {
		this.client = client;
	}

	// -----------------------------------------------------------------------
	// HELPERS
	// -----------------------------------------------------------------------

	protected void toSignatureRequestResult(SignatureRequest signatureRequest, ESignatureResult signatureResult) {
		signatureResult.setESignatureId(signatureRequest.getId());
		signatureResult.setCreatedAt(new Date(Long.valueOf(signatureRequest.getJSONObject().getLong("created_at")) * 1000L));

		signatureResult.setIsComplete(signatureRequest.isComplete());

		signatureResult.setCCs(signatureRequest.getCCs());
		List<SignerResponse> signatures = new ArrayList<SignerResponse>();
		signatureRequest.getSignatures().stream().forEach(signature -> {
			SignerResponse signatureResponse = SignerResponse.T.create();
			signatureResponse.setName(signature.getName());
			signatureResponse.setSignatureId(signature.getId());
			signatureResponse.setStatusCode(signature.getStatusString());
			signatureResponse.setLastViewedAt(signature.getLastViewed());
			signatureResponse.setSignedAt(signature.getDateSigned());
			signatureResponse.setEmail(signature.getEmail());
			signatureResponse.setLastRemindedAt(signature.getLastReminded());
			signatureResponse.setDeclineReason(signature.getDeclineReason());
			signatureResponse.setOrder(signature.getOrder());
			signatures.add(signatureResponse);
		});
		signatureResult.setSigners(signatures);

		signatureResult.setTitle(signatureRequest.getTitle());
		signatureResult.setSubject(signatureRequest.getSubject());
		signatureResult.setMessage(signatureRequest.getMessage());

		signatureResult.setDetailsUrl(signatureRequest.getDetailsUrl());
	}

	protected ValidationType getFormFieldValidatioTypeEnum(String string) {
		for (ValidationType type : ValidationType.values()) {
			if (type.name().equals(string)) {
				return type;
			}
		}
		throw new IllegalArgumentException();
	}
}
