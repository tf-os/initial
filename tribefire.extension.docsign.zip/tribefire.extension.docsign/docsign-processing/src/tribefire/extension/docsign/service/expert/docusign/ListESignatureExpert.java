// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.service.expert.docusign;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.braintribe.logging.Logger;
import com.docusign.esign.api.EnvelopesApi.ListStatusChangesOptions;
import com.docusign.esign.client.ApiException;
import com.docusign.esign.model.EnvelopesInformation;

import tribefire.extension.docsign.model.deployment.repository.configuration.DocuSignSpecification;
import tribefire.extension.docsign.model.service.ESignatureList;
import tribefire.extension.docsign.model.service.ESignatureListResult;
import tribefire.extension.docsign.model.service.ESignatureResult;

public class ListESignatureExpert extends DocuSignExpert<ESignatureList, ESignatureListResult> {

	private static final Logger logger = Logger.getLogger(ListESignatureExpert.class);

	@Override
	public ESignatureListResult process() {
		try {
			ListStatusChangesOptions options = envelopesApi.new ListStatusChangesOptions();
			options.setFromDate(new SimpleDateFormat("yyyy/MM/dd").format(request.getFromDate()));
			options.setCount(request.getPageSize().toString());
			options.setStartPosition(Integer.toString((request.getPage() - 1) * request.getPageSize()));
			options.setFolderTypes("normal,inbox,sentitems");
			options.setInclude("recipients");

			EnvelopesInformation envelopes = envelopesApi.listStatusChanges(accountId, options);

			//@formatter:off
			return responseBuilder(ESignatureListResult.T, request)
				.responseEnricher(r -> {
					List<ESignatureResult> signatureRequests = new ArrayList<ESignatureResult>();
					envelopes.getEnvelopes().stream().forEach(envelope -> {
						ESignatureResult signaturetResult = ESignatureResult.T.create();
						toSignatureRequestResult(envelope, signaturetResult);
						signatureRequests.add(signaturetResult);
					});
					r.setSignatureRequests(signatureRequests);
					
					r.setPage(request.getPage());
					r.setPageSize(request.getPageSize());
					r.setNumPages((int) Math.ceil(Double.valueOf(envelopes.getTotalSetSize()).doubleValue() / Double.valueOf(envelopes.getResultSetSize()).doubleValue()));
					r.setNumResults(Integer.valueOf(envelopes.getTotalSetSize()));
				})
				.build();
			//@formatter:on
		} catch (IllegalArgumentException | ApiException e) {
			logger.error("Error executing DocuSign LIST request!", e);
			throw new IllegalArgumentException(e.getMessage());
		}
	}

	// ***************************************************************************************************
	// Initialization
	// ***************************************************************************************************

	public static ListESignatureExpert forListESignatureExpert(DocuSignSpecification provider, ESignatureList request) {
		return createExpert(ListESignatureExpert::new, (expert) -> {
			try {
				configureExpert(expert, provider.getClientId(), provider.getUserId(), provider.getRsaKey(), provider.getLegallyBinding());
				expert.setRequest(request);
			} catch (ApiException | IOException e) {
				logger.error("Error configuring DocuSign expert!", e);
				throw new IllegalArgumentException(e.getMessage());
			}
		});
	}

}
