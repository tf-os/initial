// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.service.expert.docusign;

import java.io.IOException;
import java.util.ArrayList;

import com.braintribe.logging.Logger;
import com.docusign.esign.api.EnvelopesApi.GetEnvelopeOptions;
import com.docusign.esign.api.EnvelopesApi.UpdateRecipientsOptions;
import com.docusign.esign.client.ApiException;
import com.docusign.esign.model.Envelope;
import com.docusign.esign.model.Recipients;
import com.docusign.esign.model.RecipientsUpdateSummary;
import com.docusign.esign.model.Signer;

import tribefire.extension.docsign.model.deployment.repository.configuration.DocuSignSpecification;
import tribefire.extension.docsign.model.service.ESignatureResult;
import tribefire.extension.docsign.model.service.UpdateESignature;

public class UpdateESignatureExpert extends DocuSignExpert<UpdateESignature, ESignatureResult> {

	private static final Logger logger = Logger.getLogger(UpdateESignatureExpert.class);

	@Override
	public ESignatureResult process() {
		try {
			UpdateRecipientsOptions updateRecipientsOptions = envelopesApi.new UpdateRecipientsOptions();
			updateRecipientsOptions.setResendEnvelope("true");

			Signer signer = new Signer();
			signer.setEmail(request.getEmail());
			signer.setName(request.getName());
			signer.setRecipientId(request.getSignatureId());

			Recipients recipients = new Recipients();
			recipients.setSigners(new ArrayList<Signer>());
			recipients.getSigners().add(signer);

			RecipientsUpdateSummary recipientsUpdateSummary = envelopesApi.updateRecipients(accountId, request.getESignatureId(), recipients,
					updateRecipientsOptions);

			if (recipientsUpdateSummary.getRecipientUpdateResults() != null && !recipientsUpdateSummary.getRecipientUpdateResults().isEmpty()
					&& recipientsUpdateSummary.getRecipientUpdateResults().get(0) != null
					&& recipientsUpdateSummary.getRecipientUpdateResults().get(0).getErrorDetails() != null) {
				throw new IllegalArgumentException(recipientsUpdateSummary.getRecipientUpdateResults().get(0).getErrorDetails().getMessage());
			}

			GetEnvelopeOptions options = envelopesApi.new GetEnvelopeOptions();
			options.setInclude("recipients");

			Envelope envelope = envelopesApi.getEnvelope(accountId, request.getESignatureId(), options);

			//@formatter:off
			return responseBuilder(ESignatureResult.T, request)
				.responseEnricher(r -> {
					toSignatureRequestResult(envelope, r);
				})
				.build();
			//@formatter:on
		} catch (IllegalArgumentException | ApiException e) {
			logger.error("Error executing DocuSign UPDATE request!", e);
			throw new IllegalArgumentException(e.getMessage());
		}
	}

	// ***************************************************************************************************
	// Initialization
	// ***************************************************************************************************

	public static UpdateESignatureExpert forUpdateESignatureExpert(DocuSignSpecification provider, UpdateESignature request) {
		return createExpert(UpdateESignatureExpert::new, (expert) -> {
			try {
				configureExpert(expert, provider.getClientId(), provider.getUserId(), provider.getRsaKey(), provider.getLegallyBinding());
				expert.setRequest(request);
			} catch (ApiException | IOException e) {
				logger.error("Error configuring DocuSign expert!", e);
				throw new IllegalArgumentException(e.getMessage());
			}
		});
	}

}
