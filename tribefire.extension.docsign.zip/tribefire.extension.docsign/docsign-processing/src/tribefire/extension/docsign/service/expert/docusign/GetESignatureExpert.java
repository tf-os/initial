// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.service.expert.docusign;

import java.io.IOException;

import com.braintribe.logging.Logger;
import com.docusign.esign.api.EnvelopesApi.GetEnvelopeOptions;
import com.docusign.esign.client.ApiException;
import com.docusign.esign.model.Envelope;

import tribefire.extension.docsign.model.deployment.repository.configuration.DocuSignSpecification;
import tribefire.extension.docsign.model.service.ESignatureResult;
import tribefire.extension.docsign.model.service.GetESignature;

public class GetESignatureExpert extends DocuSignExpert<GetESignature, ESignatureResult> {

	private static final Logger logger = Logger.getLogger(GetESignatureExpert.class);

	@Override
	public ESignatureResult process() {
		try {
			GetEnvelopeOptions options = envelopesApi.new GetEnvelopeOptions();
			options.setInclude("recipients");

			Envelope envelope = envelopesApi.getEnvelope(accountId, request.getESignatureId(), options);

			//@formatter:off
			return responseBuilder(ESignatureResult.T, request)
				.responseEnricher(r -> {
					toSignatureRequestResult(envelope, r);
				})
				.build();
			//@formatter:on
		} catch (IllegalArgumentException | ApiException e) {
			logger.error("Error executing DocuSign GET request!", e);
			throw new IllegalArgumentException(e.getMessage());
		}
	}

	// ***************************************************************************************************
	// Initialization
	// ***************************************************************************************************

	public static GetESignatureExpert forGetESignature(DocuSignSpecification provider, GetESignature request) {
		return createExpert(GetESignatureExpert::new, (expert) -> {
			try {
				configureExpert(expert, provider.getClientId(), provider.getUserId(), provider.getRsaKey(), provider.getLegallyBinding());
				expert.setRequest(request);
			} catch (ApiException | IOException e) {
				logger.error("Error configuring DocuSign expert!", e);
				throw new IllegalArgumentException(e.getMessage());
			}
		});
	}

}
