// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.service.expert.hellosign;

import com.braintribe.logging.Logger;
import com.hellosign.sdk.HelloSignClient;
import com.hellosign.sdk.HelloSignException;
import com.hellosign.sdk.resource.SignatureRequest;

import tribefire.extension.docsign.model.deployment.repository.configuration.HelloSignSpecification;
import tribefire.extension.docsign.model.service.ESignatureResult;
import tribefire.extension.docsign.model.service.UpdateESignature;

public class UpdateESignatureExpert extends HelloSignExpert<UpdateESignature, ESignatureResult> {

	private static final Logger logger = Logger.getLogger(UpdateESignatureExpert.class);

	@Override
	public ESignatureResult process() {
		try {
			SignatureRequest signatureRequest = client.updateSignatureRequest(request.getESignatureId(), request.getSignatureId(),
					request.getEmail());
			//@formatter:off
			return responseBuilder(ESignatureResult.T, request)
				.responseEnricher(r -> {
					toSignatureRequestResult(signatureRequest, r);
				})
				.build();
			//@formatter:on
		} catch (HelloSignException e) {
			logger.error("Error executing HelloSign UPDATE request!", e);
			throw new IllegalArgumentException(e.getMessage());
		}
	}

	// ***************************************************************************************************
	// Initialization
	// ***************************************************************************************************

	public static UpdateESignatureExpert forUpdateESignatureExpert(HelloSignSpecification provider, UpdateESignature request) {
		return createExpert(UpdateESignatureExpert::new, (expert) -> {
			expert.setClient(new HelloSignClient(provider.getApiKey()));
			expert.setRequest(request);
		});
	}

}
