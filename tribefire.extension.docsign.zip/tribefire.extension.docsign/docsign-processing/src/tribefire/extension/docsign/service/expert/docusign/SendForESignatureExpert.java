// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.service.expert.docusign;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import com.braintribe.logging.Logger;
import com.braintribe.utils.FileTools;
import com.docusign.esign.api.EnvelopesApi.GetEnvelopeOptions;
import com.docusign.esign.client.ApiException;
import com.docusign.esign.model.CarbonCopy;
import com.docusign.esign.model.Document;
import com.docusign.esign.model.Envelope;
import com.docusign.esign.model.EnvelopeDefinition;
import com.docusign.esign.model.EnvelopeSummary;
import com.docusign.esign.model.Recipients;
import com.docusign.esign.model.Signer;

import tribefire.extension.docsign.model.deployment.repository.configuration.DocuSignSpecification;
import tribefire.extension.docsign.model.service.ESignatureResult;
import tribefire.extension.docsign.model.service.SendForESignature;

public class SendForESignatureExpert extends DocuSignExpert<SendForESignature, ESignatureResult> {

	private static final Logger logger = Logger.getLogger(SendForESignatureExpert.class);

	@Override
	public ESignatureResult process() {
		EnvelopeDefinition envDef = new EnvelopeDefinition();
		envDef.setEmailSubject(request.getSubject());
		envDef.setEmailBlurb(request.getMessage());

		envDef.setRecipients(new Recipients());
		envDef.getRecipients().setSigners(new ArrayList<Signer>());

		AtomicInteger recipientsCounter = new AtomicInteger();
		if (request.getCCs() != null && !request.getCCs().isEmpty()) {
			envDef.getRecipients().setCarbonCopies(new ArrayList<CarbonCopy>());
			request.getCCs().stream().forEach((cc) -> {
				CarbonCopy carbonCopy = new CarbonCopy();
				carbonCopy.setEmail(cc.getEmailAddress());
				carbonCopy.setName(cc.getName());
				carbonCopy.setRecipientId(Integer.toString(recipientsCounter.incrementAndGet()));
				carbonCopy.setRoutingOrder("1");
				envDef.getRecipients().getCarbonCopies().add(carbonCopy);
			});
		}

		if (request.getSigners() != null && !request.getSigners().isEmpty()) {
			request.getSigners().stream().forEach((signatore) -> {
				Signer signer = new Signer();
				signer.setEmail(signatore.getEmailAddress());
				signer.setName(signatore.getName());
				signer.setRecipientId(Integer.toString(recipientsCounter.incrementAndGet()));
				signer.setRoutingOrder("2");
				envDef.getRecipients().getSigners().add(signer);
			});
		} else {
			throw new IllegalArgumentException("At least one signer must exist!");
		}

		AtomicInteger filesCounter = new AtomicInteger();
		if (request.getFiles() != null && !request.getFiles().isEmpty()) {
			List<Document> docs = new ArrayList<Document>();
			request.getFiles().stream().forEach((file) -> {
				try (InputStream in = file.openStream()) {
					Path filePath = Files.createTempFile(FileTools.getNameWithoutExtension(file.getName()), FileTools.getExtension(file.getName()));
					Files.copy(in, filePath, StandardCopyOption.REPLACE_EXISTING);

					Document doc = new Document();
					String base64Doc = Base64.getEncoder().encodeToString(Files.readAllBytes(filePath));
					doc.setDocumentBase64(base64Doc);
					doc.setName(file.getName());
					doc.setDocumentId(Integer.toString(filesCounter.incrementAndGet()));
					docs.add(doc);
				} catch (IOException e) {
					logger.error("Error adding DocuSign document!", e);
					throw new IllegalArgumentException(e.getMessage());
				}
			});
			envDef.setDocuments(docs);
		} else {
			throw new IllegalArgumentException("At least one document must exist!");
		}

		envDef.setStatus("sent");

		try {
			EnvelopeSummary envelopeSummary = envelopesApi.createEnvelope(accountId, envDef);

			GetEnvelopeOptions options = envelopesApi.new GetEnvelopeOptions();
			options.setInclude("recipients");

			Envelope envelope = envelopesApi.getEnvelope(accountId, envelopeSummary.getEnvelopeId(), options);

			//@formatter:off
			return responseBuilder(ESignatureResult.T, request)
				.responseEnricher(r -> {
					toSignatureRequestResult(envelope, r);
				})
				.build();
			//@formatter:on
		} catch (IllegalArgumentException | ApiException e) {
			logger.error("Error executing DocuSign SEND request!", e);
			throw new IllegalArgumentException(e.getMessage());
		}
	}

	// ***************************************************************************************************
	// Initialization
	// ***************************************************************************************************

	public static SendForESignatureExpert forSendForESignatureExpert(DocuSignSpecification provider, SendForESignature request) {
		return createExpert(SendForESignatureExpert::new, (expert) -> {
			try {
				configureExpert(expert, provider.getClientId(), provider.getUserId(), provider.getRsaKey(), provider.getLegallyBinding());
				expert.setRequest(request);
			} catch (ApiException | IOException e) {
				logger.error("Error configuring DocuSign expert!", e);
				throw new IllegalArgumentException(e.getMessage());
			}
		});
	}

}
