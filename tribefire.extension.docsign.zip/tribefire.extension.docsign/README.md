# tribefire.extension.docsign

```jinni.sh setup-local-tomcat-platform --setupDependency tribefire.extension.docsign:docsign-setup#1.0 --installationPath /opt/tf-setups/docsign --debugProject tribefire.extension.docsign:docsign-debug : options --verbose```