// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.integration.test.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.UUID;

import org.junit.FixMethodOrder;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.braintribe.model.processing.session.api.resource.ResourceCreateBuilder;
import com.braintribe.model.resource.Resource;
import com.braintribe.testing.category.VerySlow;
import com.braintribe.utils.FileTools;
import com.braintribe.utils.lcd.CollectionTools2;

import tribefire.extension.docsign.integration.test.AbstractDocsignTest;
import tribefire.extension.docsign.integration.test.providerconfiguration.TestProviderConfiguration;
import tribefire.extension.docsign.model.HelloSignFormField;
import tribefire.extension.docsign.model.Recipient;
import tribefire.extension.docsign.model.SignerResponse;
import tribefire.extension.docsign.model.deployment.repository.configuration.HelloSignSpecification;
import tribefire.extension.docsign.model.deployment.repository.configuration.ProviderSpecification;
import tribefire.extension.docsign.model.service.CancelESignature;
import tribefire.extension.docsign.model.service.DocsignRequest;
import tribefire.extension.docsign.model.service.DownloadESignatureContent;
import tribefire.extension.docsign.model.service.ESignatureContentResult;
import tribefire.extension.docsign.model.service.ESignatureList;
import tribefire.extension.docsign.model.service.ESignatureListResult;
import tribefire.extension.docsign.model.service.ESignatureResult;
import tribefire.extension.docsign.model.service.GetESignature;
import tribefire.extension.docsign.model.service.RemoveESignature;
import tribefire.extension.docsign.model.service.SendESignatureReminder;
import tribefire.extension.docsign.model.service.SendForESignature;
import tribefire.extension.docsign.model.service.SuccessResult;
import tribefire.extension.docsign.model.service.UpdateESignature;

@RunWith(Parameterized.class)
@Category(VerySlow.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ServiceDocsignTest extends AbstractDocsignTest {

	@Parameters(name = "{index}: {0}")
	public static Collection<Object[]> data() throws Exception {
		List<Object[]> providerSpecifications = new ArrayList<>();
		Object[] helloSignSpecification = { TestProviderConfiguration.helloSign() };
		Object[] docuSignSpecification = { TestProviderConfiguration.docuSign() };
		providerSpecifications.add(helloSignSpecification);
		providerSpecifications.add(docuSignSpecification);

		return providerSpecifications;
	}

	// Prerequisite: Must have a fully signed document and use it's signatureRequestId
	private static String helloSignSignedSignatureRequestId = "fec4584062cb523a1b49d3a5b9fd2ba28f0e6c40";
	private static String docuSignSignedSignatureRequestId = "47da7e43-f1df-4dd3-9e83-bace0caad871";

	// can't be updated
	private static String signatureRequestIdNoFormFields;
	// can be updated
	private static String signatureRequestIdWithFormFields;
	private static String signatureId;

	private static String uuid = UUID.randomUUID().toString();

	private String testUserName = "Test User";
	private String testUserEmail = "test.user@document.one";
	private String testUpdateUserEmail = "test.update.user@document.one";
	private String ccName = "CC";
	private String ccEmail = "cc@document.one";
	private String invalidUserEmail = "test.user#document.one";
	private String noUserEmail = "no.user@document.one";

	private ProviderSpecification providerSpecification;

	public ServiceDocsignTest(ProviderSpecification providerSpecification) {
		this.providerSpecification = providerSpecification;
	}

	// -----------------------------------------------------------------------
	// TESTS
	// -----------------------------------------------------------------------

	@Test
	public void test001_sendSignatureRequestNoFormFields() throws Exception {
		SendForESignature request = SendForESignature.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		uuid = UUID.randomUUID().toString();

		request.setTitle("TestTitle-" + uuid);
		request.setSubject("TestSubject-" + uuid);
		request.setMessage("TestMessage-" + uuid);

		Recipient signer = Recipient.T.create();
		signer.setName(testUserName);
		signer.setEmailAddress(testUserEmail);
		List<Recipient> signers = new ArrayList<Recipient>();
		signers.add(signer);
		request.setSigners(signers);

		Recipient cc = Recipient.T.create();
		cc.setName(ccName);
		cc.setEmailAddress(ccEmail);
		List<Recipient> cCs = new ArrayList<Recipient>();
		cCs.add(cc);
		request.setCCs(cCs);

		ResourceCreateBuilder resourceBuilder = cortexSession.resources().create().name(pdf.getName());
		Resource resource = FileTools.read(pdf).fromInputStream(resourceBuilder::store);

		List<Resource> files = new ArrayList<Resource>();
		files.add(resource);
		request.setFiles(files);

		ESignatureResult result = (ESignatureResult) request.eval(cortexSession).get();
		signatureRequestIdNoFormFields = result.getESignatureId();

		assertResult(result);
	}

	@Test
	public void test002_sendSignatureRequestWithFormFields() throws Exception {
		SendForESignature request = SendForESignature.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		String uuid = UUID.randomUUID().toString();

		request.setTitle("TestTitle-" + uuid);
		request.setSubject("TestSubject-" + uuid);
		request.setMessage("TestMessage-" + uuid);

		Recipient signer = Recipient.T.create();
		signer.setName(testUserName);
		signer.setEmailAddress(testUserEmail);
		List<Recipient> signers = new ArrayList<Recipient>();
		signers.add(signer);
		request.setSigners(signers);

		Recipient cc = Recipient.T.create();
		cc.setName(ccName);
		cc.setEmailAddress(ccEmail);
		List<Recipient> cCs = new ArrayList<Recipient>();
		cCs.add(cc);
		request.setCCs(cCs);

		ResourceCreateBuilder resourceBuilder = cortexSession.resources().create().name(pdf.getName());
		Resource resource = FileTools.read(pdf).fromInputStream(resourceBuilder::store);

		List<Resource> files = new ArrayList<Resource>();
		files.add(resource);
		request.setFiles(files);

		HelloSignFormField formField = HelloSignFormField.T.create();
		formField.setType("signature");
		formField.setDocument(0);
		formField.setPage(1);
		formField.setSigner(0);
		formField.setX(100);
		formField.setY(250);
		formField.setHeight(25);
		formField.setWidth(150);
		formField.setRequired(true);

		List<HelloSignFormField> formFields = new ArrayList<HelloSignFormField>();
		formFields.add(formField);
		request.setFormFields(formFields);

		ESignatureResult result = (ESignatureResult) request.eval(cortexSession).get();
		signatureRequestIdWithFormFields = result.getESignatureId();
		signatureId = result.getSigners().get(0).getSignatureId();

		assertResult(result);
	}

	@Test
	public void test003_sendSignatureRequestEmptySigners() throws Exception {
		SendForESignature request = SendForESignature.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		assertException(IllegalArgumentException.class, request, "At least one signer must exist!");
	}

	@Test
	public void test004_sendSignatureRequestEmptyDocuments() throws Exception {
		SendForESignature request = SendForESignature.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setTitle("TestTitle-" + uuid);
		request.setSubject("TestSubject-" + uuid);
		request.setMessage("TestMessage-" + uuid);

		Recipient signer = Recipient.T.create();
		signer.setName(testUserName);
		signer.setEmailAddress(testUserEmail);
		List<Recipient> signers = new ArrayList<Recipient>();
		signers.add(signer);
		request.setSigners(signers);

		assertException(IllegalArgumentException.class, request, "At least one document must exist!");
	}

	@Test
	public void test005_sendSignatureRequestInvalidSigner() throws Exception {
		SendForESignature request = SendForESignature.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setTitle("TestTitle-" + uuid);
		request.setSubject("TestSubject-" + uuid);
		request.setMessage("TestMessage-" + uuid);

		Recipient signer = Recipient.T.create();
		signer.setName(testUserName);
		signer.setEmailAddress(invalidUserEmail);
		List<Recipient> signers = new ArrayList<Recipient>();
		signers.add(signer);
		request.setSigners(signers);

		ResourceCreateBuilder resourceBuilder = cortexSession.resources().create().name(pdf.getName());
		Resource resource = FileTools.read(pdf).fromInputStream(resourceBuilder::store);

		List<Resource> files = new ArrayList<Resource>();
		files.add(resource);
		request.setFiles(files);

		assertException(IllegalArgumentException.class, request,
				providerSpecification instanceof HelloSignSpecification ? "Invalid email address:" : "INVALID_EMAIL_ADDRESS_FOR_RECIPIENT");
	}

	@Ignore
	@Test
	public void test006_sendSignatureRequestInvalidFormFields() throws Exception {
		SendForESignature request = SendForESignature.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		uuid = UUID.randomUUID().toString();

		request.setTitle("TestTitle-" + uuid);
		request.setSubject("TestSubject-" + uuid);
		request.setMessage("TestMessage-" + uuid);

		Recipient signer = Recipient.T.create();
		signer.setName(testUserName);
		signer.setEmailAddress(testUserEmail);
		List<Recipient> signers = new ArrayList<Recipient>();
		signers.add(signer);
		request.setSigners(signers);

		Recipient cc = Recipient.T.create();
		cc.setName(ccName);
		cc.setEmailAddress(ccEmail);
		List<Recipient> cCs = new ArrayList<Recipient>();
		cCs.add(cc);
		request.setCCs(cCs);

		ResourceCreateBuilder resourceBuilder = cortexSession.resources().create().name(pdf.getName());
		Resource resource = FileTools.read(pdf).fromInputStream(resourceBuilder::store);

		List<Resource> files = new ArrayList<Resource>();
		files.add(resource);
		request.setFiles(files);

		HelloSignFormField formField = HelloSignFormField.T.create();
		formField.setType("signature");
		formField.setDocument(0);
		formField.setPage(0);
		formField.setSigner(0);
		formField.setX(100);
		formField.setY(250);
		formField.setHeight(25);
		formField.setWidth(150);
		formField.setRequired(true);

		List<HelloSignFormField> formFields = new ArrayList<HelloSignFormField>();
		formFields.add(formField);
		request.setFormFields(formFields);

		assertException(IllegalArgumentException.class, request, "exceeds document length");
	}

	@Test
	public void test007_listSignatureRequests() throws Exception {
		ESignatureList request = ESignatureList.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		ESignatureListResult resultList = (ESignatureListResult) request.eval(cortexSession).get();

		assertResultList(resultList, 1, 20, true);
	}

	@Test
	public void test008_listSignatureRequestsPageSize() throws Exception {
		ESignatureList request = ESignatureList.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setPageSize(1);

		ESignatureListResult resultList = (ESignatureListResult) request.eval(cortexSession).get();

		assertResultList(resultList, 1, 1, true);
	}

	@Test
	public void test009_listSignatureRequestsQuery() throws Exception {
		ESignatureList request = ESignatureList.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));
		request.setQuery("title:TestTitle-* AND subject:TestSubject-*");

		ESignatureListResult resultList = (ESignatureListResult) request.eval(cortexSession).get();

		assertResultList(resultList, 1, 20, true);
	}

	@Ignore
	@Test
	public void test010_listSignatureRequestsQueryNoResults() throws Exception {
		ESignatureList request = ESignatureList.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setQuery("title:no-result");

		ESignatureListResult resultList = (ESignatureListResult) request.eval(cortexSession).get();

		assertResultList(resultList, 1, 20, false);
	}

	@Test
	public void test011_getSignatureRequest() throws Exception {
		GetESignature request = GetESignature.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setESignatureId(signatureRequestIdNoFormFields);

		ESignatureResult result = (ESignatureResult) request.eval(cortexSession).get();

		assertResult(result);
		if (providerSpecification instanceof HelloSignSpecification) {
			assertThat(result.getTitle()).isNotBlank();
		}
		assertThat(result.getSubject()).isNotBlank();
		assertThat(result.getMessage()).isNotBlank();
	}

	@Test
	public void test012_getSignatureRequestNoRequest() throws Exception {
		GetESignature request = GetESignature.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setESignatureId("no-result");

		assertException(IllegalArgumentException.class, request,
				providerSpecification instanceof HelloSignSpecification ? "Not found" : "Invalid value specified for envelopeId");
	}

	@Test
	public void test013_sendReminderSignatureRequest() throws Exception {
		SendESignatureReminder request = SendESignatureReminder.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setESignatureId(signatureRequestIdNoFormFields);
		request.setEmailAddress(testUserEmail);

		ESignatureResult result = (ESignatureResult) request.eval(cortexSession).get();

		assertResult(result);
		if (providerSpecification instanceof HelloSignSpecification) {
			//@formatter:off
			result.getSigners().stream()
					.filter(signature -> testUserEmail.equals(signature.getEmail()))
					.forEach(signature -> assertThat(signature.getLastRemindedAt()).isNotNull());
			//@formatter:on
		}
	}

	@Test
	public void test014_sendReminderSignatureRequestNoRequest() throws Exception {
		SendESignatureReminder request = SendESignatureReminder.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setESignatureId("no-result");
		request.setEmailAddress(testUserEmail);

		assertException(IllegalArgumentException.class, request,
				providerSpecification instanceof HelloSignSpecification ? "Not found" : "Invalid value specified for envelopeId");
	}

	@Test
	public void test015_sendReminderSignatureRequestNoSigner() throws Exception {
		SendESignatureReminder request = SendESignatureReminder.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setESignatureId(signatureRequestIdNoFormFields);
		request.setEmailAddress(noUserEmail);

		assertException(IllegalArgumentException.class, request, noUserEmail + " is not a signer");
	}

	@Test
	public void test016_updateSignatureRequest() throws Exception {
		UpdateESignature request = UpdateESignature.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setESignatureId(signatureRequestIdWithFormFields);
		request.setSignatureId(signatureId);
		request.setEmail(testUpdateUserEmail);

		ESignatureResult result = (ESignatureResult) request.eval(cortexSession).get();

		assertResult(result);
		assertThat(result.getSigners().get(0).getEmail()).isEqualTo(testUpdateUserEmail);
	}

	@Ignore
	@Test
	public void test017_updateSignatureRequestNoFormFields() throws Exception {
		UpdateESignature request = UpdateESignature.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setESignatureId(signatureRequestIdNoFormFields);
		request.setSignatureId(signatureId);
		request.setEmail(testUpdateUserEmail);

		assertException(IllegalArgumentException.class, request,
				"This signature request cannot be updated, as it has a separate signature page. Please resend.");
	}

	@Test
	public void test018_getFileSignatureRequestIncomplete() throws Exception {
		DownloadESignatureContent request = DownloadESignatureContent.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setESignatureId(signatureRequestIdNoFormFields);

		assertException(IllegalArgumentException.class, request, "Requested document is not completely signed!");
	}

	@Test
	public void test019_getFileSignatureRequest() throws Exception {
		DownloadESignatureContent request = DownloadESignatureContent.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setESignatureId(
				providerSpecification instanceof HelloSignSpecification ? helloSignSignedSignatureRequestId : docuSignSignedSignatureRequestId);

		ESignatureContentResult result = (ESignatureContentResult) request.eval(cortexSession).get();

		assertThat(result).isNotNull();
		assertThat(result.getResource()).isNotNull();
		assertThat(result.getResource().getName()).isNotNull();
		assertThat(result.getResource().getFileSize()).isNotNull();
		assertThat(result.getResource().getMimeType()).isEqualTo("application/pdf");
	}

	@Test
	public void test020_removeSignatureRequest() throws Exception {
		RemoveESignature request = RemoveESignature.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setESignatureId(signatureRequestIdNoFormFields);

		assertException(IllegalArgumentException.class, request, "Only complete requests can be removed!");
	}

	@Test
	public void test021_cancelSignatureRequestNoFormFields() throws Exception {
		CancelESignature request = CancelESignature.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setESignatureId(signatureRequestIdNoFormFields);
		request.setReason("Canceling test signature request");

		SuccessResult result = request.eval(cortexSession).get();

		assertThat(result).isNotNull();
		assertThat(result.getSuccess()).isTrue();
	}

	@Test
	public void test022_cancelSignatureRequestWithFormFields() throws Exception {
		CancelESignature request = CancelESignature.T.create();
		request.setProviderSpecifications(CollectionTools2.asList(providerSpecification));

		request.setESignatureId(signatureRequestIdWithFormFields);
		request.setReason("Canceling test signature request");

		SuccessResult result = request.eval(cortexSession).get();

		assertThat(result).isNotNull();
		assertThat(result.getSuccess()).isTrue();
	}

	// -----------------------------------------------------------------------
	// ASSERTIONS
	// -----------------------------------------------------------------------

	private void assertException(Class<? extends Exception> exceptionClass, DocsignRequest request, String expectedMessage) {
		Exception exception = assertThrows(exceptionClass, () -> {
			request.eval(cortexSession).get();
		});

		assertTrue(exception.getMessage().contains(expectedMessage));
	}

	private void assertResultList(ESignatureListResult resultList, int page, int pageSize, boolean expectingResults) {
		assertThat(resultList).isNotNull();
		assertThat(resultList.getPage()).isEqualTo(page);
		assertThat(resultList.getPageSize()).isEqualTo(pageSize);
		assertThat(resultList.getNumPages()).isNotNull();
		if (expectingResults) {
			assertThat(resultList.getNumResults()).isGreaterThan(0);
		} else {
			assertThat(resultList.getNumResults()).isEqualTo(0);
		}
		resultList.getSignatureRequests().stream().forEach(signatureRequest -> assertResult(signatureRequest));
	}

	private void assertResult(ESignatureResult result) {
		assertThat(result).isNotNull();
		assertThat(result.getESignatureId()).isNotBlank();
		assertThat(result.getCreatedAt()).isNotNull();
		assertThat(result.getIsComplete()).isNotNull();
		assertThat(result.getDetailsUrl()).isNotBlank();
		assertThat(result.getSigners()).isNotEmpty();
		result.getSigners().stream().forEach(signature -> assertSignature(signature));
	}

	private void assertSignature(SignerResponse signature) {
		assertThat(signature).isNotNull();
		assertThat(signature.getSignatureId()).isNotBlank();
		assertThat(signature.getName()).isNotBlank();
		assertThat(signature.getEmail()).isNotBlank();
		assertThat(signature.getStatusCode()).isNotBlank();
	}

}
