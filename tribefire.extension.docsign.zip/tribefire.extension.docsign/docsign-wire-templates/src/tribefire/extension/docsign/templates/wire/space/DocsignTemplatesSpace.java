// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.templates.wire.space;

import com.braintribe.logging.Logger;
import com.braintribe.utils.StringTools;
import com.braintribe.wire.api.annotation.Import;
import com.braintribe.wire.api.annotation.Managed;
import com.braintribe.wire.api.scope.InstanceConfiguration;
import com.braintribe.wire.api.space.WireSpace;

import tribefire.extension.docsign.model.deployment.service.DocsignProcessor;
import tribefire.extension.docsign.templates.api.DocsignTemplateContext;
import tribefire.extension.docsign.templates.util.DocsignTemplateUtil;
import tribefire.extension.docsign.templates.wire.contract.BasicInstancesContract;
import tribefire.extension.docsign.templates.wire.contract.DocsignTemplatesContract;

/**
 *
 */
@Managed
public class DocsignTemplatesSpace implements WireSpace, DocsignTemplatesContract {

	private static final Logger logger = Logger.getLogger(DocsignTemplatesSpace.class);

	@Import
	private BasicInstancesContract basicInstances;

	@Import
	private DocsignMetaDataSpace docsignMetaData;

	@Override
	public void setupDocsign(DocsignTemplateContext context) {
		if (context == null) {
			throw new IllegalArgumentException("The DocsignTemplateContext must not be null.");
		}
		logger.debug(() -> "Configuring DOCSIGN based on:\n" + StringTools.asciiBoxMessage(context.toString(), -1));

		// processing
		docsignServiceProcessor(context);

		// metadata
		docsignMetaData.metaData(context);
	}

	// -----------------------------------------------------------------------
	// PROCESSOR
	// -----------------------------------------------------------------------

	@Override
	@Managed
	public DocsignProcessor docsignServiceProcessor(DocsignTemplateContext context) {
		DocsignProcessor bean = context.create(DocsignProcessor.T, InstanceConfiguration.currentInstance());
		bean.setModule(context.getDocsignModule());
		bean.setAutoDeploy(true);

		bean.setProviderSpecifications(context.getProviderSpecifications());

		bean.setName(DocsignTemplateUtil.resolveContextBasedDeployableName("DOCSIGN Service Processor", context));

		return bean;
	}

}
