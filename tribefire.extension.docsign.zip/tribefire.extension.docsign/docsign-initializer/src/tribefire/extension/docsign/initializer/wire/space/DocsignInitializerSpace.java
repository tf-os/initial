// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.initializer.wire.space;

import java.util.ArrayList;
import java.util.List;

import com.braintribe.logging.Logger;
import com.braintribe.model.extensiondeployment.check.CheckBundle;
import com.braintribe.utils.CommonTools;
import com.braintribe.wire.api.annotation.Import;
import com.braintribe.wire.api.annotation.Managed;

import tribefire.cortex.initializer.support.integrity.wire.contract.CoreInstancesContract;
import tribefire.cortex.initializer.support.wire.space.AbstractInitializerSpace;
import tribefire.cortex.model.check.CheckCoverage;
import tribefire.cortex.model.check.CheckWeight;
import tribefire.extension.docsign.initializer.DocsignApiConstants;
import tribefire.extension.docsign.initializer.wire.contract.DocsignInitializerContract;
import tribefire.extension.docsign.initializer.wire.contract.DocsignProviderEnum;
import tribefire.extension.docsign.initializer.wire.contract.ExistingInstancesContract;
import tribefire.extension.docsign.initializer.wire.contract.RuntimePropertiesContract;
import tribefire.extension.docsign.model.deployment.repository.configuration.DocuSignSpecification;
import tribefire.extension.docsign.model.deployment.repository.configuration.HelloSignSpecification;
import tribefire.extension.docsign.model.deployment.repository.configuration.ProviderSpecification;
import tribefire.extension.docsign.model.deployment.service.HealthCheckProcessor;
import tribefire.extension.docsign.templates.api.DocsignTemplateContext;
import tribefire.extension.docsign.templates.api.DocsignTemplateContextBuilder;
import tribefire.extension.docsign.templates.wire.contract.DocsignTemplatesContract;

@Managed
public class DocsignInitializerSpace extends AbstractInitializerSpace implements DocsignInitializerContract, DocsignApiConstants {

	private static final Logger logger = Logger.getLogger(DocsignInitializerSpace.class);

	@Import
	private ExistingInstancesContract existingInstances;

	@Import
	private CoreInstancesContract coreInstances;

	@Import
	private DocsignTemplatesContract docsignTemplates;

	@Import
	private RuntimePropertiesContract properties;

	@Override
	public void setupDefaultConfiguration(DocsignProviderEnum defaultDocsignProvider) {
		docsignTemplates.setupDocsign(defaultDocsignTemplateContext(defaultDocsignProvider));
	}

	@Managed
	public DocsignTemplateContext defaultDocsignTemplateContext(DocsignProviderEnum defaultDocsignProvider) {
		DocsignTemplateContextBuilder builder = DocsignTemplateContext.builder();

		List<ProviderSpecification> providerSpecifications = new ArrayList<>();
		switch (defaultDocsignProvider) {
			case HELLO_SIGN:
				HelloSignSpecification helloSignSpecification = helloSignSpecification();
				if (helloSignSpecification != null) {
					providerSpecifications.add(helloSignSpecification);
				}
				break;
			case DOCU_SIGN:
				DocuSignSpecification docuSignSpecification = docuSignSpecification();
				if (docuSignSpecification != null) {
					providerSpecifications.add(docuSignSpecification());
				}
				break;
			default:
				throw new IllegalArgumentException(DocsignProviderEnum.class.getSimpleName() + ": '" + defaultDocsignProvider + "' not supported");
		}

		builder.setProviderSpecifications(providerSpecifications);

		//@formatter:off
		DocsignTemplateContext bean = builder
				.setContext("default")
				.setEntityFactory(super::create)
				.setDocsignModule(existingInstances.module())
				.setLookupFunction(super::lookup)
				.setLookupExternalIdFunction(super::lookupExternalId)
			.build();
		//@formatter:on

		return bean;
	}

	// -----------------------------------------------------------------------
	// HEALTH
	// -----------------------------------------------------------------------

	@Override
	@Managed
	public CheckBundle functionalCheckBundle() {
		CheckBundle bean = create(CheckBundle.T);
		bean.setModule(existingInstances.module());
		bean.getChecks().add(healthCheckProcessor());
		bean.setName("DOCSIGN Checks");
		bean.setWeight(CheckWeight.under1s);
		bean.setCoverage(CheckCoverage.connectivity);
		bean.setIsPlatformRelevant(false);

		return bean;
	}

	@Managed
	@Override
	public HealthCheckProcessor healthCheckProcessor() {
		HealthCheckProcessor bean = create(HealthCheckProcessor.T);
		bean.setModule(existingInstances.module());
		bean.setAutoDeploy(true);
		bean.setName("DOCSIGN Health Check");
		bean.setExternalId("docsign.healthzProcessor");
		return bean;
	}

	@Managed
	@Override
	public HelloSignSpecification helloSignSpecification() {
		String apiKey = properties.HELLOSIGN_API_KEY();
		if (!CommonTools.isEmpty(apiKey)) {
			HelloSignSpecification bean = create(HelloSignSpecification.T);
			bean.setApiKey(apiKey);
			return bean;
		} else {
			return null;
		}
	}

	@Managed
	@Override
	public DocuSignSpecification docuSignSpecification() {
		String clientId = properties.DOCUSIGN_CLIENT_ID();
		String userId = properties.DOCUSIGN_USER_ID();
		String rsaKey = properties.DOCUSIGN_RSA_KEY();
		if (!CommonTools.isAnyEmpty(clientId, userId, rsaKey)) {
			DocuSignSpecification bean = create(DocuSignSpecification.T);
			bean.setClientId(clientId);
			bean.setUserId(userId);
			bean.setRsaKey(rsaKey);
			return bean;
		} else {
			return create(DocuSignSpecification.T);
		}
	}

}
