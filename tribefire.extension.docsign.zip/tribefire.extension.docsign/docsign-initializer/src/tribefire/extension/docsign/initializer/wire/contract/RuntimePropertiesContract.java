// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.initializer.wire.contract;

import com.braintribe.wire.api.annotation.Default;

import tribefire.cortex.initializer.support.wire.contract.PropertyLookupContract;

public interface RuntimePropertiesContract extends PropertyLookupContract {

	@Default("HELLO_SIGN")
	DocsignProviderEnum DOCSIGN_DEFAULT_PROVIDER();

	// HelloSign
	@Default("b2742449b7591dc610f464925f49cb3a43bdd81a1115c203b4e936cd86318513")
	String HELLOSIGN_API_KEY();

	// DocuSign
	@Default("7686d1bd-b80d-4508-a6f3-0cb37656a676")
	String DOCUSIGN_CLIENT_ID();
	@Default("ffc3426f-b22c-4ad2-952b-8e1a93af58b4")
	String DOCUSIGN_USER_ID();
	@Default("-----BEGIN RSA PRIVATE KEY-----\r\n" + "MIIEogIBAAKCAQEAhmCLMm8F6ekZmolxblYSaRLBUyi2M0pJ/D1uRriW0eJ4lgVs\r\n"
			+ "R6fku98wq8i7FY5VD1I7DSp485o60sfL+toyt01aCT4jpnMngGbiqiCFNxlSZFSk\r\n"
			+ "UYdaSU2Y01uM1xxCJ1U2awAcw74f6+x9SN2L9BUAoQ/bCUZuLhUWQJ9KIja34BvB\r\n"
			+ "UgG/lMY6YmUC1sJLGqtvE0+bJrltOVDtitaNsOS02EUQvHix8vNq5rjy/iFkHBgq\r\n"
			+ "dHrBaxMTXpYMavjetYu54uqTGrKnM/HiUnxIu5sjtkmqUdkbbs1SU6JQViJIWmWG\r\n"
			+ "nx+Upl3ODdYhtaAuJJcekBnG8hVsc9GtccsuxQIDAQABAoIBAAExwXr4xqYuFrar\r\n"
			+ "axEufapmasZ48amiCudNinnhcSG7cBPxR2WZpexPjwiv143Y/oOM2Q6EZp/Pqp8t\r\n"
			+ "/G+l2daMPvUfEsULd/npsDEP6e8z7+oJYI6C8/f70xRp12YgD6x20u1/ikHpIjKA\r\n"
			+ "HxrzMSfBugg0cl9yO094i4KWh9um+mfH/WdG65GVkttoiC5CnJqzh6yuJBPTM5Yf\r\n"
			+ "UyZf+OZuHv1VXObmMkcID2mSawCo56qMfourS4Z4h3WnFPtI6Z1C4Mfpw2Xie44T\r\n"
			+ "YRjnMrYOO3b0S2LFaTHp0MSK5wsRhnqO3EXCxpPYGa5LJUB9Fw/giIsR8nPi1IZo\r\n"
			+ "RWVqu58CgYEA+qpKRJcJJWCir/+7/7bjNiSBgAiCK9p86ZXYdZnLUP6qOACy2rlQ\r\n"
			+ "rXdKt7xqcMA9c/uL4oUE0ESIc5GdGCU2iXrA+4GY0QLqGpvQwiumr5cAXZq1Ult2\r\n"
			+ "T382D+lWxT5ZS0V5UNhVaFPDw7h5qhnMncFbIIk0Edx/4g3QSd6OrpcCgYEAiTyt\r\n"
			+ "JgjWY+zhNEEWn+RplEZPkHXl7sNvGArJ35KAPS225a3iiIUzXdFuDaQeWjbmNj7N\r\n"
			+ "SIXVqg6Qzr7kBQgO2P+vQeDAJuPBw4EV17t4YI7D21c8TBFIqYN5Ezuihg01FMb8\r\n"
			+ "GyJms2lgdPSH9M2OwymesRJUAhFI47qyJfbxVQMCgYBkSyp4Ey53pBiz7tDb2eND\r\n"
			+ "UIv4HG9o+HyuQWRgeW6eM6cLzUvCtA8RuP9OULcN8f0koOsxcSOh6Snng8WlWY5e\r\n"
			+ "p5z7hLkON+pPRzTZ2/lPnE1rJnGSSEIoQK/y4dv0A6Rat6t4q3ZQzeMwNmmHo9b4\r\n"
			+ "79p0RDFvTBhm7DwAsmnIdQKBgC97eeEF/791Dvo4Zu6NZeYyaYbu884nekGUQgKD\r\n"
			+ "urDwJy7SeeWISJx2QKChnwrRodc05WvpOmLrRTjzHQuMnS6BUI73hyQtezX8bKVG\r\n"
			+ "rMCjxKoYRbl/5WcZIQQBhxrgaPQ2YLW2slfy5rewf3W4xWNK/CgB0mUgu9pnFwpB\r\n"
			+ "pYAnAoGAGH0vebcT/uJL9NglulJF0EL2yc2vA38uZwHfXkib+Jb55j8tIkzdry0v\r\n"
			+ "XgzDj4EAgBNCSobkuFGykgotB3wT/WLaXvqPA23kRPe7QX2u1v3S8UY+iEAhRC44\r\n" + "ekAI1f1HzUOIaNgivixIBcqVIVR0XiucAaqVvTiOK2o2RQO20PQ=\r\n"
			+ "-----END RSA PRIVATE KEY-----")
	String DOCUSIGN_RSA_KEY();
}
