// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.initializer;

import com.braintribe.model.processing.bootstrapping.TribefireRuntime;

import tribefire.extension.docsign.DocsignConstants;

public interface DocsignApiConstants extends DocsignConstants {

	// DocuSign
	String DOCUSIGN_CLIENT_ID = TribefireRuntime.getProperty("DOCUSIGN_CLIENT_ID");
	String DOCUSIGN_USER_ID = TribefireRuntime.getProperty("DOCUSIGN_USER_ID");
	String DOCUSIGN_RSA_KEY = TribefireRuntime.getProperty("DOCUSIGN_RSA_KEY");

	// HelloSign
	String HELLOSIGN_API_KEY = TribefireRuntime.getProperty("HELLOSIGN_API_KEY");

}
