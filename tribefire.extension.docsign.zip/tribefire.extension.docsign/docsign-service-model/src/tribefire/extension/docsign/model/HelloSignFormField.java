// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.model;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.annotation.meta.Description;
import com.braintribe.model.generic.annotation.meta.Mandatory;
import com.braintribe.model.generic.annotation.meta.Name;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

public interface HelloSignFormField extends GenericEntity {

	EntityType<HelloSignFormField> T = EntityTypes.T(HelloSignFormField.class);

	@Name("Name")
	@Description("The name of the form field. (optional)")
	String getName();
	void setName(String name);

	@Mandatory
	@Name("Type")
	@Description("One of the Type options. Allowed values checkbox/checkbox-merge/date_signed/dropdown/initials/radio/signature/text/text-merge")
	String getType();
	void setType(String type);

	@Name("Validation Type")
	@Description("One of the Type options. Allowed values numbers_only/letters_only/phone_number/bank_routing_number/bank_account_number/email_address/zip_code/social_security_number/employer_identification_number. (optional)")
	String getValidationType();
	void setValidationType(String validationType);

	@Mandatory
	@Name("X")
	@Description("X coordinate of the field in pixels.")
	Integer getX();
	void setX(Integer x);

	@Mandatory
	@Name("Y")
	@Description("Y coordinate of the field in pixels.")
	Integer getY();
	void setY(Integer y);

	@Mandatory
	@Name("Width")
	@Description("Width of the field in pixels.")
	Integer getWidth();
	void setWidth(Integer width);

	@Mandatory
	@Name("Height")
	@Description("Height of the field in pixels.")
	Integer getHeight();
	void setHeight(Integer height);

	@Mandatory
	@Name("Page")
	@Description("Page in the document where the field should be placed (requires documents be PDF files). (1-based index)")
	Integer getPage();
	void setPage(Integer page);

	@Mandatory
	@Name("Signer")
	@Description("Index indicating which signer should fill out the field. (0-based index)")
	Integer getSigner();
	void setSigner(Integer signer);

	@Mandatory
	@Name("Document")
	@Description("Index indicating which document contains the field. (0-based index)")
	Integer getDocument();
	void setDocument(Integer document);

	@Mandatory
	@Name("Required")
	@Description("Indicator whether this field is required.")
	Boolean getRequired();
	void setRequired(Boolean required);
}
