// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.model.service;

import java.util.Date;

import com.braintribe.model.generic.annotation.Initializer;
import com.braintribe.model.generic.annotation.meta.Description;
import com.braintribe.model.generic.annotation.meta.Name;
import com.braintribe.model.generic.eval.EvalContext;
import com.braintribe.model.generic.eval.Evaluator;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;
import com.braintribe.model.service.api.ServiceRequest;

@Name("eSignature List")
public interface ESignatureList extends DocsignRequest {

	EntityType<ESignatureList> T = EntityTypes.T(ESignatureList.class);

	@Initializer("1")
	@Name("Page")
	@Description("Which page number of the SignatureRequest List to return. Defaults to 1.")
	Integer getPage();
	void setPage(Integer page);

	@Initializer("20")
	@Name("Page Size")
	@Description("Number of objects to be returned per page. Must be between 1 and 100. Default is 20.")
	Integer getPageSize();
	void setPageSize(Integer pageSize);

	@Name("Query")
	@Description("String that includes search terms and/or fields to be used to filter the signature request objects. (optional)")
	String getQuery();
	void setQuery(String query);

	@Initializer("GMT:946684800000")
	@Name("From Date")
	@Description("Specifies the date and time to start looking for status changes. Default is 2000/01/01.")
	Date getFromDate();
	void setFromDate(Date fromDate);

	@Override
	EvalContext<? extends SuccessResult> eval(Evaluator<ServiceRequest> evaluator);

}
