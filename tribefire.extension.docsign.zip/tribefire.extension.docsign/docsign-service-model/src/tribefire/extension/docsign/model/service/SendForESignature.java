// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.model.service;

import java.util.List;

import com.braintribe.model.generic.annotation.meta.Description;
import com.braintribe.model.generic.annotation.meta.Mandatory;
import com.braintribe.model.generic.annotation.meta.Name;
import com.braintribe.model.generic.eval.EvalContext;
import com.braintribe.model.generic.eval.Evaluator;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;
import com.braintribe.model.resource.Resource;
import com.braintribe.model.service.api.ServiceRequest;

import tribefire.extension.docsign.model.HelloSignFormField;
import tribefire.extension.docsign.model.Recipient;

@Name("Send For eSignature")
public interface SendForESignature extends DocsignRequest {

	EntityType<SendForESignature> T = EntityTypes.T(SendForESignature.class);

	@Mandatory
	@Name("Files")
	@Description("File(s) to send for signature.")
	List<Resource> getFiles();
	void setFiles(List<Resource> files);

	@Name("Title")
	@Description("The to assign to the signature request. (optional)")
	String getTitle();
	void setTitle(String title);

	@Name("Subject")
	@Description("The subject in the email that will be sent to the signers. (optional)")
	String getSubject();
	void setSubject(String subject);

	@Name("Message")
	@Description("The custom message in the email that will be sent to the signers. (optional)")
	String getMessage();
	void setMessage(String message);

	@Mandatory
	@Name("Signers")
	@Description("The names and email addresses of the signers.")
	List<Recipient> getSigners();
	void setSigners(List<Recipient> signers);

	@Name("CCs")
	@Description("The names and email addresses of the CCs. (optional)")
	List<Recipient> getCCs();
	void setCCs(List<Recipient> ccs);

	@Name("Form Fields")
	@Description("The fields that should appear on the document. (optional)")
	List<HelloSignFormField> getFormFields();
	void setFormFields(List<HelloSignFormField> formFields);

	@Override
	EvalContext<? extends ESignatureResult> eval(Evaluator<ServiceRequest> evaluator);

}
