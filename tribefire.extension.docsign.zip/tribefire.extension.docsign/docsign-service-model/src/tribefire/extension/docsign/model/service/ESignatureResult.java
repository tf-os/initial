// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.docsign.model.service;

import java.util.Date;
import java.util.List;

import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

import tribefire.extension.docsign.model.HasESignatureId;
import tribefire.extension.docsign.model.SignerResponse;

/**
 * 
 *
 */
public interface ESignatureResult extends DocsignResult, HasESignatureId {

	EntityType<? extends ESignatureResult> T = EntityTypes.T(ESignatureResult.class);

	String getTitle();
	void setTitle(String title);

	String getSubject();
	void setSubject(String subject);

	String getMessage();
	void setMessage(String message);

	Date getCreatedAt();
	void setCreatedAt(Date createdAt);

	boolean getIsComplete();
	void setIsComplete(boolean isComplete);

	List<String> getCCs();
	void setCCs(List<String> cCs);

	List<SignerResponse> getSigners();
	void setSigners(List<SignerResponse> signers);

	String getDetailsUrl();
	void setDetailsUrl(String detailsUrl);

}
