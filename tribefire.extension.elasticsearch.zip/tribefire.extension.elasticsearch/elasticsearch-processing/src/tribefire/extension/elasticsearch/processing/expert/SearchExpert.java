// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.elasticsearch.processing.expert;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;

import com.braintribe.logging.Logger;
import com.braintribe.utils.ArrayTools;
import com.braintribe.utils.StringTools;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.ElasticsearchException;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery.Builder;
import co.elastic.clients.elasticsearch._types.query_dsl.TextQueryType;
import co.elastic.clients.elasticsearch.core.search.Hit;
import co.elastic.clients.elasticsearch.core.search.TotalHits;
import co.elastic.clients.json.jackson.JacksonJsonpMapper;
import co.elastic.clients.transport.ElasticsearchTransport;
import co.elastic.clients.transport.rest_client.RestClientTransport;
import tribefire.extension.elasticsearch.model.api.request.doc.SearchAsYouType;
import tribefire.extension.elasticsearch.model.api.request.doc.SearchParameter;
import tribefire.extension.elasticsearch.model.api.request.doc.SearchRequest;
import tribefire.extension.elasticsearch.model.api.response.SearchResponse;
import tribefire.extension.elasticsearch.model.api.response.SearchResponseHit;

public class SearchExpert extends BaseExpert<SearchRequest, SearchResponse> {

	private static final Logger logger = Logger.getLogger(SearchExpert.class);

	private String term;

	private List<SearchParameter> parameters;

	private List<String> parentIds;
	private Boolean recursively;

	private Integer pageOffset;
	private Integer pageLimit;

	// ***************************************************************************************************
	// Configuration
	// ***************************************************************************************************

	protected void setTerm(String term) {
		this.term = term;
	}

	protected void setParameters(List<SearchParameter> parameters) {
		this.parameters = parameters;
	}

	private void setParentIds(List<String> parentIds) {
		this.parentIds = parentIds;
	}

	protected void setRecursively(Boolean recursively) {
		this.recursively = recursively;
	}

	protected void setPageOffset(Integer pageOffset) {
		this.pageOffset = pageOffset;
	}

	protected void setPageLimit(Integer pageLimit) {
		this.pageLimit = pageLimit;
	}

	@Override
	public SearchResponse process() {
		// Create the low-level client
		RestClient restClient = RestClient.builder(new HttpHost("localhost", 9200)).build();

		// Create the transport with a Jackson mapper
		ElasticsearchTransport transport = new RestClientTransport(restClient, new JacksonJsonpMapper());

		// And create the API client
		ElasticsearchClient client = new ElasticsearchClient(transport);

		try {
			Builder builder = new BoolQuery.Builder();

			AtomicReference<Builder> builderRef = new AtomicReference<Builder>(builder);

			if (!StringTools.isEmpty(this.term)) {
				builderRef.set(
						builder.must(m -> m.multiMatch(mma -> mma.fields(ArrayTools.toList("title", "title._2gram", "title._3gram", "title._4gram"))
								.type(TextQueryType.BoolPrefix).query(this.term))));
			}

			this.parameters.stream().forEach(p -> {
				builderRef.set(builder.must(m -> m.match(ma -> ma.field(p.getName()).query(p.getValue()))));
			});

			Builder pathBuilder = new BoolQuery.Builder();

			AtomicReference<Builder> pathBuilderRef = new AtomicReference<Builder>(pathBuilder);

			boolean isRootQuery = this.parentIds.isEmpty();

			if (!recursively && isRootQuery) {
				setParentIds(Arrays.asList("/"));
			}

			if (!this.parentIds.isEmpty()) {
				this.parentIds.stream().forEach(id -> {
					if (this.recursively) {
						pathBuilderRef.set(pathBuilder.should(s -> s.term(t -> t.field("$path.tree").value(id))));
					} else {
						pathBuilderRef.set(pathBuilder.should(s -> s.matchPhrase(m -> m.field("$path").query(id))));
					}
				});

				BoolQuery pathBoolQuery = pathBuilder.build();
				if (this.recursively) {
					builder.filter(f -> f.bool(pathBoolQuery));
				} else {
					builder.must(pathBoolQuery._toQuery());
				}
			}

			BoolQuery boolQuery = builder.build();
			//@formatter:off
			co.elastic.clients.elasticsearch.core.SearchRequest searchRequest = co.elastic.clients.elasticsearch.core.SearchRequest.of(s -> s
					.index(this.indexName)
					.query(q -> q      
							.bool(boolQuery)
							)
					.from(this.pageOffset)
					.size(this.pageLimit > 0 ? this.pageLimit : 10000)
					);
			
			
			co.elastic.clients.elasticsearch.core.SearchResponse<Void> response = client.search(searchRequest, Void.class);
			
			TotalHits total = response.hits().total();
			
			List<SearchResponseHit> responseHits = new ArrayList<SearchResponseHit>();
			
			List<Hit<Void>> hits = response.hits().hits();
			for (Hit<Void> hit: hits) {
			    SearchResponseHit responseHit = SearchResponseHit.T.create();
			    responseHit.setIndexId(hit.id());
			    responseHit.setScore(hit.score());
			    responseHits.add(responseHit);
			}
			
			return responseBuilder(SearchResponse.T, this.request)
					.responseEnricher(r -> {
						r.setTotalHits(total.value());
						r.setHits(responseHits);
					})
					.build();
			//@formatter:on
		} catch (ElasticsearchException | IOException e) {
			logger.error("Error searching!", e);
			throw new IllegalArgumentException(e.getMessage());
		}

	}

	// ***************************************************************************************************
	// Initialization
	// ***************************************************************************************************

	public static SearchExpert forSearch(SearchRequest request) {
		return createExpert(SearchExpert::new, (expert) -> {
			expert.setRequest(request);
			expert.setIndexName(request.getIndexName());
			expert.setParameters(request.getParameters());
			expert.setParentIds(request.getParentIds());
			expert.setRecursively(request.getRecursively());
			expert.setPageOffset(request.getPageOffset());
			expert.setPageLimit(request.getPageLimit());
		});
	}

	public static SearchExpert forSearchAsYouType(SearchAsYouType request) {
		return createExpert(SearchExpert::new, (expert) -> {
			expert.setRequest(request);
			expert.setIndexName(request.getIndexName());
			expert.setTerm(request.getTerm());
			expert.setParameters(request.getParameters());
			expert.setParentIds(request.getParentIds());
			expert.setRecursively(request.getRecursively());
			expert.setPageOffset(request.getPageOffset());
			expert.setPageLimit(request.getPageLimit());
		});
	}

}
