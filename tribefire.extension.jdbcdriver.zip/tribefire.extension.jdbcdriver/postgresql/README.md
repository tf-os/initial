# PostgreSQL Driver Platform Library

A platform library which provides PostgreSQL Driver.
