# MSSQL Driver Plugin

# Deprecated.

Please use the alternative plugin that contains the version number in the name.