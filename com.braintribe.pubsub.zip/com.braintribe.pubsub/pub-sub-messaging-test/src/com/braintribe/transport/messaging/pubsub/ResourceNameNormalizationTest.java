// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.transport.messaging.pubsub;

import static com.braintribe.testing.junit.assertions.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.fail;

import org.junit.Test;

public class ResourceNameNormalizationTest {


	@Test
	public void testResourceNameNormalization() {
		
		assertThat(PubSubMessageConsumer.normalizeResourceName("hello", 0, 255, true)).isEqualTo("hello");
		assertThat(PubSubMessageConsumer.normalizeResourceName("hello, world", 0, 255, true)).isEqualTo("hello%2C+world");
		assertThat(PubSubMessageConsumer.normalizeResourceName("hello   world", 0, 255, true)).isEqualTo("hello+++world");
		
		assertThat(PubSubMessageConsumer.normalizeResourceName("123", 0, 255, true)).isEqualTo("X123");
		assertThat(PubSubMessageConsumer.normalizeResourceName("12", 3, 255, true)).isEqualTo("X12");
		assertThat(PubSubMessageConsumer.normalizeResourceName("123", 3, 255, true)).isEqualTo("X123");
		
		assertThat(PubSubMessageConsumer.normalizeResourceName("aZ09~.-_%+", 3, 255, true)).isEqualTo("aZ09~.-_%+");
		
		assertThat(PubSubMessageConsumer.normalizeResourceName("google", 0, 255, true)).isEqualTo("Xgoogle");

		assertThat(PubSubMessageConsumer.normalizeResourceName("X12345", 3, 3, false)).isEqualTo("X12");
		assertThat(PubSubMessageConsumer.normalizeResourceName("X12345", 0, 3, false)).isEqualTo("X12");

		try {
			PubSubMessageConsumer.normalizeResourceName(null, 0, 255, true);
			fail("This should have thrown a NPE.");
		} catch(NullPointerException npe) {
			//expected
		}

		try {
			PubSubMessageConsumer.normalizeResourceName("X12345", 0, 3, true);
			fail("This should have thrown an IllegalArgumentException.");
		} catch(IllegalArgumentException iae) {
			//expected
		}

		try {
			PubSubMessageConsumer.normalizeResourceName("X12345", 3, 0, true);
			fail("This should have thrown an IllegalArgumentException.");
		} catch(IllegalArgumentException iae) {
			//expected
		}

		try {
			PubSubMessageConsumer.normalizeResourceName("X12345", 0, -2, true);
			fail("This should have thrown an IllegalArgumentException.");
		} catch(IllegalArgumentException iae) {
			//expected
		}

	}
}
