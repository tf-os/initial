// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.transport.messaging.pubsub.test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.braintribe.codec.marshaller.bin.Bin2Marshaller;
import com.braintribe.model.messaging.Message;
import com.braintribe.model.messaging.expert.Messaging;
import com.braintribe.transport.messaging.api.MessagingContext;
import com.braintribe.transport.messaging.api.test.utils.Marshallers;
import com.braintribe.transport.messaging.pubsub.PubSubMessaging;

public class PubSubDenotationTypeBasedTest {
	
	private DateFormat df = new SimpleDateFormat("yyyy.MM.dd-HH:mm:ss");
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected com.braintribe.transport.messaging.api.MessagingConnectionProvider getMessagingConnectionProvider() {
		
		Messaging denotationType = createDenotationType();
		
		com.braintribe.transport.messaging.api.Messaging messaging = getExpertByDenotationType(denotationType);
		
		return messaging.createConnectionProvider(denotationType, getMessagingContext());
		
	}

	
	protected Messaging createDenotationType() {
		
		com.braintribe.model.messaging.pubsub.PubSubMessaging messagingDenotationType = com.braintribe.model.messaging.pubsub.PubSubMessaging.T.create();
		messagingDenotationType.setProject("bamboo-archery-180615");
		messagingDenotationType.setCredentials("{    \"type\": \"service_account\",    \"project_id\": \"bamboo-archery-180615\",    \"private_key_id\": \"f750a2cac393f3c89b1f750c83496b9184ee1c4a\",    \"private_key\": \"-----BEGIN PRIVATE KEY-----\\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDa4G/62Y2hjtLk\\nTIn8clcGNHEPhQvJquR16O4DAQWtGiZDxuplMo+6tJN+4KXj1sWlWZMQkb0PHl6t\\nMD2d/irTOKTTfqnONYQEu7M5OAxOPLr/9Gl2amXQ9WFdbsjfX84/ykqu7shsl5Ny\\nc8FnHxW2Tt3lZnpszS8Cfor34HO8ex6tr23rIQsjidHX8hafsP7GdBruzGUjuWCT\\nGSzOp/htEMukaH3zUZiX7VD8Vvs0Vn4ktGjyHY+6rjqsS5zK8X0a2Up7QURdBwoZ\\nkWdABT7NNsU1sR4zfVxmXHuJ4W7NwjzE1LSt/toTfq/p1EzeB8nYB6jmhHoespv1\\nMIAa4/5zAgMBAAECggEAH/tf3BzSNqiqxSQv8hzM/YGdLEzfCj030R4o5R8kSAUZ\\npplYDP3EhbNhbU6AaZiA3HvduDPrbFxI2O/tw6UXdzIALPfa8mAx0F/oPMn6oQCm\\nZxm8wp+iYqma7ARGQr7PjCpQG7FAGlSoUrbPrEnyVLy/wgeQMk9lo+zUpoqmrq6z\\nq3ON0MMRLp2r7G5NLNWjcdzZLV8Xl+1pHflLsV7bRzZQIUTofxa6+abj6QnPXglr\\nkrwKYEiWnwniVP5lRNs+3PBseA9/JJ1md06GdCJ1rby3NCiLw4312XKhzsBhildJ\\nUjMDlwjcGARoICbx7p6WfwAjuduRErtf/HJKAdH3PQKBgQDuty6OaWILRtTJCwfi\\n6lUD/s3/fMcdB6XQZsKOWdsjHgQSj2H1Ij+FCE+T8xMs9BaiKzVH4vfKsQhujhnP\\nYhCsN43yJX/eztMwp96DitGMJCIvxS+Ov1xZtxelln4YuNpWBFCAm9bjHouYoOeY\\ngWGQwJhROy94kKedDcGlHB6gfwKBgQDquYYZ5Y10qtBZm3LBhgdrhZ+wsctDVTWS\\nJCNamnYRM8r9nC2FnP44kS8DUt5Oq/HYSktN33YRwO8Df6p/3SBb5i/rXx4NawsA\\n7F0RyW6oe7jDBc2tBIahORCXsnLNa8C014G8eZVG7pdv+FqUWzWrXS6n5AZmQTIe\\nPo/fOr4oDQKBgFGb9GGha3BZfcNhbwfHftsH0FsIyHWHOMu/ZcIOvBkMWO4TcLTC\\nSZ7sUXBOCH80z0wPo354/Keh0DUjhXVdnD+UGoXvBgEhChg3O54S5kKX08wrCHAv\\nwZ22N3JXubIv+AyyGuds35Dzz1uVnreHe9hlz2zt4/O+2F6b5ljQ/TN3AoGAXOQu\\n/fCqmpE/AzdRouS36wVmvTafinYeTUef9itKrmQg4Vz9ZvNKaHiMcnRJJjlF7KL6\\nSkc1IrGH5YqQnymTtMrUDAIIkqbaI/NmobNl56eO5x9U1jQEU6mRt3cXl9Qc33Sq\\nEzzKpteldtqCflPaWYb2/9pt7em/O9jmdyF4P8ECgYEAp3gdLl3UlVNWjnoz4Gsw\\nFuzIecMGaHa9BsZrxlzqslKOVsNRaVNjEOvQqCm2fh4PNUhtfOrynr+0jWjpJXzF\\nroxHqgDHkcoBguJAI5TW8m8L5ytDa/GkbcmBKD03heYEIcmocjexbXdyOfTsRp8t\\nfz/hplOL4Rj6uIbC8PK+2CI=\\n-----END PRIVATE KEY-----\\n\",    \"client_email\": \"rku-806@bamboo-archery-180615.iam.gserviceaccount.com\",    \"client_id\": \"107259576651230845814\",    \"auth_uri\": \"https://accounts.google.com/o/oauth2/auth\",    \"token_uri\": \"https://accounts.google.com/o/oauth2/token\",    \"auth_provider_x509_cert_url\": \"https://www.googleapis.com/oauth2/v1/certs\",    \"client_x509_cert_url\": \"https://www.googleapis.com/robot/v1/metadata/x509/rku-806%40bamboo-archery-180615.iam.gserviceaccount.com\"  }  ");
		
		return messagingDenotationType;
		
	}
	
	protected com.braintribe.transport.messaging.api.Messaging<? extends Messaging> getExpertByDenotationType(Messaging denotationType) {
		
		if (denotationType instanceof com.braintribe.model.messaging.pubsub.PubSubMessaging) {
			PubSubMessaging messaging = new PubSubMessaging();
			return messaging;
		}
		
		return null;
		
	}
	
	protected void populate(Message message) {
		
		String iden = "Message-"+df.format(new Date());
		
		message.setBody("Body: "+iden);
		message.setCorrelationId("CorrelationId: "+iden);
		message.setHeaders(createTestHeaders(iden));
	}
	
	private static Map<String, Object> createTestHeaders(String iden) {
		
		String[] testArray = new String[] {"A", "B", "C"};
		
		Map<String, Object> h = new HashMap<String, Object>();
		h.put("String-header", "String-header of "+iden);
		h.put("Long-header", Long.MIN_VALUE);
		h.put("Integer-header", Integer.MAX_VALUE);
		h.put("Boolean-header", Boolean.TRUE);
		
		//makes the marshalling fail with BinMarshaller:
		//h.put("Array-header", testArray);
		
		h.put("List-header", Arrays.asList(testArray));
		
		return h;
	}
	
	protected MessagingContext getMessagingContext() {
		MessagingContext context = new MessagingContext();
		context.setMarshaller(new Bin2Marshaller());
		return context;
	}
	
}
