// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.transport.messaging.pubsub;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

import com.braintribe.logging.Logger;
import com.braintribe.model.messaging.Destination;
import com.braintribe.model.messaging.Message;
import com.braintribe.model.messaging.Queue;
import com.braintribe.model.messaging.Topic;
import com.braintribe.transport.messaging.api.MessageConsumer;
import com.braintribe.transport.messaging.api.MessageProducer;
import com.braintribe.transport.messaging.api.MessagingContext;
import com.braintribe.transport.messaging.api.MessagingException;
import com.braintribe.transport.messaging.api.MessagingSession;
import com.google.api.gax.rpc.NotFoundException;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.pubsub.v1.TopicAdminClient;
import com.google.cloud.pubsub.v1.TopicAdminSettings;
import com.google.pubsub.v1.ProjectName;
import com.google.pubsub.v1.ProjectTopicName;

/**
 * <p>
 * {@link MessagingSession} implementation for {@link PubSubMessaging}.
 * 
 * @see MessagingSession
 */
public class PubSubMessagingSession implements MessagingSession {

	private PubSubConnection connection;
	private MessagingContext messagingContext;

	private static final Logger log = Logger.getLogger(PubSubMessagingSession.class);

	private Set<PubSubMessageProducer> messageProducers = new HashSet<>();
	private ReentrantLock messageProducersLock = new ReentrantLock();
	private Set<PubSubMessageConsumer> messageConsumers = new HashSet<>();
	private ReentrantLock messageConsumersLock = new ReentrantLock();

	private Map<String, Queue> createdQueues = new ConcurrentHashMap<>();
	private Map<String, Topic> createdTopics = new ConcurrentHashMap<>();
	private ProjectName projectName = null;
	private com.braintribe.model.messaging.pubsub.PubSubMessaging providerConfiguration;
	private GoogleCredentials credentials;

	public PubSubMessagingSession(ProjectName projectName, com.braintribe.model.messaging.pubsub.PubSubMessaging providerConfiguration, GoogleCredentials credentials) {
		this.projectName = projectName;
		this.providerConfiguration = providerConfiguration;
		this.credentials = credentials;
	}

	public PubSubConnection getConnection() {
		return connection;
	}

	@Override
	public MessageProducer createMessageProducer() throws MessagingException {
		return createMessageProducer(null);
	}

	@Override
	public void open() throws MessagingException {
		//nothing to do
	}

	@Override
	public void close() throws MessagingException {
		messageProducersLock.lock();
		try {
			while (!messageProducers.isEmpty()) {
				Iterator<PubSubMessageProducer> iterator = messageProducers.iterator();
				PubSubMessageProducer mp = iterator.next();
				iterator.remove();
				try {
					mp.close();
				} catch(Exception e) {
					log.debug(() -> "Error while closing message producer: "+mp, e);
				}
			}
		} finally {
			messageProducersLock.unlock();
		}
		messageConsumersLock.lock();
		try {
			while (!messageConsumers.isEmpty()) {
				Iterator<PubSubMessageConsumer> iterator = messageConsumers.iterator();
				PubSubMessageConsumer mc = iterator.next();
				iterator.remove();
				try {
					mc.close();
				} catch(Exception e) {
					log.debug(() -> "Error while closing message consumer: "+mc, e);
				}
			}
		} finally {
			messageConsumersLock.unlock();
		}
	}

	@Override
	public Queue createQueue(String name) throws MessagingException {
		Queue alreadyCreated = createdQueues.get(name);
		if (alreadyCreated != null) {
			return alreadyCreated;
		}

		ProjectTopicName topicName = ProjectTopicName.of(projectName.getProject(), name);

		try {
			if (!topicExists(topicName)) {
				createTopic(topicName);
			}
		} catch(Exception e) {
			throw new MessagingException("Could not create/find topic with name "+name, e);
		}

		Queue t = Queue.T.create();
		t.setName(name);

		createdQueues.put(name, t);
		return t;
	}

	@Override
	public Topic createTopic(String name) throws MessagingException {

		Topic alreadyCreated = createdTopics.get(name);
		if (alreadyCreated != null) {
			return alreadyCreated;
		}

		ProjectTopicName topicName = ProjectTopicName.of(projectName.getProject(), name);

		try {
			if (!topicExists(topicName)) {
				createTopic(topicName);
			}
		} catch(Exception e) {
			throw new MessagingException("Could not create/find topic with name "+name, e);
		}

		Topic t = Topic.T.create();
		t.setName(name);

		createdTopics.put(name, t);
		return t;
	}

	private void createTopic(ProjectTopicName topicName) throws Exception {
		
		TopicAdminSettings topicAdminSettings = TopicAdminSettings.newBuilder().setCredentialsProvider(() -> credentials).build();
		
		try (TopicAdminClient topicAdminClient = TopicAdminClient.create(topicAdminSettings)) {
			topicAdminClient.createTopic(topicName);
		}
	}

	private boolean topicExists(ProjectTopicName topicName) throws Exception {
		
		TopicAdminSettings topicAdminSettings = TopicAdminSettings.newBuilder().setCredentialsProvider(() -> credentials).build();
		
		try (TopicAdminClient topicAdminClient = TopicAdminClient.create(topicAdminSettings)) {
			
			try {
				topicAdminClient.getTopic(topicName);
			} catch(NotFoundException nfe) {
				return false;
			}
			return true;
		}
	}

	@Override
	public Message createMessage() throws MessagingException {
		return Message.T.create();
	}

	@Override
	public MessageProducer createMessageProducer(Destination destination) throws MessagingException {

		PubSubMessageProducer producer = new PubSubMessageProducer(projectName, destination, credentials); 
		producer.setApplicationId(messagingContext.getApplicationId());
		producer.setNodeId(messagingContext.getNodeId());
		producer.setMessagingContext(messagingContext);
		producer.setSession(this);

		messageProducersLock.lock();
		try {
			messageProducers.add(producer);
		} finally {
			messageProducersLock.unlock();
		}
		
		return producer;
	}

	@Override
	public MessageConsumer createMessageConsumer(Destination destination) throws MessagingException {
		PubSubMessageConsumer consumer = new PubSubMessageConsumer(projectName, destination, providerConfiguration, credentials); 
		consumer.setApplicationId(messagingContext.getApplicationId());
		consumer.setNodeId(messagingContext.getNodeId());
		consumer.setMessagingContext(messagingContext);	
		consumer.setSession(this);
		
		messageConsumersLock.lock();
		try {
			messageConsumers.add(consumer);
		} finally {
			messageConsumersLock.unlock();
		}
		
		return consumer;
	}

	public void setMessagingContext(MessagingContext messagingContext2) {
		this.messagingContext = messagingContext2;
	}

	public void unregisterMessageProducer(PubSubMessageProducer pubSubMessageProducer) {
		messageProducersLock.lock();
		try {
			messageProducers.remove(pubSubMessageProducer);
		} finally {
			messageProducersLock.unlock();
		}	
	}

	public void unregisterMessageConsumer(PubSubMessageConsumer pubSubMessageConsumer) {
		messageConsumersLock.lock();
		try {
			messageConsumers.remove(pubSubMessageConsumer);
		} finally {
			messageConsumersLock.unlock();
		}	
	}

}
