// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.transport.messaging.pubsub;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.nio.charset.StandardCharsets;

import com.braintribe.logging.Logger;
import com.google.auth.oauth2.GoogleCredentials;

public class CredentialsLoader {

	private static final Logger log = Logger.getLogger(CredentialsLoader.class);
	
	public static GoogleCredentials retrieveCredentials(String credentialsSettings) {
		
		GoogleCredentials credentials = getCredentialsFromFile(credentialsSettings);
		if (credentials != null) {
			return credentials;
		}
		
		String env = System.getProperty(credentialsSettings);
		if (env == null) {
			env = System.getenv(credentialsSettings);
		}
		if (env != null) {
			credentials = getCredentialsFromFile(env);
			if (credentials != null) {
				return credentials;
			}
			credentials = getCredentialsFromString(env);
			if (credentials != null) {
				return credentials;
			}
		}
		
		credentials = getCredentialsFromString(credentialsSettings);
		
		return credentials;
	}
	
	private static GoogleCredentials getCredentialsFromString(String credentialsString) {
		try (ByteArrayInputStream in = new ByteArrayInputStream(credentialsString.getBytes(StandardCharsets.UTF_8))) {
			GoogleCredentials credentials = GoogleCredentials.fromStream(in);
			return credentials;
		} catch(Exception e2) {
			log.debug(() -> "Could not interpret the credentials: "+credentialsString, e2);
		}
		return null;
	}
	
	private static GoogleCredentials getCredentialsFromFile(String filepath) {
		GoogleCredentials credentials = null; 
		try {
			File f = new File(filepath);
			if (f.exists()) {
				try (FileInputStream fis = new FileInputStream(f)) {
					credentials = GoogleCredentials.fromStream(fis);
					return credentials;
				}				
			}
		} catch(Exception e) {
			log.debug(() -> "Could not interpret credentials as a file path.", e);
		}
		return null;
	}
	
}
