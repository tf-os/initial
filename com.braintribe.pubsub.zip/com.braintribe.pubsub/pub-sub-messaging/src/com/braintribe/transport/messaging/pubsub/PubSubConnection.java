// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.transport.messaging.pubsub;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

import com.braintribe.logging.Logger;
import com.braintribe.model.messaging.pubsub.PubSubMessaging;
import com.braintribe.transport.messaging.api.MessagingComponentStatus;
import com.braintribe.transport.messaging.api.MessagingConnection;
import com.braintribe.transport.messaging.api.MessagingContext;
import com.braintribe.transport.messaging.api.MessagingException;
import com.braintribe.transport.messaging.api.MessagingSession;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.pubsub.v1.ProjectName;

/**
 * <p>
 * {@link MessagingConnection} implementation representing a connection to a Pub/Sub server.
 * 
 */
public class PubSubConnection implements MessagingConnection {

	private static final Logger log = Logger.getLogger(PubSubConnection.class);
	private ProjectName projectName;
	private MessagingContext messagingContext;
	private PubSubMessaging providerConfiguration;
	
	private MessagingComponentStatus status = MessagingComponentStatus.NEW;
	
	protected Set<PubSubMessagingSession> sessions = new HashSet<>();
	protected ReentrantLock sessionsLock = new ReentrantLock();
	private GoogleCredentials credentials;
	
	public PubSubConnection(com.braintribe.model.messaging.pubsub.PubSubMessaging providerConfiguration, GoogleCredentials credentials) {
		this.providerConfiguration = providerConfiguration;
		this.credentials = credentials;
	}
	
	
	public void setProjectName(ProjectName projectName) {
		this.projectName = projectName;
	}


	@Override
	public void open() throws MessagingException {
		
		if (status == MessagingComponentStatus.CLOSING || status == MessagingComponentStatus.CLOSED) {
			throw new MessagingException("Connection in unexpected state: "+status.toString().toLowerCase());
		}
		if (status == MessagingComponentStatus.OPEN) {
			//opening an already opened connection shall be a no-op
			if (log.isTraceEnabled()) {
				log.trace("open() called in an already opened connection. Connection already established.");
			}
			return;
		}

		this.status = MessagingComponentStatus.OPEN;
	}


	@Override
	public void close() throws MessagingException {
		this.status = MessagingComponentStatus.CLOSING;

		sessionsLock.lock();
		try {
			for (PubSubMessagingSession session : sessions) {
				try {
					session.close();
				} catch(Exception e) {
					log.error("Error while trying to close session: "+session, e);
				}
			}
		} finally {
			sessionsLock.unlock();
		}
		
		this.status = MessagingComponentStatus.CLOSED;
	}


	@Override
	public MessagingSession createMessagingSession() throws MessagingException {
		
		open();
		
		PubSubMessagingSession session = new PubSubMessagingSession(projectName, providerConfiguration, credentials);
		session.setMessagingContext(messagingContext);
		
		sessionsLock.lock();
		try {
			sessions.add(session);
		} finally {
			sessionsLock.unlock();
		}
		return session;
	}


	public void setMessagingContext(MessagingContext messagingContext) {
		this.messagingContext = messagingContext;
	}

}
