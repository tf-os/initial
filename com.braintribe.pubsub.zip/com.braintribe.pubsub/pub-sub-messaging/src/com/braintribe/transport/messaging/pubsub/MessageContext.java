// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.transport.messaging.pubsub;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import com.braintribe.model.messaging.Message;
import com.google.cloud.pubsub.v1.AckReplyConsumer;
import com.google.pubsub.v1.PubsubMessage;

public class MessageContext {
	
	private Message message;
	private CountDownLatch messageProcessed = new CountDownLatch(1);
	private boolean acknowledged = false;
	private AckReplyConsumer consumer;
	private PubsubMessage pubsubMessgae;
	private boolean processed = false;

	public MessageContext(PubsubMessage pubsubMessgae, Message message, AckReplyConsumer consumer) {
		this.pubsubMessgae = pubsubMessgae;
		this.message = message;
		this.consumer = consumer;
	}

	public PubsubMessage getPubsubMessgae() {
		return pubsubMessgae;
	}

	public Message getMessage() {
		return message;
	}

	public void ack() {
		if (processed) {
			return;
		}
		processed = true;
		acknowledged = true;
		messageProcessed.countDown();
		consumer.ack();
	}
	
	public void nack() {
		if (processed) {
			return;
		}
		processed = true;
		acknowledged = false;
		messageProcessed.countDown();
		consumer.nack();
	}
	
	public boolean acknowledged() {
		return acknowledged;
	}
	
	public void waitForAck(long timeout) throws InterruptedException {
		messageProcessed.await(timeout, TimeUnit.MILLISECONDS);
	}

	public boolean isProcessed() {
		return processed;
	}
	
	@Override
	public String toString() {
		return "MessageContext: processed: "+processed+", acknowledged: "+acknowledged+", message: "+message;
	}
}
