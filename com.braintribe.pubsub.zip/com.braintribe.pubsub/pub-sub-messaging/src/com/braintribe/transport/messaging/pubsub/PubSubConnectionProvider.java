// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.transport.messaging.pubsub;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

import com.braintribe.logging.Logger;
import com.braintribe.transport.messaging.api.MessagingConnectionProvider;
import com.braintribe.transport.messaging.api.MessagingContext;
import com.braintribe.transport.messaging.api.MessagingException;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.pubsub.v1.ProjectName;

/**
 * <p>
 * {@link MessagingConnectionProvider} implementation for providing {@link PubSubConnection}(s).
 * 
 * @see MessagingConnectionProvider
 * @see PubSubConnection
 */
public class PubSubConnectionProvider implements MessagingConnectionProvider<PubSubConnection> {

	private static final Logger log = Logger.getLogger(PubSubConnectionProvider.class);
	
    private com.braintribe.model.messaging.pubsub.PubSubMessaging providerConfiguration;
    private MessagingContext messagingContext;
	private ProjectName projectName;
	private GoogleCredentials credentials;
	
	private Set<PubSubConnection> connections = new HashSet<>();
	private ReentrantLock connectionsLock = new ReentrantLock();

    public PubSubConnectionProvider() {
    }
    
    public void setConnectionConfiguration(com.braintribe.model.messaging.pubsub.PubSubMessaging providerConfiguration) {
    		this.providerConfiguration = providerConfiguration;
    }
    
    public MessagingContext getMessagingContext() {
		return messagingContext;
	}

	public void setMessagingContext(MessagingContext messagingContext) {
		this.messagingContext = messagingContext;
	}
    
	@Override
	public PubSubConnection provideMessagingConnection() throws MessagingException {

		PubSubConnection connection = new PubSubConnection(providerConfiguration, credentials);
		connection.setProjectName(projectName);
		connection.setMessagingContext(messagingContext);
		
		connectionsLock.lock();
		try {
			connections.add(connection);
		} finally {
			connectionsLock.unlock();
		}
		
		return connection;
		
	}

	@Override
	public synchronized void close() {
		connectionsLock.lock();
		try {
			for (PubSubConnection con : connections) {
				try {
					con.close();
				} catch(Exception e) {
					log.error("Could not close connection: "+con, e);
				}
			}
		} finally {
			connectionsLock.unlock();
		}
	}
	
	public void setProjectName(ProjectName projectName) {
		this.projectName = projectName;
	}

	public void setCredentials(GoogleCredentials credentials) {
		this.credentials = credentials;
	}

	@Override
	public String description() {
		if (providerConfiguration == null) {
			return "PubSub Messaging";
		} else {
			String project = providerConfiguration.getProject();
			if (project == null || project.trim().length() == 0) {
				return "PubSub Messaging";
			} else {
				return "PubSub Messaging for project "+project;
			}
		}
	}
	
	@Override
	public String toString() {
		return description();
	}
	
}
