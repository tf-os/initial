// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.transport.messaging.pubsub.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;

import com.braintribe.logging.Logger;
import com.braintribe.model.processing.bootstrapping.TribefireRuntime;
import com.braintribe.utils.StringTools;

/**
 * Utility class that is used to obtain a unique node Id. This node Id is provided as a constructor parameter.
 * The String may contain either a fixed value or it may also contain wildcards. There are only two
 * parameters supported as wildcards: <code>{uuid}</code> (a unique UUID) and <code>{tfNodeId}</code> (taking the value of
 * the runtime property TRIBEFIRE_NODE_ID. The UUID will only be created once during the lifetime of an instance of this class.
 * Likewise, the TRIBEFIRE_NODE_ID runtime value will also only be retrieved once if it is specified in the nodeId specification.
 */
public class NodeIdSupplier implements Supplier<String> {

	private static final Logger log = Logger.getLogger(NodeIdSupplier.class);
	
	private String nodeIdSpecification;
	private Set<String> variables;
	private String uuid;
	private String envNodeId;
	
	public NodeIdSupplier(String nodeIdSpecification) {
		super();
		this.nodeIdSpecification = nodeIdSpecification;
		this.variables = new HashSet<>();
		
		// We get a list of all variable names and get the corresponding runtime value for later use
		List<String> vars = StringTools.getPatternVariables(nodeIdSpecification);
		for (String var : vars) {
			if (var.equals("uuid")) {
				uuid = UUID.randomUUID().toString();
				this.variables.add(var);
			} else if (var.equals("tfNodeId")) {
				envNodeId = TribefireRuntime.getProperty(TribefireRuntime.ENVIRONMENT_NODE_ID);
				this.variables.add(var);				
			} else {
				log.error("Unsupported variable: "+var);
			}
		}
	}

	@Override
	public String get() {

		String nodeId = null;
		
		if (variables != null && variables.size() > 0) { 
			Map<String,Object> map = new HashMap<String,Object>();
			for (String var : variables) {
				if (var.equals("uuid")) {
					map.put("uuid", this.uuid);					
				} else if (var.equals("tfNodeId")) {
					map.put("tfNodeId", this.envNodeId);			
				}
			}
			nodeId = StringTools.patternFormat(nodeIdSpecification, map); 
		} else {
			nodeId = this.nodeIdSpecification;
		}
		return nodeId;
	}

}
