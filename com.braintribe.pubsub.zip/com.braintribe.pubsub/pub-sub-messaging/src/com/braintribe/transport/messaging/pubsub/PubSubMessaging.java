// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.transport.messaging.pubsub;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.Supplier;

import com.braintribe.cfg.DestructionAware;
import com.braintribe.logging.Logger;
import com.braintribe.transport.messaging.api.Messaging;
import com.braintribe.transport.messaging.api.MessagingContext;
import com.braintribe.transport.messaging.pubsub.util.NodeIdSupplier;
import com.braintribe.utils.lcd.StringTools;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.ServiceOptions;
import com.google.pubsub.v1.ProjectName;

/**
 * <p>
 * Pub/Sub implementation of the GenericModel-based messaging system.
 * 
 * @see Messaging
 */
public class PubSubMessaging implements Messaging<com.braintribe.model.messaging.pubsub.PubSubMessaging>, DestructionAware {

	private static final Logger log = Logger.getLogger(PubSubMessaging.class);
	
	private Set<PubSubConnectionProvider> providers = new HashSet<>();
	private ReentrantLock providersLock = new ReentrantLock();
	
	protected static ScheduledExecutorService scheduledExecutorService;
	private static ReentrantLock scheduledExecutorServiceLock = new ReentrantLock();
	
	private static Supplier<String> nodeIdSupplier = new NodeIdSupplier("{uuid}");
	
	@Override
	public PubSubConnectionProvider createConnectionProvider(com.braintribe.model.messaging.pubsub.PubSubMessaging denotation,
			MessagingContext context) {

		PubSubConnectionProvider connectionProvider = new PubSubConnectionProvider();
		connectionProvider.setConnectionConfiguration(denotation);
		connectionProvider.setMessagingContext(context);

		String project = denotation.getProject();
		ProjectName projectName = ProjectName.of(project);
		connectionProvider.setProjectName(projectName);

		String credentialsSettings = denotation.getCredentials();
		if (StringTools.isBlank(credentialsSettings)) {
			throw new RuntimeException("The credentials must not be empty.");
		}

		GoogleCredentials credentials = CredentialsLoader.retrieveCredentials(credentialsSettings); 
		if (credentials == null) {
			throw new RuntimeException("Could not get credentials from configuration: "+credentialsSettings);
		}

		connectionProvider.setCredentials(credentials);
		
		String defaultId = ServiceOptions.getDefaultProjectId();
		log.debug("Initialized PubSub messaging. Selected project: "+project+", default project: "+defaultId);

		String nodeIdSpecification = denotation.getNodeId();
		if (!StringTools.isEmpty(nodeIdSpecification)) {
			nodeIdSupplier = new NodeIdSupplier(nodeIdSpecification);
		}
		
		providersLock.lock();
		try {
			providers.add(connectionProvider);
		} finally {
			providersLock.unlock();
		}
		
		return connectionProvider;

	}
	
	protected static String getNodeId() {
		return nodeIdSupplier.get();
	}
	
	protected static ScheduledExecutorService getScheduledExecutorService() {
		if (scheduledExecutorService == null) {
			scheduledExecutorServiceLock.lock();
			try {
				if (scheduledExecutorService == null) {
					scheduledExecutorService = Executors.newScheduledThreadPool(10);
				}
			} finally {
				scheduledExecutorServiceLock.unlock();
			}
		}
		return scheduledExecutorService;
	}
	

	@Override
	public void preDestroy() {
		providersLock.lock();
		try {
			for (PubSubConnectionProvider p : providers) {
				try {
					p.close();
				} catch(Exception e) {
					log.error("Error while closing connection provider: "+p, e);
				}
			}
		} finally {
			providersLock.unlock();
		}
		if (scheduledExecutorService != null) {
			scheduledExecutorService.shutdown();
		}
	}

}
