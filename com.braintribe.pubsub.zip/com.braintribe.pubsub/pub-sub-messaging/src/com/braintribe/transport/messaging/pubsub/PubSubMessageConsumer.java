// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.transport.messaging.pubsub;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

import com.braintribe.codec.marshaller.api.MarshallException;
import com.braintribe.logging.Logger;
import com.braintribe.model.messaging.Destination;
import com.braintribe.model.messaging.Message;
import com.braintribe.model.messaging.Topic;
import com.braintribe.transport.messaging.api.MessageConsumer;
import com.braintribe.transport.messaging.api.MessageListener;
import com.braintribe.transport.messaging.api.MessageProperties;
import com.braintribe.transport.messaging.api.MessagingComponentStatus;
import com.braintribe.transport.messaging.api.MessagingException;
import com.google.api.gax.core.FixedExecutorProvider;
import com.google.api.gax.rpc.NotFoundException;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.pubsub.v1.AckReplyConsumer;
import com.google.cloud.pubsub.v1.Subscriber;
import com.google.cloud.pubsub.v1.SubscriptionAdminClient;
import com.google.cloud.pubsub.v1.SubscriptionAdminSettings;
import com.google.protobuf.ByteString;
import com.google.pubsub.v1.ProjectName;
import com.google.pubsub.v1.ProjectSubscriptionName;
import com.google.pubsub.v1.ProjectTopicName;
import com.google.pubsub.v1.PubsubMessage;
import com.google.pubsub.v1.Subscription;
import com.google.pubsub.v1.TopicName;

/**
 * <p>
 * {@link MessageConsumer} implementation for {@link PubSubMessaging}.
 * 
 * @see MessageConsumer
 */
public class PubSubMessageConsumer extends PubSubAbstractMessageHandler implements MessageConsumer {

	private static final Logger log = Logger.getLogger(PubSubMessageConsumer.class);


	private MessageListener messageListener;

	private MessagingComponentStatus status = MessagingComponentStatus.NEW;

	private ConsumptionMode consumptionMode;

	private ProjectName projectName;

	private Subscriber subscriber;
	private Subscription createdSubscription; 
	private ProjectSubscriptionName subscriptionName; 

	private LinkedBlockingQueue<MessageContext> messageQueue = new LinkedBlockingQueue<>();


	private com.braintribe.model.messaging.pubsub.PubSubMessaging providerConfiguration;
	private static AtomicLong consumerCounter = new AtomicLong(0);


	private GoogleCredentials credentials;

	private enum ConsumptionMode {
		SYNC, ASYNC;
	}
	
	private static final int MIN_RESOURCE_NAME_LENGTH = 3;
	private static final int MAX_RESOURCE_NAME_LENGTH = 255;

	public PubSubMessageConsumer(ProjectName projectName, Destination destination, com.braintribe.model.messaging.pubsub.PubSubMessaging providerConfiguration, GoogleCredentials credentials) {
		super();
		this.projectName = projectName;
		super.setDestination(destination);
		this.providerConfiguration = providerConfiguration;
		this.credentials = credentials;
	}


	@Override
	public MessageListener getMessageListener() throws MessagingException {
		return messageListener;
	}

	@Override
	public void setMessageListener(MessageListener messageListener) throws MessagingException {
		this.messageListener = messageListener;

		//consumption starts whenever a not null message listener is registered to this consumer
		if (this.messageListener != null) {
			startDelegateConsumption(ConsumptionMode.ASYNC);
		}
	}

	@Override
	public Message receive() throws MessagingException {
		return receive(0);
	}

	@Override
	public Message receive(long timeout) throws MessagingException {

		startDelegateConsumption(ConsumptionMode.SYNC);

		while (true) {

			MessageContext messageContext = null;
			try {

				if (timeout > 0) {
					messageContext = messageQueue.poll(timeout, TimeUnit.MILLISECONDS);
				} else {
					messageContext = messageQueue.take();
				}

				if (messageContext == null) {
					return null;
				}

			} catch (InterruptedException e) {

				if (log.isDebugEnabled()) {
					log.debug("Consumer call on nextDelivery() was interrupted"+(e.getMessage() != null ? ": "+e.getMessage() : ""), e);
				}

				return null;

			} catch (Exception e) {

				if (messageContext != null) {
					messageContext.nack();
				}

				throw new MessagingException("failed to consume message: "+e.getMessage(), e);
			}

			messageContext.ack();

			return messageContext.getMessage();
		}

	}

	@Override
	public void close() throws MessagingException {
		if (status == MessagingComponentStatus.CLOSED) {
			log.debug(() -> "Producer is already closed");
			return;
		}

		if (this.subscriber != null) {
			try {
				this.subscriber.stopAsync().awaitTerminated();
			} catch(Exception e) {
				log.error("Error while shutting down publisher.", e);
			}
		}

		getSession().unregisterMessageConsumer(this);

		if (getDestination() instanceof Topic) {
			try {
				deleteSubscription(subscriptionName);
			} catch (Exception e) {
				log.error("Error while trying to delete queue subscription: "+subscriptionName, e);
			}
		}

		status = MessagingComponentStatus.CLOSED;
	}

	private void deleteSubscription(ProjectSubscriptionName subscriptionName) throws Exception {

		SubscriptionAdminSettings subscriptionAdminSettings = SubscriptionAdminSettings.newBuilder()
				.setCredentialsProvider(() -> credentials)
				.build();

		try (SubscriptionAdminClient subscriptionAdminClient = SubscriptionAdminClient.create(subscriptionAdminSettings)) {
			subscriptionAdminClient.deleteSubscription(subscriptionName);
			log.debug(() -> "Deleted: "+subscriptionName);
		}
	}


	protected synchronized void open() throws MessagingException {
		if (subscriber != null) {
			return;
		}
		try {
			prepareConsumerDestination();

			subscriber = Subscriber.newBuilder(subscriptionName, this::receiveMessage)
					.setCredentialsProvider(() -> credentials)
					.setExecutorProvider(FixedExecutorProvider.create(PubSubMessaging.getScheduledExecutorService()))
					.build();
			subscriber.startAsync();

			status = MessagingComponentStatus.OPEN;

		} catch (Exception e) {
			throw new MessagingException("Failed to start consumer: "+e.getMessage(), e);
		}
	}

	/**
	 * <p>
	 * Starts the consumption for this consumer under the given {@code mode}.
	 * 
	 * <p>
	 * This method is a no-op if this consumer was already initialized under the given {@code mode}.
	 * 
	 * <p>
	 * This method will halt with a {@link MessagingException} if this consumer was already initialized with a different
	 * consumption mode than the given {@code mode}.
	 * 
	 * @param mode
	 *            The {@link ConsumptionMode}, currently supported options are: asynchronous (
	 *            {@link ConsumptionMode#ASYNC}) and synchronous ({@link ConsumptionMode#SYNC})
	 * @throws MessagingException
	 *             If:
	 *             <ul>
	 *             <li>The given {@link ConsumptionMode} is not supported;
	 *             <li>This consumer was already initialized with a different {@link ConsumptionMode};
	 *             <li>The consumption initialization fails;
	 *             </ul>
	 */
	protected synchronized void startDelegateConsumption(ConsumptionMode mode) throws MessagingException {

		if (status == MessagingComponentStatus.NEW) {
			open();
			consumptionMode = mode;
		}

		if (consumptionMode != mode) {
			throw new MessagingException("Failed to start consumption in [ "+mode+" ] mode for this consumer as it was already started as [ "+consumptionMode+" ]");
		}

	}

	protected Message extractMessage(Map<String,String> headers, final PubsubMessage psMessage) {

		Message message = null;

		String contentType = headers.get(PROP_CONTENTTYPE);

		ByteString byteString = psMessage.getData();
		byte[] body = byteString.toByteArray();

		if (body != null && body.length > 0) {

			try {

				log.trace(() -> "Extracting message received from "+getDestination().getName()+" of type "+contentType);

				message = getMessagingContext().unmarshallMessage(body);

				if (log.isTraceEnabled()) log.trace("Extracted message received from "+getDestination().getName()+": "+message);

			} catch (MarshallException e) {
				log.error("Failed to extract "+Message.class.getName()+" from the given payload due to: "+e.getMessage(), e);
			}
		} else {
			if (log.isWarnEnabled()) {
				log.warn("Unable to extract a "+Message.class.getName()+" based on the content type [ "+contentType+" ] and payload [ "+body+" ]");
			}
		}

		return message;
	}

	protected boolean matchesAddressee(Map<String,String> headers) {

		if (headers == null || headers.isEmpty()) {
			return true;
		}

		Object appId, nodeId;

		// @formatter:off
		return !(
				(
						(appId = headers.get(propertyPrefix+MessageProperties.addreseeAppId.getName())) != null && 
						!appId.toString().equals(getApplicationId())
						) || (
								(nodeId = headers.get(propertyPrefix+MessageProperties.addreseeNodeId.getName())) != null && 
								!nodeId.toString().equals(getNodeId())
								)
				);
		// @formatter:on

	}

	private void prepareConsumerDestination() throws MessagingException {
		if (createdSubscription != null) {
			return;
		}
		try {
			ProjectTopicName topicName = ProjectTopicName.of(projectName.getProject(), getDestination().getName());

			String subscriptionId = "subscription_"+getDestination().getName();
			if (getDestination() instanceof Topic) {
				long count = consumerCounter.incrementAndGet();
				String countString = Long.toString(count, 16);
				String postFix = "-"+com.braintribe.transport.messaging.pubsub.PubSubMessaging.getNodeId()+"-"+countString+"-"+UUID.randomUUID().toString();
				
				subscriptionId = normalizeResourceName(subscriptionId, 0, MAX_RESOURCE_NAME_LENGTH-postFix.length(), false);
				subscriptionId += postFix;
			} else {
				subscriptionId = normalizeResourceName(subscriptionId, MIN_RESOURCE_NAME_LENGTH, MAX_RESOURCE_NAME_LENGTH, true);
			}
			
			subscriptionName = ProjectSubscriptionName.of(projectName.getProject(), subscriptionId);
			if (!subscriptionExists(subscriptionName)) {
				subscribe(topicName, subscriptionName);
			}
		} catch(Exception e) {
			throw new MessagingException("Error while trying to subscribe to topic "+getDestination().getName(), e);
		}
	}

	/**
	 * Makes sure that the provided resource name adheres to the rules.
	 * The name must start with a letter, may only contain a-z, A-Z, 0-9, -, _, ~, +, %
	 * <br>
	 * The length must be between 3 and 255. It must not start with "goog".
	 * If the provided name is too short, X will be appended at the end. If the name is
	 * too long, it will be cut at position 255. Every character in the name that does not follow
	 * the rules above will be URL encoded.
	 * 
	 * @param resourceName The name that has to be normalized.
	 * @param maxLength The maximum length that this method is allowed to return.
	 * @param lengthExceedIsFatal If true and the resulting name exceeds the maximum length, an IllegalArgumentException will be thrown. If this is false, the name will be simply truncated.
	 * @return The sanitized resource name.
	 * @throws IllegalArgumentException Thrown if the length of the resulting name exceeds the maximum length (thrown if lengthExceedIsFatal is true). Also thrown if the maxLength is non-positive or lower than minLength.
	 * @throws NullPointerException Thrown if the resource name provided is null
	 * @see <a href="https://cloud.google.com/pubsub/docs/overview#names">Names</a>
	 */
	protected static String normalizeResourceName(String resourceName, int minLength, int maxLength, boolean lengthExceedIsFatal) throws IllegalArgumentException {
		if (resourceName == null) {
			throw new NullPointerException("The resourceName must not be null.");
		}
		if (minLength > maxLength || maxLength <= 0) {
			throw new IllegalArgumentException("The minLength ("+minLength+") and maxLength ("+maxLength+") are not valid.");
		}
		char[] charArray = resourceName.toCharArray();
		StringBuilder sb = new StringBuilder();
		for (int i=0; i<charArray.length; ++i) {
			char c = charArray[i];
			if ((c >= 'a' && c <= 'z') || 
					(c >= 'A' && c <= 'Z') || 
					(c >= '0' && c <= '9') ||
					(c == '-') || (c == '_') || (c == '.') || (c == '~') || (c == '+') || (c == '%')) {
				sb.append(c);
			} else {
				try {
					sb.append(URLEncoder.encode(Character.toString(c), "UTF-8"));
				} catch (UnsupportedEncodingException e) {
					throw new RuntimeException("Could not URL encode character '"+c+"'.", e);
				}
			}
		}
		
		char first = sb.charAt(0);
		if (!((first >= 'a' && first <= 'z') || (first >= 'A' && first <= 'Z'))) {
			sb.insert(0, 'X');
		} else if (sb.toString().startsWith("goog")) {
			sb.insert(0, 'X');
		}
		while (sb.length() < minLength) {
			sb.append("X");
		}

		if (sb.length() > maxLength) {
			if (lengthExceedIsFatal) {
				throw new IllegalArgumentException("The resource name "+resourceName+" results in "+sb.toString()+" which exceed the maximum length of "+maxLength);
			} else {
				return sb.substring(0, maxLength);
			}
		} else {
			return sb.toString();
		}
	}

	private void subscribe(TopicName topicName, ProjectSubscriptionName subscription) throws Exception {

		SubscriptionAdminSettings subscriptionAdminSettings = SubscriptionAdminSettings.newBuilder()
				.setCredentialsProvider(() -> credentials)
				.build();

		try (SubscriptionAdminClient subscriptionAdminClient = SubscriptionAdminClient.create(subscriptionAdminSettings)) {
			Subscription request = Subscription.newBuilder()
					.setName(subscription.toString())
					.setTopic(topicName.toString())
					.build();
			createdSubscription = subscriptionAdminClient.createSubscription(request);
		}
	}

	private boolean subscriptionExists(ProjectSubscriptionName subscription) throws Exception {

		SubscriptionAdminSettings subscriptionAdminSettings = SubscriptionAdminSettings.newBuilder()
				.setCredentialsProvider(() -> credentials)
				.build();

		try (SubscriptionAdminClient subscriptionAdminClient = SubscriptionAdminClient.create(subscriptionAdminSettings)) {

			try {
				subscriptionAdminClient.getSubscription(subscription);
			} catch(NotFoundException nfe) {
				return false;
			}
			return true;
		}
	}

	private void receiveMessage(final PubsubMessage message, final AckReplyConsumer consumer) {
		log.trace(() -> "Received message: "+message);

		if (messageListener == null && consumptionMode == ConsumptionMode.ASYNC) {
			if (log.isWarnEnabled()) {
				log.warn("Message will not be acknowledged as there is no message listener registered");
			}
			return;
		}

		Map<String,String> headers = super.readMessageProperties(message);


		if (!matchesAddressee(headers)) {
			if (log.isDebugEnabled()) {
				log.trace("Delivery ignored due to addresse headers mismatch: " + headers);
			}
			try {
				consumer.ack();
			} catch (Exception e) {
				log.error("Failed to ack message ignored due to addresee headers mismatch", e);
			}
			return;
		}

		Message extractedMessage = extractMessage(headers, message);

		if (extractedMessage == null) {
			// An unmarshallable message is ack'ed and ignored for the consumer health's sake
			consumer.ack();
			return;
		}

		if (consumptionMode == ConsumptionMode.ASYNC) {
			try {
				messageListener.onMessage(extractedMessage);
			} catch(MessagingException me) {
				log.error("Error while processing message: "+extractedMessage, me);
				return;
			} finally {
				consumer.ack();
			}


		} else {
			MessageContext context = new MessageContext(message, extractedMessage, consumer);
			try {
				messageQueue.put(context);
			} catch (InterruptedException e) {
				log.debug(() -> "Interrupted while waiting for a free slot in the message queue.");
				consumer.nack();
				return;
			}

			try {
				context.waitForAck(providerConfiguration.getProcessingTimeout());
			} catch (InterruptedException e) {
				log.debug(() -> "Interrupted while waiting for the processing of received message: "+extractedMessage);
				//Ack'ing the message because we are still able to process the message
				consumer.ack();
				return;
			}
		}

	}


}
