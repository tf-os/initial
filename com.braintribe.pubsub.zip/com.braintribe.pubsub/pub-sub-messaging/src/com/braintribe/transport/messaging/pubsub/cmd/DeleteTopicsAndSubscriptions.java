// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.transport.messaging.pubsub.cmd;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.atomic.AtomicInteger;

import com.braintribe.transport.messaging.pubsub.CredentialsLoader;
import com.braintribe.utils.FileTools;
import com.braintribe.utils.StringTools;
import com.braintribe.utils.date.NanoClock;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.pubsub.v1.SubscriptionAdminClient;
import com.google.cloud.pubsub.v1.SubscriptionAdminSettings;
import com.google.cloud.pubsub.v1.TopicAdminClient;
import com.google.cloud.pubsub.v1.TopicAdminClient.ListTopicSubscriptionsPage;
import com.google.cloud.pubsub.v1.TopicAdminClient.ListTopicSubscriptionsPagedResponse;
import com.google.cloud.pubsub.v1.TopicAdminClient.ListTopicsPage;
import com.google.cloud.pubsub.v1.TopicAdminClient.ListTopicsPagedResponse;
import com.google.cloud.pubsub.v1.TopicAdminSettings;
import com.google.pubsub.v1.ListTopicSubscriptionsResponse;
import com.google.pubsub.v1.ListTopicsResponse;
import com.google.pubsub.v1.ProjectName;
import com.google.pubsub.v1.ProjectTopicName;
import com.google.pubsub.v1.Topic;

/**
 * This command line tool can be used to delete all topics (and their subscriptions) that start with a specific prefix.
 * It takes 3 arguments:
 * 
 * The security key
 * The project name
 * The prefix of the topics to be deleted
 * 
 * The returning error code 0 indicates that everything went fine. Errors will be output to System.err, everything else on System.out.
 * See the static variables for an explanation of the various error codes.
 */
public class DeleteTopicsAndSubscriptions {

	private final static int ERROR_CODE_INVALID_PARAMS        = 1;
	private final static int ERROR_CODE_NO_CREDENTIALS        = 2;
	private final static int ERROR_CODE_NO_PROJECT            = 3;
	private final static int ERROR_CODE_NO_PREFIX             = 4;
	private final static int ERROR_CODE_INVALID_CREDENTIALS   = 5;
	private final static int ERROR_CODE_TADMIN_CREATION_ERROR = 6;
	private final static int ERROR_CODE_SADMIN_CREATION_ERROR = 7;
	private final static int ERROR_CODE_TOPIC_ERROR           = 8;
	private final static int ERROR_CODE_UNEXPECTED_ERROR      = 9;
	private final static int ERROR_CODE_UNSUCCESSFUL          = 10;
	private final static int ERROR_CODE_OK                    = 0;

	private String credentialsString;
	private String projectName;
	private String prefix;

	private GoogleCredentials credentials;
	private AtomicInteger examinedTopics = new AtomicInteger(0);
	private AtomicInteger deletedTopics = new AtomicInteger(0);
	private AtomicInteger unsuccessfulDeletedTopics = new AtomicInteger(0);
	private AtomicInteger deletedSubscriptions = new AtomicInteger(0);
	private AtomicInteger unsuccessfulDeletedSubscriptions = new AtomicInteger(0);

	public static void main(String[] args) {
		if (args == null || args.length != 3) {
			System.err.println("Please provide the following parameters: <security JSON (directly, name of an environment variable, or a file path)> <project name> <prefix>");
			System.exit(ERROR_CODE_INVALID_PARAMS);
		}

		String credentialsString = args[0];
		String projectName = args[1];
		String prefix = args[2];

		if (StringTools.isBlank(credentialsString)) {
			System.err.println("The credentials are empty.");
			System.exit(ERROR_CODE_NO_CREDENTIALS);
		}
		if (StringTools.isBlank(projectName)) {
			System.err.println("The project name is empty.");
			System.exit(ERROR_CODE_NO_PROJECT);
		}
		if (StringTools.isBlank(prefix)) {
			System.err.println("The prefix is empty.");
			System.exit(ERROR_CODE_NO_PREFIX);
		}

		String normalizedPrefix = FileTools.normalizeFilename(prefix, '_');

		System.out.println("Deleting all topics/subscriptions of project \""+projectName+"\" with prefix \""+normalizedPrefix+"\"");

		DeleteTopicsAndSubscriptions app = new DeleteTopicsAndSubscriptions(credentialsString, projectName, normalizedPrefix);
		try {
			app.connect();
			
			boolean success = app.removeTopicsAndSubscriptions();

			System.out.println("Success: "+success);

			if (success) {
				System.exit(ERROR_CODE_OK);
			} else {
				System.exit(ERROR_CODE_UNSUCCESSFUL);
			}

		} catch(Exception e) {
			e.printStackTrace(System.err);
			System.exit(ERROR_CODE_UNEXPECTED_ERROR);
		}

	}

	private DeleteTopicsAndSubscriptions(String credentialsString, String projectName, String prefix) {
		this.credentialsString = credentialsString;
		this.projectName = projectName;
		this.prefix = prefix;
	}

	private void connect() {
		Instant start = NanoClock.INSTANCE.instant();

		credentials = CredentialsLoader.retrieveCredentials(credentialsString); 
		if (credentials == null) {
			System.err.println("Could not get credentials from configuration: "+credentialsString);
			System.exit(ERROR_CODE_INVALID_CREDENTIALS);
		}
		
		System.out.println("Retrieved credentials in "+StringTools.prettyPrintDuration(start, true, ChronoUnit.MILLIS));
	}

	private boolean removeTopicsAndSubscriptions() {
		Instant start = NanoClock.INSTANCE.instant();

		TopicAdminSettings topicAdminSettings = null;
		try {
			topicAdminSettings = TopicAdminSettings.newBuilder().setCredentialsProvider(() -> credentials).build();
		} catch (Exception e) {
			e.printStackTrace(System.err);
			System.exit(ERROR_CODE_TADMIN_CREATION_ERROR);
		}
		SubscriptionAdminSettings subscriptionAdminSettings = null;
		try {
			subscriptionAdminSettings = SubscriptionAdminSettings.newBuilder().setCredentialsProvider(() -> credentials).build();
		} catch(Exception e) {
			e.printStackTrace(System.err);
			System.exit(ERROR_CODE_SADMIN_CREATION_ERROR);			
		}

		ProjectName project = ProjectName.of(projectName);

		String expectedPrefix = "projects/"+projectName+"/topics/"+prefix+".";

		try (TopicAdminClient topicAdminClient = TopicAdminClient.create(topicAdminSettings); 
				SubscriptionAdminClient subscriptionAdminClient = SubscriptionAdminClient.create(subscriptionAdminSettings)) {

			ListTopicsPagedResponse listTopics = topicAdminClient.listTopics(project);

			for (ListTopicsPage page : listTopics.iteratePages()) {
				ListTopicsResponse response = page.getResponse();
				for (Topic topic : response.getTopicsList()) {
					String foundName = topic.getName();

					examinedTopics.incrementAndGet();

					if (foundName.startsWith(expectedPrefix)) {
						ProjectTopicName projectTopicName = ProjectTopicName.of(projectName, foundName);
						deleteTopic(topicAdminClient, subscriptionAdminClient, projectTopicName);
					}
				}
			}

		} catch(Exception e) {
			System.err.println("Error while listing/deleting topics.");
			e.printStackTrace(System.err);
			System.exit(ERROR_CODE_TOPIC_ERROR);
		}
		
		System.out.println("Finished cleanup in "+StringTools.prettyPrintDuration(start, true, ChronoUnit.MILLIS));
		System.out.println("Topics examined:              "+examinedTopics.get());
		System.out.println("Topics deleted:               "+deletedTopics.get());
		System.out.println("Topic deletion errors:        "+unsuccessfulDeletedTopics.get());
		System.out.println("Subscriptions deleted:        "+deletedSubscriptions.get());
		System.out.println("Subscription deletion errors: "+unsuccessfulDeletedSubscriptions.get());
		
		if (unsuccessfulDeletedTopics.get() > 0 || unsuccessfulDeletedSubscriptions.get() > 0) {
			return false;
		}
		return true;
	}

	private void deleteTopic(TopicAdminClient topicAdminClient, SubscriptionAdminClient subscriptionAdminClient, ProjectTopicName projectTopicName) {
		if (projectTopicName == null) {
			return;
		}

		Instant start = NanoClock.INSTANCE.instant();
		
		int subscriptionCount = 0;
		

		ListTopicSubscriptionsPagedResponse listTopicSubscriptions = topicAdminClient.listTopicSubscriptions(projectTopicName.getTopic());
		for (ListTopicSubscriptionsPage page : listTopicSubscriptions.iteratePages()) {

			ListTopicSubscriptionsResponse response = page.getResponse();
			for (String subscriptionName : response.getSubscriptionsList()) {

				try {
					subscriptionAdminClient.deleteSubscription(subscriptionName);
					deletedSubscriptions.incrementAndGet();
					subscriptionCount++;

				} catch(Exception e) {
					unsuccessfulDeletedSubscriptions.incrementAndGet();
					System.err.println("Could not delete subscription \""+subscriptionName+"\" of topic \""+projectTopicName.getTopic()+"\"");
					e.printStackTrace(System.err);
				}
			}

		}
		try {
			topicAdminClient.deleteTopic(projectTopicName.getTopic());

			deletedTopics.incrementAndGet();
			
			System.out.println("Deleted topic: \""+projectTopicName.getTopic()+"\" ("+subscriptionCount+" subscriptions) in "+StringTools.prettyPrintDuration(start, true, ChronoUnit.MILLIS));
			
		} catch(Exception e) {
			unsuccessfulDeletedTopics.incrementAndGet();
			System.err.println("Could not delete topic \""+projectTopicName.getTopic()+"\".");
			e.printStackTrace(System.err);
		}


	}

}
