// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.processing.query.smart.test2.unmapped.model.smart;

import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;
import com.braintribe.model.processing.query.smart.test2.unmapped.model.accessA.SimpleUnmappedA;

/**
 * This type is mapped, but has a property that is not mapped - which should be treated as if it was always null.
 * 
 */
public interface UnmappedPropertySmart extends SimpleUnmappedA {

	String mappedSubName = "mappedSubName";
	String unmappedSubName = "unmappedSubName";
	String unmappedEntity = "unmappedEntity";

	EntityType<UnmappedPropertySmart> T = EntityTypes.T(UnmappedPropertySmart.class);

	String getMappedSubName();
	void setMappedSubName(String mappedSubName);

	String getUnmappedSubName();
	void setUnmappedSubName(String unmappedSubName);

	UnmappedTopLevelTypeSmart getUnmappedEntity();
	void setUnmappedEntity(UnmappedTopLevelTypeSmart unmappedEntity);
	
}
