// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.processing.query.smart.test.debug;

import com.braintribe.model.processing.query.test.debug.TupleSetViewer;
import com.braintribe.model.processing.smart.query.planner.SmartQueryPlanPrinter;
import com.braintribe.model.query.SelectQuery;
import com.braintribe.model.queryplan.set.TupleSet;
import com.braintribe.model.smartqueryplan.SmartQueryPlan;

public class SmartTupleSetViewer extends TupleSetViewer {

	public static void view(String testName, SelectQuery query, SmartQueryPlan plan) {
		printTestName(testName);
		System.out.println("Query: " + SmartQueryPlanPrinter.print(query) + "\n");
		System.out.println("Total component count: " + plan.getTotalComponentCount());
		System.out.println(SmartQueryPlanPrinter.print(plan.getTupleSet(), true));
		printTestBottomBorder();
	}

	public static void view(String testName, TupleSet set) {
		printTestName(testName);
		System.out.println(SmartQueryPlanPrinter.print(set, true));
		printTestBottomBorder();
	}

}
