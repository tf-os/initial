// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.query.smart.processing.eval.context;

import com.braintribe.model.processing.query.eval.api.QueryEvaluationContext;
import com.braintribe.model.processing.query.eval.api.Tuple;
import com.braintribe.model.processing.query.eval.context.ConditionEvaluator;
import com.braintribe.model.queryplan.filter.Condition;
import com.braintribe.model.queryplan.filter.ConditionType;
import com.braintribe.model.smartqueryplan.filter.SmartFullText;

/**
 * 
 */
public class SmartConditionEvaluator extends ConditionEvaluator {

	private static final SmartConditionEvaluator instance = new SmartConditionEvaluator();

	private SmartConditionEvaluator() {
	}

	public static SmartConditionEvaluator getInstance() {
		return instance;
	}

	@Override
	public boolean evaluate(Tuple tuple, Condition condition, QueryEvaluationContext context) {
		if (condition.conditionType() == ConditionType.fullText) {
			return SmartFulltextComparator.matches(tuple, (SmartFullText) condition);

		} else {
			return super.evaluate(tuple, condition, context);
		}

	}

}
