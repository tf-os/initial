// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.processing.smart.query.planner.tools;

import com.braintribe.model.generic.reflection.GenericModelType;
import com.braintribe.model.meta.GmType;
import com.braintribe.model.processing.query.tools.SourceTypeResolver;
import com.braintribe.model.query.Source;

/**
 * 
 */
public class SourceGmTypeResolver {

	public static GmType resolveGmType(Source source) {
		return resolveGmType(SourceTypeResolver.<GenericModelType> resolveType(source));
	}

	@SuppressWarnings("unused")
	public static GmType resolveGmType(GenericModelType type) {
		throw new UnsupportedOperationException("Method 'SourceGmTypeResolver.resolveGmType' is not implemented yet!");

	}

}
