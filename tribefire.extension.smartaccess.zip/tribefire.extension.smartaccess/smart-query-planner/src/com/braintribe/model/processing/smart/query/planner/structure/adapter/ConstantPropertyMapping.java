// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.processing.smart.query.planner.structure.adapter;

import java.util.Map;

/**
 */
public class ConstantPropertyMapping {

	/** Maps smart type signature to the mapped value */
	public final Map<String, Object> smartToValue;
	/** Maps delegate type signature to the mapped value */
	public final Map<String, Object> delegateToValue;

	public final boolean isStatic;

	public ConstantPropertyMapping(Map<String, Object> smartToValue, Map<String, Object> delegateToValue) {
		this.smartToValue = smartToValue;
		this.delegateToValue = delegateToValue;
		this.isStatic = smartToValue.size() == 1; // we assume there is at least one element
	}

}
