// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.processing.query.smart.eval.set.base;

import com.braintribe.model.processing.query.fluent.SelectQueryBuilder;
import com.braintribe.model.processing.query.smart.test.model.accessB.PersonB;
import com.braintribe.model.query.SelectQuery;

public class SmartSelectQueryBuilder {
	
	protected SelectQuery buildTemplatedCorrelationQuery() {
		// @formatter:off
		SelectQuery correlationQuery = new SelectQueryBuilder()
				.from(PersonB.class, "pB")
				.where()
				.conjunction()
					.property("pB","companyNameB").eq("Get Smart")
					.disjunction()
						.conjunction()
							.property("pB","correlationB").ne(null)
						.close()
					.close()
				.close()
				.done();
		// @formatter:on

		return correlationQuery;

	}


}
