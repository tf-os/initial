import Contract from "./contractDesigner.js";

export let contract = new Contract();