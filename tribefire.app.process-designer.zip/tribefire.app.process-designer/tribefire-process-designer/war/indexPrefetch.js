import Contract from "./contractPrefetch.js";

export let contract = new Contract();