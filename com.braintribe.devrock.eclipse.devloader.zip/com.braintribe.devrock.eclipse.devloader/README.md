# com.braintribe.devrock.eclipse.devloader
The repository provides an extended version of the dev-loader from Eclipse Tomcat Plugin.
For more information about the extensions and modifications see the Javadoc documentation of DevLoader.java.
