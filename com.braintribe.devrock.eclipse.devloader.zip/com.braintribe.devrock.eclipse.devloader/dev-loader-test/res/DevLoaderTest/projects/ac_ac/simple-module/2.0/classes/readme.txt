This folder would normally contain compiled Java classes (from Eclipse).
