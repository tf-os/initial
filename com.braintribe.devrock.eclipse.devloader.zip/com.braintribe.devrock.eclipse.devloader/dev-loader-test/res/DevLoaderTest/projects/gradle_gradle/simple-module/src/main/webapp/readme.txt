This folder would normally contain the web app files. 
