The DevLoader is part of Eclipse Tomcat Plugin (forked from Sysdeo).
We extracted the source code and slightly adapted it to improve support for various build tools.

The DevLoader is compatible with Tomcat 8.5.x and Eclipse Tomcat Plugin 9.1.2.
It requires at Java 7 or later.
