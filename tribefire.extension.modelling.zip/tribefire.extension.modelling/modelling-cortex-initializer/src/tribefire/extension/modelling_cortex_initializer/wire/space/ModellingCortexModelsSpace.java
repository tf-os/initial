// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.modelling_cortex_initializer.wire.space;

import com.braintribe.model.meta.GmMetaModel;
import com.braintribe.wire.api.annotation.Import;
import com.braintribe.wire.api.annotation.Managed;

import tribefire.cortex.initializer.support.integrity.wire.contract.CoreInstancesContract;
import tribefire.cortex.initializer.support.wire.space.AbstractInitializerSpace;
import tribefire.extension.modelling.commons.ModellingConstants;
import tribefire.extension.modelling_cortex_initializer.wire.contract.ExistingInstancesContract;
import tribefire.extension.modelling_cortex_initializer.wire.contract.ModellingCortexModelsContract;

@Managed
public class ModellingCortexModelsSpace extends AbstractInitializerSpace implements ModellingCortexModelsContract, ModellingConstants {

	@Import
	private ExistingInstancesContract existingInstances;
	
	@Import
	private CoreInstancesContract coreInstances;
	
	@Managed
	@Override
	public GmMetaModel managementWbModel() {
		GmMetaModel bean = create(GmMetaModel.T);		
		
		bean.setName(NAME_MANAGEMENT_WB_MODEL);
		
		bean.getDependencies().add(existingInstances.managementModel());		
		bean.getDependencies().add(existingInstances.managementApiModel());		
		
		bean.getDependencies().add(coreInstances.workbenchModel());
		
		return bean;
	}
	
	@Managed
	@Override
	public GmMetaModel projectWbModel() {
		GmMetaModel bean = create(GmMetaModel.T);		
		
		bean.setName(NAME_MODELLING_WB_MODEL);
		
		bean.getDependencies().add(existingInstances.modellingApiModel());		
		
		bean.getDependencies().add(coreInstances.workbenchModel());
		
		return bean;
	}
	
	@Managed
	@Override
	public GmMetaModel projectModel() {
		GmMetaModel bean = create(GmMetaModel.T);		
		
		bean.setName(NAME_MODELLING_MODEL);
		bean.getDependencies().add(existingInstances.modellingProjectModel());
		
		return bean;
	}
}
