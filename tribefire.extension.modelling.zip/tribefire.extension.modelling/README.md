# Tribefire Model Designer

## Setup

Run the following command to setup the model designer:

```jinni setup-local-tomcat-platform tribefire.extension.modelling:model-designer-setup#1.0 --installationPath <Your Path>```
