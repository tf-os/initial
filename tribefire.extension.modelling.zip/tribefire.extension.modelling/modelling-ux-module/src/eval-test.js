/// <reference path="../com.braintribe.gm.gm-core-api-1.0~/gm-core-api.d.ts"/>
/// <reference path="../com.braintribe.gm.basic-resource-model-1.0~/basic-resource-model.d.ts"/>
