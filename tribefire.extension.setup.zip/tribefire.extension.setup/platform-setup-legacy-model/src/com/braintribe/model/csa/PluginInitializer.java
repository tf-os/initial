// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.csa;

import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

/**
 * {@link SmoodInitializer} that is resolved via the plugin mechanism (see
 * com.braintribe.model.processing.plugin.PluginManager). This can be used to define java based initializer as a plugin.
 * 
 */
public interface PluginInitializer extends SmoodInitializer {

	EntityType<PluginInitializer> T = EntityTypes.T(PluginInitializer.class);

	/** If null, defaults to {@link #getName() name}. */
	String getSelector();
	void setSelector(String selector);

	@Override
	default void normalize() {
		if (getSelector() == null)
			setSelector(getName());
	}

}