// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.tribefire.jinni.cmdline.impl;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.GenericModelType;
import com.braintribe.model.generic.reflection.Property;
import com.braintribe.model.jinni.api.JinniOptions;
import com.braintribe.model.processing.session.api.managed.ModelAccessory;
import com.braintribe.model.service.api.ServiceRequest;
import com.braintribe.tribefire.jinni.cmdline.api.ParsedCommandLine;

public class JinniLegacyCommandLineParser extends AbstractCommandLineParser {

	@Override
	public ParsedCommandLine parse(String[] args, Function<String, GenericEntity> entityFactory, ModelAccessory modelAccessory) {
		String readEndpointOption = null;

		JinniOptions options = (JinniOptions) entityFactory.apply("options");

		Map<String, String> properties = new LinkedHashMap<>();
		String requestIdentifier = null;
		for (String arg : args) {
			int propertyValueDelimiter = -1;
			if (readEndpointOption != null) {
				setOption(options, readEndpointOption, arg);
				readEndpointOption = null;
			} else if (arg.charAt(0) == '-') {
				readEndpointOption = arg.substring(1);
			} else if ((propertyValueDelimiter = arg.indexOf('=')) != -1) {
				// property assignment
				String name = arg.substring(0, propertyValueDelimiter);
				String value = arg.substring(propertyValueDelimiter + 1);
				properties.put(name, value);
			} else {
				// request identifier
				requestIdentifier = arg;
			}

		}

		ParsedCommandLineImpl parsedCommandLine = new ParsedCommandLineImpl(entityFactory);

		if (requestIdentifier != null) {
			ServiceRequest serviceRequest = (ServiceRequest) entityFactory.apply(requestIdentifier);
			processProperties(properties, serviceRequest, serviceRequest.entityType());
			parsedCommandLine.addEntity(serviceRequest);
		}

		parsedCommandLine.addEntity(options);

		return parsedCommandLine;
	}

	private void setOption(JinniOptions options, String propertyName, String stringValue) {

		Property property = options.entityType().getProperty(propertyName);
		GenericModelType propertyType = property.getType();

		Object value = decodeValue(propertyType, stringValue);
		property.set(options, value);
	}

	private void processProperties(Map<String, String> properties, ServiceRequest request, EntityType<? extends ServiceRequest> entityType) {
		for (Entry<String, String> entry : properties.entrySet()) {
			String propertyName = entry.getKey();
			Property property = entityType.findProperty(propertyName);

			if (property == null) {
				throw new IllegalArgumentException("unsupported property " + propertyName + " on request type " + entityType.getTypeSignature());
			}

			String encodedValue = entry.getValue();
			Object value = decodeValue(property.getType(), encodedValue);
			property.set(request, value);
		}
	}

}
