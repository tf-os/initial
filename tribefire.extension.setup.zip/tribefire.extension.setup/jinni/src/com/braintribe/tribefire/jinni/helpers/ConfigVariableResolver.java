// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.tribefire.jinni.helpers;

import java.io.File;

import com.braintribe.gm.model.reason.Reason;
import com.braintribe.gm.model.reason.Reasons;
import com.braintribe.gm.model.reason.essential.InvalidArgument;
import com.braintribe.gm.model.reason.essential.NotFound;
import com.braintribe.model.generic.value.Variable;
import com.braintribe.ve.api.VirtualEnvironment;

public class ConfigVariableResolver {
	
		private static final String ENV_PREFIX = "env.";
		private Reason failure;
		private File base;
		private File file;
		private VirtualEnvironment virtualEnvironment;
		
		public ConfigVariableResolver(VirtualEnvironment virtualEnvironment, File file) {
			super();
			this.virtualEnvironment = virtualEnvironment;
			this.file = file;
			this.base = file.getParentFile();
		}

		public Reason getFailure() {
			return failure;
		}
		
		public String resolve(Variable var) {
			return resolve(var.getName());
		}

		private String resolve(String var) {
			if (var.startsWith(ENV_PREFIX)) {
				String envName = var.substring(ENV_PREFIX.length());
				
				String value = virtualEnvironment.getEnv(envName);
				
				if (value == null) {
					acquireFailure().getReasons().add(Reasons.build(NotFound.T) //
														.text("Could not resolve property " + var) //
														.toReason());
					return "${" + var + "}";
				}
				
				//return var;
				return value;
			}

			if (var.equals("config.base")) {
				return base.getAbsolutePath();
			}
			
			String value = virtualEnvironment.getProperty(var);
			
			if (value == null) {
				acquireFailure().getReasons().add(Reasons.build(NotFound.T)// 
						.text("Could not resolve property " + var) //
						.toReason()); //
				return "${" + var + "}";
			}
			
			return value; 
		}

		private Reason acquireFailure() {
			if (failure == null) {
				failure = Reasons.build(InvalidArgument.T).text("Configuration post processing failed for " + file.getAbsolutePath()).toReason();
			}
			
			return failure;
		}
	}