_This is italic._

**This is bold.**

[This is a link to google.com](https://www.google.com)

![This is an image link.](https://smilingnoface.deviantart.com/art/forest-spirit-156871956)

[Go back](../README.md) the tribefire jinni CLI.

[Go back as well](/README.md) the tribefire jinni CLI.

![This is another way to link to this image.][fairy-link]

[fairy-link]: https://smilingnoface.deviantart.com/art/forest-spirit-156871956

<a href="/README.html">readme</a>

> This is a quote!

# Heading1
## Heading2

* Unordered list element1
 * Sub element1
 * Sub element2
* Unordered list element2

1. Ordered list element1
2. Ordered list element2

---

1. This will be followed by an own paragraph

 This  paragraph starts with a space.

 But somehow this does not work out as expected.

2. This is another paragraph

 Hello another paragraph

---

This is one
line.

---

This is a hard

break.

---

This is a soft  
break. Two spaces after soft.

---
