[](b.md?INCLUDE)
