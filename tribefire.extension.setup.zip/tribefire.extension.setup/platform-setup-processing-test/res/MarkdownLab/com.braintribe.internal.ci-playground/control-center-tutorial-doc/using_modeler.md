## General
Modeler is a UI client which allows you to create models. Modeler is embedded in Control Center, but you can also use it as a standalone application.

>For more information, see [Control Center](asset://com.braintribe.internal.ci-playground:features-doc/ui)clients/control_center.md) and [Explorer](asset://com.braintribe.internal.ci-playground:features-doc/ui)clients/explorer.md).

## Using Modeler
<iframe width="560" height="315" src="https://www.youtube.com/embed/ujkO3Jlt7ys" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
