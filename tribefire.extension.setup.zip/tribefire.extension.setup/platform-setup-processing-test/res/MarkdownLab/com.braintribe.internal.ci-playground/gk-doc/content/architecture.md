# Title

column1|column2|column3
---|---|---

[link to architecture](links.md)

[include architecture](links.md?INCLUDE)
