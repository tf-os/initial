// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.jinni.api;

import com.braintribe.model.generic.annotation.meta.Description;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;
import com.braintribe.model.service.api.PlatformRequest;

@Description("Jinni alias extension. Run without a parameter to display configured aliases. "
		+ "Run with 'alias' and 'command' parameters to define a new alias. Existing alias will be overwritten.")
public interface Alias extends PlatformRequest {
	EntityType<Alias> T = EntityTypes.T(Alias.class);

	@Description("Executes the given alias. This is functionally identical to 'jinni aliasName'.")
	String getExecute();
	void setExecute(String execute);

}
