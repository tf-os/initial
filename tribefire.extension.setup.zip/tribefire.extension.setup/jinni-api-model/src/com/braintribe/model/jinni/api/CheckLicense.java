// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.jinni.api;

import com.braintribe.model.generic.annotation.Initializer;
import com.braintribe.model.generic.annotation.meta.Alias;
import com.braintribe.model.generic.annotation.meta.Description;
import com.braintribe.model.generic.annotation.meta.Mandatory;
import com.braintribe.model.generic.annotation.meta.PositionalArguments;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;
import com.braintribe.model.resource.FileResource;
import com.braintribe.model.service.api.PlatformRequest;

@Description("Check particular directory for correct licensing.")
@PositionalArguments({ "dir" })
public interface CheckLicense extends PlatformRequest {
	EntityType<CheckLicense> T = EntityTypes.T(CheckLicense.class);

	@Description("The directory from which the content should be checked")
	@Alias("d")
	@Mandatory
	FileResource getDir();
	void setDir(FileResource dir);

	@Description("Only checking. No modifications.")
	@Alias("c")
	@Initializer("true")
	Boolean getOnlyChecking();
	void setOnlyChecking(Boolean onlyChecking);

	@Description("Update year. If onlyChecking is false, the year MUST be provided, too. ")
	@Alias("y")
	String getYear();
	void setYear(String year);

	@Description("Fix Windows-style CRLF. ")
	@Alias("w")
	@Initializer("false")
	Boolean getFixCRLF();
	void setFixCRLF(Boolean fixCRLF);

	@Description("Cleanup JavaDoc Authors")
	@Alias("j")
	@Initializer("false")
	Boolean getJDocCleanup();
	void setJDocCleanup(Boolean jdocCleanup);
}
