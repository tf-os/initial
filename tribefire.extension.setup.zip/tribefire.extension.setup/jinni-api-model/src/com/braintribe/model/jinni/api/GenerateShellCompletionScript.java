// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.jinni.api;

import com.braintribe.model.generic.annotation.Initializer;
import com.braintribe.model.generic.annotation.meta.Description;
import com.braintribe.model.generic.annotation.meta.Mandatory;
import com.braintribe.model.generic.annotation.meta.PositionalArguments;
import com.braintribe.model.generic.eval.EvalContext;
import com.braintribe.model.generic.eval.Evaluator;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;
import com.braintribe.model.resource.FileResource;
import com.braintribe.model.service.api.PlatformRequest;
import com.braintribe.model.service.api.ServiceRequest;
import com.braintribe.model.service.api.result.Neutral;

@PositionalArguments({ "file" })
@Description("Generates completion script for Shell that you need to \"source\" to use it.")
public interface GenerateShellCompletionScript extends PlatformRequest {

	EntityType<GenerateShellCompletionScript> T = EntityTypes.T(GenerateShellCompletionScript.class);

	@Description("The file to which the script should be written")
	@Mandatory
	FileResource getFile();
	void setFile(FileResource file);

	@Description("Specifies which of the argument's real name and aliases should be included as suggestions for completion.")
	@Initializer("realName")
	CliCompletionStrategy getArgumentNameCompletionStrategy();
	void setArgumentNameCompletionStrategy(CliCompletionStrategy argumentNameCompletionStrategy);

	@Override
	EvalContext<Neutral> eval(Evaluator<ServiceRequest> evaluator);

}
