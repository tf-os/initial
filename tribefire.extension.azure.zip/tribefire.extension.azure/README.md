# tribefire.extension.azure

Please refer to the [Documentation](azure-doc/src/azure.md) in `azure-doc`