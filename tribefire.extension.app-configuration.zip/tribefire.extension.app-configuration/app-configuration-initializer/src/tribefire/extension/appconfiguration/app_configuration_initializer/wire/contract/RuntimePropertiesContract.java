// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.appconfiguration.app_configuration_initializer.wire.contract;

import com.braintribe.wire.api.annotation.Decrypt;
import com.braintribe.wire.api.annotation.Default;

import tribefire.cortex.initializer.support.wire.contract.PropertyLookupContract;

public interface RuntimePropertiesContract extends PropertyLookupContract {
	
	@Default("org.postgresql.Driver")
	String APP_CONFIGURATION_DB_CONNECTION_DRIVER();
	String APP_CONFIGURATION_DB_CONNECTION_URL();
	String APP_CONFIGURATION_DB_CONNECTION_USER();
	@Decrypt
	String APP_CONFIGURATION_DB_CONNECTION_PASSWORD();
	@Default("10")
	Integer APP_CONFIGURATION_DB_POOL_MAX_CONNECTIONS();
	
	@Default("access.appconfiguration")
	String APP_CONFIGURATION_ACCESS_ID();
	
	@Default("app-config-admin")
	String APP_CONFIGURATION_ADMIN_ROLE();
	
	@Default("false")
	Boolean APP_CONFIGURATION_ENABLE_AUDITING();
	
}
