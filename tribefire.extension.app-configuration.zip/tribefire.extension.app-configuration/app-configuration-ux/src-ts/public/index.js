import Contract from "./contract.js";

console.log("START!");
export let contract = new Contract();
