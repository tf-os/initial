// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.appconfiguration.processing.services;

import static com.braintribe.utils.lcd.StringTools.isBlank;
import static tribefire.extension.appconfiguration.processing.tools.QueryTools.getEntity;
import static tribefire.extension.appconfiguration.processing.tools.QueryTools.getFirstEntity;

import java.util.function.Supplier;

import com.braintribe.cfg.Configurable;
import com.braintribe.cfg.Required;
import com.braintribe.logging.Logger;
import com.braintribe.model.processing.service.api.ServiceProcessor;
import com.braintribe.model.processing.service.api.ServiceRequestContext;
import com.braintribe.model.processing.session.api.persistence.PersistenceGmSession;
import com.braintribe.model.processing.session.api.persistence.PersistenceGmSessionFactory;

import tribefire.extension.appconfiguration.model.AppConfiguration;
import tribefire.extension.appconfiguration.model.api.GetAppConfiguration;
import tribefire.extension.appconfiguration.model.api.GetAppConfigurationResponse;

public class AppConfigurationProcessor implements ServiceProcessor<GetAppConfiguration, GetAppConfigurationResponse> {

	private static final Logger logger = Logger.getLogger(AppConfigurationProcessor.class);

	private PersistenceGmSessionFactory gmSessionFactory;
	private Supplier<String> accessIdSupplier;

	@Configurable
	@Required
	public void setGmSessionFactory(PersistenceGmSessionFactory gmSessionFactory) {
		this.gmSessionFactory = gmSessionFactory;
	}

	@Configurable
	@Required
	public void setAccessIdSupplier(Supplier<String> accessIdSupplier) {
		this.accessIdSupplier = accessIdSupplier;
	}

	@Override
	public GetAppConfigurationResponse process(ServiceRequestContext requestContext, GetAppConfiguration request) {
		logger.debug("Fetching app configuration by name '" + request.getName() + "'");
		
		PersistenceGmSession configGmSession = gmSessionFactory.newSession(accessIdSupplier.get());
		
		AppConfiguration config = null;
		if (!isBlank(request.getName())) {
			config = getEntity(configGmSession, AppConfiguration.T, AppConfiguration.name, request.getName());
		}  else {
			config = getFirstEntity(configGmSession, AppConfiguration.T);
		}
		
		GetAppConfigurationResponse response = GetAppConfigurationResponse.T.create();
		response.setConfiguration(config);
		
		return response;
	}

}