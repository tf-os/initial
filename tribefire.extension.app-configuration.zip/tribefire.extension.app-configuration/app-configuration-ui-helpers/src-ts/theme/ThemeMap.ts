import { ThemeStore } from "./types";

export const DEFAULT_REPLACE_THEME_ON_ADD = false;

export const themeMap = new Map<string, ThemeStore>();
