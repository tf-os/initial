// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.logging.juli.handlers;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UncheckedIOException;
import java.util.logging.LogRecord;
import java.util.logging.StreamHandler;

/**
 * <p>
 * This is a simple extension of {@link StreamHandler} which logs to a file configured by the system property
 * <b>logging.staticfilehandler.filepath</b>
 *
 */
public class StaticFileHandler extends StreamHandler {

	public static final String SYSTEM_PROPERTY_FILEPATH = "logging.staticfilehandler.filepath";
	private OutputStream out;

	/**
	 * Creates a new <code>StaticFileHandler</code> instance. This {@link StreamHandler#setOutputStream(java.io.OutputStream) sets the OutputStream}
	 * to the {@link FileOutputStream} configured by <b>logging.staticfilehandler.filepath</b>
	 */
	public StaticFileHandler() {
		String fileName = System.getProperty(SYSTEM_PROPERTY_FILEPATH);
		try {
			out = new FileOutputStream(fileName);
			setOutputStream(out);
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	@Override
	public synchronized void publish(LogRecord record) {
		super.publish(record);
		flush();
	}

	@Override
	public synchronized void close() {
		flush();
		try {
			out.close();
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}
}
