// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.drools.pe;

import org.kie.api.runtime.StatelessKieSession;

import com.braintribe.model.process.Process;
import com.braintribe.model.processing.pmp.api.TransitionProcessor;
import com.braintribe.model.processing.pmp.api.TransitionProcessorContext;
import com.braintribe.model.processing.pmp.api.TransitionProcessorException;

public class DroolsTransitionProcessor extends AbstractDroolsProcessor implements TransitionProcessor<Process> {
	@Override
	public void process(TransitionProcessorContext<Process> context) throws TransitionProcessorException {
		StatelessKieSession session = droolsContainer.openSession();
		
		session.setGlobal("context", context);
		session.execute(context.getProcess());
	}
}
