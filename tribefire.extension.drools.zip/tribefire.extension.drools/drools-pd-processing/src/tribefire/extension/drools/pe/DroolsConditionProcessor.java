// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.drools.pe;

import org.kie.api.runtime.StatelessKieSession;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.processing.condition.api.ConditionProcessor;
import com.braintribe.model.processing.condition.api.ConditionProcessorContext;
import com.braintribe.model.processing.condition.api.ConditionProcessorException;
import com.braintribe.provider.Holder;

public class DroolsConditionProcessor extends AbstractDroolsProcessor implements ConditionProcessor<GenericEntity> {

	@Override
	public boolean matches(ConditionProcessorContext<GenericEntity> context) throws ConditionProcessorException {
		StatelessKieSession session = droolsContainer.openSession();
		
		Holder<Boolean> result = new Holder<>(false);
		
		session.setGlobal("context", context);
		session.setGlobal("condition", result);
		session.execute(context.getSubject());
		
		return result.get();
	}
}
