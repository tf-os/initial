# tribefire.cortex.testing

Some artifacts of this group have been moved to `tribefire.cortex`:

- imp
- tribefire-test-tools
- tribefire-test-deps