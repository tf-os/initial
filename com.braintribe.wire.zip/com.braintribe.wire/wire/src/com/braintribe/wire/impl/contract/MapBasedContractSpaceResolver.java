// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.wire.impl.contract;

import java.util.Map;
import java.util.function.Supplier;

import com.braintribe.wire.api.context.WireContext;
import com.braintribe.wire.api.space.ContractResolution;
import com.braintribe.wire.api.space.ContractSpaceResolver;
import com.braintribe.wire.api.space.WireSpace;

public class MapBasedContractSpaceResolver implements ContractSpaceResolver {

	private Map<Class<? extends WireSpace>, Supplier<ContractResolution>> mappings;
	private boolean lenient;
	
	public MapBasedContractSpaceResolver(Map<Class<? extends WireSpace>, Supplier<ContractResolution>> mappings, boolean lenient) {
		this.mappings = mappings;
		this.lenient = lenient;
	}

	@Override
	public ContractResolution resolveContractSpace(WireContext<?> wireContext, Class<? extends WireSpace> contractSpaceClass) {
		return resolveContractSpace(contractSpaceClass);
	}
	
	@Override
	public ContractResolution resolveContractSpace(Class<? extends WireSpace> contractSpaceClass) {
		Supplier<ContractResolution> mappedClassSupplier = mappings.get(contractSpaceClass);
		
		if (mappedClassSupplier == null) {
			if (lenient)
				return null;
			
			throw new IllegalStateException("Contract BeanSpace " +  contractSpaceClass + " is not mapped");
		}
		
		return mappedClassSupplier.get();
	}
	
}
