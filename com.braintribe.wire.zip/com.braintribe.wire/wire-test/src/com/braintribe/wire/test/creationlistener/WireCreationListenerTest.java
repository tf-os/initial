// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.wire.test.creationlistener;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.braintribe.wire.api.Wire;
import com.braintribe.wire.api.context.WireContext;
import com.braintribe.wire.test.creationlistener.wire.CreationListenerTestWireModule;
import com.braintribe.wire.test.creationlistener.wire.contract.CreationListenerTestContract;

public class WireCreationListenerTest {

	@Test
	public void testCreationListeners() {
		InstanceCollector instanceCollector = new InstanceCollector();
		
		try (WireContext<CreationListenerTestContract> context = Wire.contextBuilder(CreationListenerTestWireModule.INSTANCE).creationListener(instanceCollector).build()) {
			
			context.contract().rootInstance();
			
			Assertions.assertThat(instanceCollector.beforeBeanNames).containsExactly("rootInstance", "subInstance1", "sub1SubInstance", "subInstance2");
			Assertions.assertThat(instanceCollector.afterBeanNames).containsExactly("sub1SubInstance", "subInstance1", "subInstance2", "rootInstance");
		}
	}
}
