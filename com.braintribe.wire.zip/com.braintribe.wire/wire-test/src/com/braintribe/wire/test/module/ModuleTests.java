// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.wire.test.module;

import org.junit.Test;

import com.braintribe.testing.junit.assertions.assertj.core.api.Assertions;
import com.braintribe.wire.api.Wire;
import com.braintribe.wire.api.context.WireContext;
import com.braintribe.wire.test.module.wire.ExampleModule;
import com.braintribe.wire.test.module.wire.contract.ExampleContract;

public class ModuleTests {

	@Test
	public void testSimple() throws Exception {
		try (WireContext<ExampleContract> context = Wire.context(ExampleModule.INSTANCE)) {
			ExampleContract exampleContract = context.contract();
			Assertions.assertThat(exampleContract.text()).as("Could not get the excepted managed instance").isEqualTo("Hello World!");
			Assertions.assertThat(context.contract().text("pre")).as("Could not get the excepted managed instance").isEqualTo("pre-foobar");
		}
	}
}
