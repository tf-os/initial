// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.wire.api.reflect;

import java.lang.reflect.Type;

import com.braintribe.wire.api.annotation.Scope;
import com.braintribe.wire.api.space.WireSpace;

public interface ManagedInstanceReflection {
	Scope scope();
	String name();
	WireSpace space();
	boolean isPublic();
	boolean isParameterized();
	Type[] parameterTypes();
	Type returnType();
	<T> T instance();
	<T> T instance(Object... args);
}
