// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.wire.api.space;

import com.braintribe.wire.api.context.WireContext;

/**
 * A ContractSpaceResolver is an expert to conclude from a contract {@link WireSpace} class (being an interface)
 * to the name of the actual implementing {@link WireSpace} class that would then be loaded in a special class loader 
 * that can also do Wire's enriching of the implementing class on demand if that enriching was not done a packaging time.
 *
 */
public interface ContractSpaceResolver {
	
	default ContractResolution resolveContractSpace(WireContext<?> wireContext, Class<? extends WireSpace> contractSpaceClass) {
		return resolveContractSpace(contractSpaceClass);
	}
	
	ContractResolution resolveContractSpace(Class<? extends WireSpace> contractSpaceClass);
}
