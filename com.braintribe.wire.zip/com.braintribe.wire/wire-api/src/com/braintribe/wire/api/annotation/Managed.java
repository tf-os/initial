// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.wire.api.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.braintribe.wire.api.context.WireContext;
import com.braintribe.wire.api.scope.WireScope;
import com.braintribe.wire.api.space.WireSpace;

/**
 * The Managed annotation is to be placed on any factory method or {@link WireSpace} that should be managed by Wire.
 * A method annotated iwth will be enhanced on bytecode level by Wire in order to create the managed instance within a {@link WireScope} if
 * the {@link WireSpace} containing it is annotated as well.
 *    
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.TYPE})
@Inherited
public @interface Managed {
	/**
	 * The scope that should be used. If this is {@link Scope#inherit} the scope will be inherited via the following chain:
	 * <ol>
	 * 	<li>factory method</li>
	 *  <li>{@link WireSpace}</li>
	 *  <li>{@link WireContext}</li>
	 * </ol>
	 * The default of this will be {@link Scope#inherit}. 
	 */
	Scope value() default Scope.inherit;
}
