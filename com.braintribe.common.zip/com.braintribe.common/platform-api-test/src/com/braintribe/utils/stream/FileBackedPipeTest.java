// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.utils.stream;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UncheckedIOException;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Test;
import org.junit.rules.TemporaryFolder;

import com.braintribe.logging.Logger;
import com.braintribe.utils.FileTools;
import com.braintribe.utils.IOTools;
import com.braintribe.utils.lcd.StopWatch;

public class FileBackedPipeTest {

	private static final int NUMBER_OF_READ_THREADS = 10;

	public static final Logger log = Logger.getLogger(FileBackedPipeTest.class);

	private static ExecutorService executor;

	private static byte[] FIRST_LINE = "first line".getBytes();
	private static byte[] SECOND_LINE = "second line".getBytes();

	@ClassRule
	public static final TemporaryFolder tempFolder = new TemporaryFolder();

	@BeforeClass
	public static void init() {
		executor = Executors.newCachedThreadPool();
	}

	@AfterClass
	public static void destroy() {
		ExecutorService e = executor;
		if (e != null) {
			e.shutdownNow();
			executor = null;
		}
	}

	@Test
	public void multiThreadedTest() throws InterruptedException, ExecutionException, IOException {
		File dataDir = new File("data");

		if (dataDir.exists()) {
			FileTools.deleteDirectoryRecursively(dataDir);
		}

		FileBackedPipe pipe = new FileBackedPipe("test");

		File dataFile = new File(dataDir, "data");
		dataFile.getParentFile().mkdirs();

		try (OutputStream out = Files.newOutputStream(dataFile.toPath())) {
			MultipartTestUtils.writeRandomText(500_000, out);
		}

		List<Future<File>> futures = new ArrayList<>();

		// execute before reading threads
		for (int i = 0; i < NUMBER_OF_READ_THREADS; i++) {
			futures.add(executor.submit(() -> read(pipe)));
		}

		// execute writing thread
		executor.execute(() -> {
			try {
				try (InputStream in = Files.newInputStream(dataFile.toPath()); OutputStream out = pipe.openOutputStream()) {
					IOTools.transferBytes(in, out);
				}
			} catch (IOException e) {
				throw new UncheckedIOException(e);
			}
		});

		// execute after reading threads
		for (int i = 0; i < NUMBER_OF_READ_THREADS; i++) {
			futures.add(executor.submit(() -> read(pipe)));
		}

		for (Future<File> future : futures) {
			File file = future.get();

			assertThat(file).as("Unexpected file content").hasSameContentAs(dataFile);
		}
	}

	public void lab() throws InterruptedException, ExecutionException, IOException {
		File dataDir = new File("data");

		if (dataDir.exists()) {
			FileTools.deleteDirectoryRecursively(dataDir);
		}

		FileBackedPipe pipe = new FileBackedPipe("test");

		File dataFile = new File(dataDir, "data");
		File dataFile2 = new File(dataDir, "data2");
		dataFile.getParentFile().mkdirs();

		try (OutputStream out = Files.newOutputStream(dataFile.toPath())) {
			MultipartTestUtils.writeRandomText(100_000_000, out);
		}

		// synchronous write and read
		StopWatch w = new StopWatch();
		try (InputStream in = Files.newInputStream(dataFile.toPath()); OutputStream out = Files.newOutputStream(dataFile2.toPath())) {
			IOTools.transferBytes(in, out, () -> new byte[IOTools.SIZE_64K]);
		}
		long t1 = w.getElapsedTime();

		try (InputStream in = Files.newInputStream(dataFile2.toPath())) {
			byte buffer[] = IOTools.BUFFER_SUPPLIER_64K.get();
			while (in.read(buffer) != -1) {
				// noop
			}
		}

		long t2 = w.getElapsedTime();

		System.out.println("Time used for writing: " + t1 + "ms");
		System.out.println("Time used for full IO: " + t2 + "ms");

		// synchronous write and read
		StopWatch w2 = new StopWatch();
		Future<?> future = executor.submit(() -> {
			try (InputStream in = pipe.openInputStream()) {
				byte buffer[] = IOTools.BUFFER_SUPPLIER_64K.get();
				while (in.read(buffer) != -1) {
					// noop
				}
			} catch (IOException e) {
				throw new UncheckedIOException(e);
			}
		});

		try (InputStream in = Files.newInputStream(dataFile.toPath()); OutputStream out = pipe.openOutputStream()) {
			IOTools.transferBytes(in, out, IOTools.BUFFER_SUPPLIER_64K);
		}

		future.get();

		long t3 = w2.getElapsedTime();
		System.out.println("Time used for full pipe IO: " + t3 + "ms");

		// List<Future<File>> futures = new ArrayList<>();
		//
		// // execute before reading threads
		// for (int i = 0; i < NUMBER_OF_READ_THREADS; i++) {
		// futures.add(executor.submit(() -> read(pipe)));
		// }
		//
		// // execute writing thread
		// executor.execute(() -> {
		// try {
		// try (InputStream in = Files.newInputStream(dataFile.toPath()); OutputStream out = pipe.openOutputStream()) {
		// IOTools.transferBytes(in, out);
		// }
		// } catch (IOException e) {
		// throw new UncheckedIOException(e);
		// }
		// });
		//
		// // execute after reading threads
		// for (int i = 0; i < NUMBER_OF_READ_THREADS; i++) {
		// futures.add(executor.submit(() -> read(pipe)));
		// }
		//
		// for (Future<File> future: futures) {
		// File file = future.get();
		//
		// assertThat(file).as("Unexpected file content").hasSameContentAs(dataFile);
		// }
	}

	private File read(FileBackedPipe pipe) {
		try {
			String fileName = UUID.randomUUID().toString();
			File targetFile = new File("data/" + fileName);

			try (InputStream in = pipe.openInputStream(); OutputStream out = Files.newOutputStream(targetFile.toPath())) {
				IOTools.transferBytes(in, out);
			}

			return targetFile;
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}

	@Test
	public void singleThreadedTest() throws IOException {
		byte buffer[] = new byte[FIRST_LINE.length];
		byte buffer2[] = new byte[SECOND_LINE.length];

		FileBackedPipe pipe = new FileBackedPipe("test");

		InputStream inBefore = pipe.openInputStream();

		OutputStream out = pipe.openOutputStream();

		out.write(FIRST_LINE);

		InputStream inBetween = pipe.openInputStream();

		inBefore.read(buffer);

		assertThat(buffer).as("unexpected bytes read from inBefore").isEqualTo(FIRST_LINE);

		out.write(SECOND_LINE);

		inBefore.read(buffer2);
		assertThat(buffer2).as("unexpected bytes read from inBefore").isEqualTo(SECOND_LINE);

		out.close();

		assertThat(inBefore.read()).as("eof expected").isEqualTo(-1);

		inBetween.read(buffer);
		inBetween.read(buffer2);
		assertThat(buffer).as("unexpected bytes read from inBetween").isEqualTo(FIRST_LINE);
		assertThat(buffer2).as("unexpected bytes read from inBetween").isEqualTo(SECOND_LINE);
		assertThat(inBetween.read()).as("eof expected").isEqualTo(-1);

		InputStream inAfter = pipe.openInputStream();

		inAfter.read(buffer);
		inAfter.read(buffer2);
		assertThat(buffer).as("unexpected bytes read from inAfter").isEqualTo(FIRST_LINE);
		assertThat(buffer2).as("unexpected bytes read from inAfter").isEqualTo(SECOND_LINE);
		assertThat(inAfter.read()).as("eof expected").isEqualTo(-1);

	}

}

class MultipartTestUtils {
	private static String[] words = { "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };

	private MultipartTestUtils() {
		// Prevent from instantiating the class
	}

	static enum PartStreamingMethod {
		chunked,
		contentLengthAware,
		raw
	}

	static void writeRandomData(OutputStream out, int byteCount) throws IOException {
		byte buffer[] = IOTools.BUFFER_SUPPLIER_8K.get();

		Random r = new Random(0);

		int bufferBytesUsed = 0;
		for (int i = 0; i < byteCount; i++) {
			buffer[bufferBytesUsed++] = (byte) r.nextInt(255);

			if (bufferBytesUsed == IOTools.SIZE_8K) {
				out.write(buffer);
				bufferBytesUsed = 0;
			}
		}

		if (bufferBytesUsed > 0) {
			out.write(buffer, 0, bufferBytesUsed);
		}

	}

	static void writeRandomText(int minfileSize, OutputStream out) throws IOException {
		Random random = new Random(System.currentTimeMillis());
		int amountWritten = 0;
		int lineWordsWritten = 0;
		try (Writer writer = new OutputStreamWriter(out, StandardCharsets.UTF_8)) {
			while (amountWritten < minfileSize) {

				if (lineWordsWritten > 20) {
					writer.write('\n');
					lineWordsWritten = 0;
				} else if (lineWordsWritten > 0) {
					writer.write(' ');
				}

				String word;

				int index = random.nextInt(words.length);
				word = words[index];

				writer.write(word);
				amountWritten += word.length();
				lineWordsWritten++;
			}
		}
	}

	static void writeRandomDataFile(File generatedFile, int byteCount) {
		try (OutputStream out = new FileOutputStream(generatedFile)) {
			writeRandomData(out, byteCount);
		} catch (IOException e) {
			throw new UncheckedIOException(e);
		}
	}
}
