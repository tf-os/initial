// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.utils.lcd;

/**
 * An extended version of {@link StopWatch} that resets the instance after each call to {@link #getElapsedTime()}.
 *
 *
 */
public class AutoResettingStopWatch extends StopWatch {

	public AutoResettingStopWatch() {
		// nothing to do
	}

	/**
	 * Returns the elapsed time and resets the internal timer.
	 */
	@Override
	public long getElapsedTime() {
		final long elapsedTime = super.getElapsedTime();
		reset();
		return elapsedTime;
	}
}
