// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.common;

import java.io.File;
import java.io.FileFilter;
import java.util.function.Predicate;

/**
 * A {@link FileFilter} that filters files based on a {@link FilterBasedFileFilter#setPredicate(Predicate) delegate} {@link Predicate}.
 *
 */
public class FilterBasedFileFilter implements FileFilter {

	private Predicate<File> predicate;

	public FilterBasedFileFilter() {
		// nothing to do
	}

	public FilterBasedFileFilter(final Predicate<File> predicate) {
		this.predicate = predicate;
	}

	public Predicate<File> getPredicate() {
		return this.predicate;
	}

	public void setPredicate(final Predicate<File> predicate) {
		this.predicate = predicate;
	}

	@Override
	public boolean accept(final File file) {
		return predicate.test(file);
	}
}
