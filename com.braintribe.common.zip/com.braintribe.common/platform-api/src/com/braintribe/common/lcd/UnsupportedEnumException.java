// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.common.lcd;

/**
 * This exception signals that an enum constant couldn't be handled because it's not supported. Use this exception if you are aware that there are one
 * or more constants that your code cannot handle (yet).
 *
 * @see UnknownEnumException
 */
public class UnsupportedEnumException extends AbstractUncheckedBtException {

	private static final long serialVersionUID = -3154492481256430408L;

	public UnsupportedEnumException(String message) {
		super(message);
	}

	public UnsupportedEnumException(final Enum<?> enumConstant) {
		super("Enum constant " + enumConstant + " of enum type " + enumConstant.getClass().getName() + " is not supported!");
	}

}
