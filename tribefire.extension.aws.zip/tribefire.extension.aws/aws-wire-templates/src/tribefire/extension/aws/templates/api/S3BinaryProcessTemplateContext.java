// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.aws.templates.api;

import com.braintribe.model.aws.deployment.S3Region;
import com.braintribe.model.deployment.Cartridge;
import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.wire.api.scope.InstanceConfiguration;

public interface S3BinaryProcessTemplateContext {

	String getIdPrefix();

	String getName();

	String getAwsAccessKey();

	String getAwsSecretAccessKey();

	S3Region getRegion();

	String getBucketName();

	String getPathPrefix();

	Integer getHttpConnectionPoolSize();

	Long getConnectionAcquisitionTimeout();

	Long getConnectionTimeout();

	Long getSocketTimeout();

	String getUrlOverride();

	String getCloudFrontBaseUrl();

	String getCloudFrontPrivateKey();

	String getCloudFrontPublicKey();

	String getCloudFrontKeyGroupId();

	Cartridge getAwsCartridge();

	com.braintribe.model.deployment.Module getAwsModule();

	<T extends GenericEntity> T lookup(String globalId);

	<T extends GenericEntity> T create(EntityType<T> entityType, InstanceConfiguration instanceConfiguration);

	static S3BinaryProcessTemplateContextBuilder builder() {
		return new S3BinaryProcessTemplateContextImpl();
	}

}