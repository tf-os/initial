# tribefire demo svelte app.

Simple login and profile page

Implemented router, store, tfjs autentification ...
