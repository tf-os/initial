<script type="ts">
  import RouteView from '../../hoc/RouteView.svelte'
  import LoginView from './LoginView.svelte'

  // export let params = {};
</script>

<RouteView>
  <LoginView />
</RouteView>
