<script type="ts">
  import RouteView from '../../hoc/RouteView.svelte'
  import ProfileView from './ProfileView.svelte'
</script>

<RouteView showMenu>
  <ProfileView />
</RouteView>
