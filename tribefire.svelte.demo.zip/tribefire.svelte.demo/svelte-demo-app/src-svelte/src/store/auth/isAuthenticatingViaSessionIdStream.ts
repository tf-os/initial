import { SvelteSubject } from "../../types/SvelteSubject";

export let isAuthenticatingViaSessionIdStream = new SvelteSubject(false);
