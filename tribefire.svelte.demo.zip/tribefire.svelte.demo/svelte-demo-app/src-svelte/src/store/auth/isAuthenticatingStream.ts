import { SvelteSubject } from "../../types/SvelteSubject";

export let isAuthenticatingStream = new SvelteSubject(false)
