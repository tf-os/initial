import { SvelteSubject } from '../types/SvelteSubject'

export const isMainMenuRoute$ = new SvelteSubject(false)
export const isMainLangMenuRoute$ = new SvelteSubject(false)
