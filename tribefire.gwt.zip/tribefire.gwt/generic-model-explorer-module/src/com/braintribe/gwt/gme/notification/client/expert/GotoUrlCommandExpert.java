// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.gwt.gme.notification.client.expert;

import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Supplier;

import com.braintribe.gwt.gme.constellation.client.ExplorerConstellation;
import com.braintribe.gwt.gme.constellation.client.MasterDetailConstellation;
import com.braintribe.gwt.ioc.client.Configurable;
import com.braintribe.gwt.ioc.client.Required;
import com.braintribe.model.generic.path.ModelPath;
import com.braintribe.model.generic.path.RootPathElement;
import com.braintribe.model.processing.notification.api.CommandExpert;
import com.braintribe.model.uicommand.GotoUrl;
import com.google.gwt.regexp.shared.RegExp;
import com.google.gwt.user.client.Window;
import com.sencha.gxt.core.shared.FastMap;

/**
 * Command which contains an URL to be opened either in GME, or in a new browser window.
 * 
 */
public class GotoUrlCommandExpert implements CommandExpert<GotoUrl> {

	private static final String BLANK_TARGET = "_blank";
	private static final String INLINE = "inline";
	private static final String regex = "\\$[\\\\{]([^}]*)[\\\\}]";
	private RegExp regexp = RegExp.compile(regex); 

	private ExplorerConstellation explorerConstellation;
	private Supplier<MasterDetailConstellation> masterDetailConstellationProvider;
	private Map<String, String> envProps;
	private Map<String, Object> windows = new FastMap<>();

	@Required
	public void setExplorerConstellation(ExplorerConstellation explorerConstellation) {
		this.explorerConstellation = explorerConstellation;
	}

	@Required
	public void setMasterDetailConstellationProvider(Supplier<MasterDetailConstellation> masterDetailConstellationProvider) {
		this.masterDetailConstellationProvider = masterDetailConstellationProvider;
	}
	
	@Configurable
	public void setEnvironmentProperties(Map<String, String> envProps) {
		this.envProps = envProps;
	}

	@Override
	public void handleCommand(GotoUrl gotoUrl) {
		String target = gotoUrl.getTarget();
		String url = gotoUrl.getUrl();
		
		boolean matches = regexp.test(url);
		if (matches) {
			if (envProps != null && !envProps.isEmpty()) {
				for (Entry<String, String> entry : envProps.entrySet()) {
					url = url.replaceAll("\\$[\\\\{]"+entry.getKey()+"[\\\\}]", entry.getValue());
				}			
			}
			/*
			MatchResult matchResult = regexp.exec(url);
			if(matchResult.getGroupCount() > 0) {
				String message = "Couldn't find replacements for ";
				for(int i = 0; i < matchResult.getGroupCount(); i++) {
					message += matchResult.getGroup(i) + ", ";
				}
				//ErrorDialog.showMessage(message);
			}
			SplitResult splitResult = regexp.split(url);
			int length = splitResult.length();
			*/
		}		
		
		url = url == null ? "#" : url;
		
		String name = gotoUrl.getName();
		if (target == null || !target.equals(INLINE)) {
			if (target == null)
				Window.open(url, BLANK_TARGET, "");
			else
				open(url, target);
			return;
		}
		
		MasterDetailConstellation masterDetailConstellation = masterDetailConstellationProvider.get();
		masterDetailConstellation.configureGmSession(explorerConstellation.getGmSession());
		ModelPath modelPath = new ModelPath();
		modelPath.add(new RootPathElement(GotoUrl.T, gotoUrl));
		masterDetailConstellation.setContent(modelPath);
		explorerConstellation.maybeCreateVerticalTabElement(null, name, url, () -> masterDetailConstellation, null, null, false);
		if (target.equals(INLINE))
			masterDetailConstellation.collapseOrExpandDetailView(true);
	}
	
	private native void open(String url, String name)/*-{
		var k = 'openWindow-'+name;          
		var w = $wnd[k];			
		if(!w){
		    w = $wnd.open(url, name);
		    loop = setInterval(function() {   
		        if(w.closed) { 
		            $wnd[k] = null; 
		            clearInterval(loop);
		        }  
		    }, 500); 
		    $wnd[k] = w;
		}else{
		    w.location.href = url;
		}
		w.focus();     
	}-*/;
}
