// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.gwt.metadataeditor.client.listeners;

import com.braintribe.gwt.gmview.client.GmSelectionListener;
import com.braintribe.gwt.gmview.client.GmSelectionSupport;
import com.google.gwt.event.logical.shared.SelectionEvent;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.user.client.ui.Widget;
import com.sencha.gxt.widget.core.client.event.RowClickEvent;
import com.sencha.gxt.widget.core.client.event.RowClickEvent.RowClickHandler;

/**
 * Management of GmSelectionListener and its delegates.
 * 
 */
public class SelectionListeners extends AbstractListeners<GmSelectionListener> implements SelectionHandler<Widget>, RowClickHandler {

	private final GmSelectionSupport gmSelectionSupport;

	public SelectionListeners(GmSelectionSupport gmSelectionSupport) {
		super();
		this.gmSelectionSupport = gmSelectionSupport;
	}

	@Override
	protected void execute(GmSelectionListener sl) {
		sl.onSelectionChanged(this.gmSelectionSupport);
	}

	@Override
	public void onSelection(SelectionEvent<Widget> event) {
		fireListeners();
	}

	@Override
	public void onRowClick(RowClickEvent event) {
		fireListeners();
	}

}
