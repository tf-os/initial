// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.gwt.modeller.client.filter;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.annotation.SelectiveInformation;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

@SelectiveInformation("${description}")
public interface RelationshipFilterWeavingContext extends GenericEntity{

	final EntityType<RelationshipFilterWeavingContext> T = EntityTypes.T(RelationshipFilterWeavingContext.class);
	
	String getFilterType();
	void setFilterType(String filterType);
	
	Object getValue();
	void setValue(Object value);
	
	String getPropertyName();
	void setPropertyName(String propertyName);
	
	Boolean getUseNegation();
	void setUseNegation(Boolean useNegation);
	
	String getDescription();
	void setDescription(String description);
	
	/*
	public EntityType<? extends RelationshipFilter> filterType;
	public Object value;
	public String propertyName;
	public boolean useNegation;
	*/
}