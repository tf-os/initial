configuration of the extension
==============================

This extension requires some configuration. All feature require a [repository configuration](./repository/configuration.md), some of the features require a further [resolution configuration](./resolution/configuration.md).

Both configurations are not passed to the [services](../services/services.md), but referenced via their ids. There are pulled from the associated access, so you can reuse prepared configurations multiple times. 
