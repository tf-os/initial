tribefire.extension.artifact : artifact processing extension
============================================================

basically, the extension exposes some of the artifact dependency magic that is used within various parts of tribefire, inclusive and not restricted to the build system.

As the features rely on access to remote repositories (aka remote servers), some configuration is required. [about the configuration](./configuration/configuration.md)

The services themselves are described here  
[about the services](./services/services.md)
