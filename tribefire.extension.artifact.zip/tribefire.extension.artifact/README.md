# tribefire.extension.dependencies
