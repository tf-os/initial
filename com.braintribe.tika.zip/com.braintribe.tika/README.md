# com.braintribe.tika

This repository was retired on 28th July 2022 since it was migrated to tribefire.extension.tika