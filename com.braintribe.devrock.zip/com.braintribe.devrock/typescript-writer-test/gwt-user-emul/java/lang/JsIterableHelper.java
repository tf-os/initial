// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package java.lang;

import java.util.Iterator;

/**
 */
/* package */ class JsIterableHelper {

	/** Uses {@link Iterator}. */
	public static native <T> JsIterable<T> iterable(Iterable<T> itbl) /*-{
	    var result = {};
	    result[Symbol.iterator] = function () {
	        it = itbl.@Iterable::iterator()();
	        return {
	            next: function() {
	                if (it.@Iterator::hasNext()()) {
	                    return { done: false, value: it.@Iterator::next()() };
	                } else {
	                    return { done: true };
	                }
	            }
	        };
	    };
	
	    return result;
	}-*/;

}
