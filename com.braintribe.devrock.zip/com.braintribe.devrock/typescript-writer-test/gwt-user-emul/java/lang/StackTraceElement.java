// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package java.lang;

import java.JsAnnotationsPackageNames;

import java.io.Serializable;
import java.util.Objects;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsType;

/**
 * Included for hosted mode source compatibility. Partially implemented
 * 
 * @skip
 */
@JsType(namespace = JsAnnotationsPackageNames.JAVA_LANG)
@SuppressWarnings("unusable-by-js")
public final class StackTraceElement implements Serializable {

  private String className;

  private String fileName;

  private int lineNumber;

  private String methodName;

  public StackTraceElement() {
  }

  @JsIgnore
  public StackTraceElement(String className, String methodName,
      String fileName, int lineNumber) {
	this();
    assert className != null;
    assert methodName != null;
    this.className = className;
    this.methodName = methodName;
    this.fileName = fileName;
    this.lineNumber = lineNumber;
  }

  public String getClassName() {
    return className;
  }

  public String getFileName() {
    return fileName;
  }

  public int getLineNumber() {
    return lineNumber;
  }

  public String getMethodName() {
    return methodName;
  }
  
  //Emulation, which always returns false
  public boolean isNativeMethod() {
      return false;
  }

  @Override
  public boolean equals(Object other) {
    if (other instanceof StackTraceElement) {
      StackTraceElement st = (StackTraceElement) other;
      return lineNumber == st.lineNumber
          && Objects.equals(methodName, st.methodName)
          && Objects.equals(className, st.className)
          && Objects.equals(fileName, st.fileName);
    }
    return false;
  }

  @Override
  public int hashCode() {
    return Objects.hash(lineNumber, className, methodName, fileName);
  }

  @Override
  public String toString() {
    return className + "." + methodName + "("
        + (fileName != null ? fileName : "Unknown Source")
        + (lineNumber >= 0 ? ":" + lineNumber : "") + ")";
  }
}
