// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package java.util;

import static javaemul.internal.InternalPreconditions.checkNotNull;

import java.util.function.Predicate;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import java.JsAnnotationsPackageNames;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsType;
import jsinterop.utils.Collections;

/**
 * General-purpose interface for storing collections of objects.
 * See <a href="https://docs.oracle.com/javase/8/docs/api/java/util/Collection.html">
 * the official Java API doc</a> for details.
 *
 * @param <E> element type
 */
@JsType(namespace = JsAnnotationsPackageNames.JAVA_UTIL)
public interface Collection<E> extends Iterable<E> {

  boolean add(E o);

  boolean addAll(Collection<? extends E> c);

  void clear();

  boolean contains(Object o);

  boolean containsAll(Collection<?> c);

  boolean isEmpty();

  @JsIgnore
  default Stream<E> parallelStream() {
    // no parallelism in gwt
    return stream();
  }

  boolean remove(Object o);

  boolean removeAll(Collection<?> c);

  @JsIgnore
  default boolean removeIf(Predicate<? super E> filter) {
    checkNotNull(filter);
    boolean removed = false;
    for (Iterator<E> it = iterator(); it.hasNext();) {
      if (filter.test(it.next())) {
        it.remove();
        removed = true;
      }
    }
    return removed;
  }

  boolean retainAll(Collection<?> c);

  int size();

  @JsIgnore
  @Override
  default Spliterator<E> spliterator() {
    return Spliterators.spliterator(this, 0);
  }

  default Stream<E> stream() {
    return StreamSupport.stream(spliterator(), false);
  }

  Object[] toArray();

  @JsIgnore
  <T> T[] toArray(T[] a);

	// ################################################
	// ## . . . . . . . TFJS Additions . . . . . . . ##
	// ################################################

  default boolean addAllJs(E... args) {
	  return addAll(Arrays.asList(args));
  }

  default boolean containsAllJs(E... args) {
	  return containsAll(Arrays.asList(args));
  }

  default boolean removeAllJs(E... args) {
	  return removeAll(Arrays.asList(args));
  }

  default boolean retainAllJs(E... args) {
	  return retainAll(Arrays.asList(args));
  }

}
