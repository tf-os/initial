// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package java.util;

import static javaemul.internal.InternalPreconditions.checkNotNull;

import java.JsAnnotationsPackageNames;
import java.util.function.Consumer;

import jsinterop.annotations.JsType;

/**
 * See <a href="https://docs.oracle.com/javase/8/docs/api/java/util/Iterator.html">
 * the official Java API doc</a> for details.
 *
 * @param <E> element type
 */
@JsType(namespace = JsAnnotationsPackageNames.JAVA_UTIL)
@SuppressWarnings("unusable-by-js")
public interface Iterator<E> {

  boolean hasNext();

  E next();

  default void forEachRemaining(Consumer<? super E> consumer) {
    checkNotNull(consumer);
    while (hasNext()) {
      consumer.accept(next());
    }
  }

  default void remove() {
    throw new UnsupportedOperationException();
  }
}
