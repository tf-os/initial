// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package java.util;

/**
 */
/* package */ class JsUtilHelper {

	public static native <K, V> JsMap<K, V> toJsMap(Map<K, V> map) /*-{
	    var result = new Map();
	    var it = map.@Map::entrySet()().@Set::iterator()();

	    while (it.@Iterator::hasNext()()) {
	    	var e = it.@Iterator::next()();
	    	result.set(e.getKey(), e.getValue());
	    }

	    return result;
	}-*/;

	public static native <E> JsSet<E> toJsSet(Set<E> set) /*-{
	    var result = new Set();
	    var it = set.@Set::iterator()();

	    while (it.@Iterator::hasNext()())
	    	result.add(it.@Iterator::next()());
	
	    return result;
	}-*/;
}
