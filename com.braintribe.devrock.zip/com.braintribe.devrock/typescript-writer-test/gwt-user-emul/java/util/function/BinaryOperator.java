// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package java.util.function;

import java.util.Comparator;

import java.JsAnnotationsPackageNames;
import jsinterop.annotations.JsType;

import static javaemul.internal.InternalPreconditions.checkCriticalNotNull;

/**
 * See <a href="https://docs.oracle.com/javase/8/docs/api/java/util/function/BinaryOperator.html">
 * the official Java API doc</a> for details.
 *
 * @param <T> type of both operands and the result
 */
@FunctionalInterface
@JsType(namespace = JsAnnotationsPackageNames.JAVA_UTIL)
public interface BinaryOperator<T> extends BiFunction<T, T, T> {

  static <T> BinaryOperator<T> maxBy(Comparator<? super T> comparator) {
    return (t, u) -> comparator.compare(t, u) <= 0 ? u : t;
  }

  static <T> BinaryOperator<T> minBy(Comparator<? super T> comparator) {
    return (t, u) -> comparator.compare(t, u) <= 0 ? t : u;
  }
}
