// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package java.util.function;

import static javaemul.internal.InternalPreconditions.checkCriticalNotNull;

import java.JsAnnotationsPackageNames;

import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

/**
 * See <a href="https://docs.oracle.com/javase/8/docs/api/java/util/function/Function.html">
 * the official Java API doc</a> for details.
 *
 * @param <T> type of the argument
 * @param <R> type of the return value
 */
@JsType(namespace = JsAnnotationsPackageNames.JAVA_UTIL)
@SuppressWarnings("unusable-by-js")
@FunctionalInterface
public interface Function<T, R> {

  static <T> Function<T, T> identity() {
    return t -> t;
  }

  R apply(T t);

  @JsMethod(name = "andThenFunction")
  default <V> Function<T, V> andThen(Function<? super R, ? extends V> after) {
    checkCriticalNotNull(after);
    return t -> after.apply(apply(t));
  }

  default <V> Function<V, R> compose(Function<? super V, ? extends T> before) {
    checkCriticalNotNull(before);
    return t -> apply(before.apply(t));
  }
}
