// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package java.util;

import static javaemul.internal.InternalPreconditions.checkNotNull;

import java.io.Serializable;
import java.util.function.Function;
import java.util.function.ToDoubleFunction;
import java.util.function.ToIntFunction;
import java.util.function.ToLongFunction;

import jsinterop.annotations.JsIgnore;
import jsinterop.annotations.JsMethod;
import jsinterop.annotations.JsType;

import java.JsAnnotationsPackageNames;


/**
 * An interface used a basis for implementing custom ordering. <a
 * href="http://java.sun.com/j2se/1.5.0/docs/api/java/util/Comparator.html">[Sun
 * docs]</a>
 *
 * @param <T> the type to be compared.
 */
@FunctionalInterface
@JsType(namespace = JsAnnotationsPackageNames.JAVA_UTIL)
@SuppressWarnings("unusable-by-js")
public interface Comparator<T> {

  int compare(T a, T b);

  @Override
  boolean equals(Object other);

	  default Comparator<T> reversed() {
		    return null;
	  }

  default Comparator<T> thenComparing(Comparator<? super T> other) {
    checkNotNull(other);
    return (Comparator<T> & Serializable) (a, b) -> {
      int c = compare(a, b);
      return (c != 0) ? c : other.compare(a, b);
    };
  }

  @JsMethod(name="thenComparingByWith")
  default <U> Comparator<T> thenComparing(Function<? super T, ? extends U> keyExtractor,
      Comparator<? super U> keyComparator) {
    return thenComparing(comparing(keyExtractor, keyComparator));
  }

  @JsMethod(name="thenComparingBy")
  default <U extends Comparable<? super U>> Comparator<T> thenComparing(
      Function<? super T, ? extends U> keyExtractor) {
    return thenComparing(comparing(keyExtractor));
  }

  @JsIgnore
  default Comparator<T> thenComparingInt(ToIntFunction<? super T> keyExtractor) {
    return thenComparing(comparingInt(keyExtractor));
  }

  @JsIgnore
  default Comparator<T> thenComparingLong(ToLongFunction<? super T> keyExtractor) {
    return thenComparing(comparingLong(keyExtractor));
  }

  @JsIgnore
  default Comparator<T> thenComparingDouble(ToDoubleFunction<? super T> keyExtractor) {
    return thenComparing(comparingDouble(keyExtractor));
  }

  @JsMethod(name="comparingWith")
  static <T, U> Comparator<T> comparing(Function<? super T, ? extends U> keyExtractor,
      Comparator<? super U> keyComparator) {
    checkNotNull(keyExtractor);
    checkNotNull(keyComparator);
    return (Comparator<T> & Serializable) (a, b) ->
        keyComparator.compare(keyExtractor.apply(a), keyExtractor.apply(b));
  }

  static <T, U extends Comparable<? super U>> Comparator<T> comparing(
      Function<? super T, ? extends U> keyExtractor) {
    return comparing(keyExtractor, naturalOrder());
  }

  @JsIgnore
  static<T> Comparator<T> comparingDouble(ToDoubleFunction<? super T> keyExtractor) {
    checkNotNull(keyExtractor);
    return (Comparator<T> & Serializable) (a, b) ->
        Double.compare(keyExtractor.applyAsDouble(a), keyExtractor.applyAsDouble(b));
  }

  @JsIgnore
  static <T> Comparator<T> comparingInt(ToIntFunction<? super T> keyExtractor) {
    checkNotNull(keyExtractor);
    return (Comparator<T> & Serializable) (a, b) ->
        Integer.compare(keyExtractor.applyAsInt(a), keyExtractor.applyAsInt(b));
  }

  @JsIgnore
  static <T> Comparator<T> comparingLong(ToLongFunction<? super T> keyExtractor) {
    checkNotNull(keyExtractor);
    return (Comparator<T> & Serializable) (a, b) ->
        Long.compare(keyExtractor.applyAsLong(a), keyExtractor.applyAsLong(b));
  }

	  static <T extends Comparable<? super T>> Comparator<T> naturalOrder() {
		    return null;
	  }

	  static <T> Comparator<T> nullsFirst(Comparator<? super T> comparator) {
		    return null;
	  }

	  static <T> Comparator<T> nullsLast(Comparator<? super T> comparator) {
		    return null;
	  }

	  static <T extends Comparable<? super T>> Comparator<T> reverseOrder() {
	    return null;
	  }
	}
