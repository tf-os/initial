// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.provider.compound;

import java.util.Collection;

import java.util.function.Supplier;


/**
 * The {@link CompoundProvider} is an abstract implementation of a {@link Provider} that bundles multiple other
 * providers to create a {@link Collection} of results.
 * <p></p>
 * Implementations only have to implement the method {@link #newCollectionInstance()}.
 * 
 * 
 * @param <T>
 *            Generic Type specifying the {@link Collection} implementation the compound provider will return, e.g.
 *            HashSet.
 * @param <E>
 *            Generic Type specifying the type of elements contained in the resulting collection.
 */
public abstract class CompoundProvider<T extends Collection<E>, E> implements Supplier<T> {

	private Collection<Provider<E>> providers;

	/**
	 * Provides a {@link Collection} of elements provided by the {@link Provider}s configured by
	 * {@link #setProviders(Collection)}.
	 */
	@Override
	public T get() throws RuntimeException {
		T result = newCollectionInstance();
		fillResultFromProviderImpls(result);
		return result;
	}

	private void fillResultFromProviderImpls(T result) throws RuntimeException {
		for (Provider<E> provider : providers) {
			result.add(provider.provide());
		}
	}

	/**
	 * Creates a new instance of the concrete {@link Collection} type.
	 */
	protected abstract T newCollectionInstance();

	/**
	 * Configures the {@link Provider}s this class uses for generating its result of {@link #provide()}.
	 */
	public void setProviders(Collection<Provider<E>> providers) {
		this.providers = providers;
	}
}
