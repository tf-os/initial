// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.generic.base;

import com.braintribe.model.generic.GMF;
import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.reflection.CloningContext;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;
import com.braintribe.model.generic.reflection.GenericModelType;
import com.braintribe.model.generic.reflection.Property;
import com.braintribe.model.generic.reflection.PropertyAccessInterceptor;
import com.braintribe.model.generic.reflection.PropertyValueReceiver;
import com.braintribe.model.generic.reflection.TraversingContext;
import com.braintribe.model.generic.session.GmSession;
import com.braintribe.model.generic.value.EntityReference;
import com.braintribe.model.generic.value.ValueDescriptor;

/**
 * @see GenericBase
 */
public interface EntityBase extends GenericBase {

	final EntityType<GenericEntity> T = EntityTypes.T(GenericEntity.class);

	@Override
	default boolean isEntity() {
		return true;
	}

	// ###################################################
	// ## . . . generic property-access methods . . . . ##
	// ###################################################

	// @formatter:off
	void write(Property p, Object value);
	Object read(Property p);

	void writeVd(Property p, ValueDescriptor value);
	ValueDescriptor readVd(Property p);

	void read(Property p, PropertyValueReceiver pvr);
	// @formatter:on

	// ###################################################
	// ## . . . . . . other helpful methods . . . . . . ##
	// ###################################################

	/**
	 * This is here just to point out that we always override this method.
	 */
	@Override
	String toString();

	String toSelectiveInformation();

	/**
	 * Returns a string representation of this entity. The default one is the {@link #toString()}, but for some
	 * hierarchies (queries, manipulations) a tailor-made stringifiers might be in place. For details see the platform
	 * implementation.
	 */
	default String stringify() {
		return GMF.platform().stringify((GenericEntity) this, GenericEntity.T);
	}

	/* TODO change return type to EntityType<?> once we change ITW so that entityType() method is created dynamically
	 * (and not this one) */
	@Override
	GenericModelType type();

	/**
	 * Returns the {@link EntityType} corresponding to this instance. This returns the same thing as {@link #type()}
	 * method, but with more specific return-type (as overriding that method with this return type is unfortunately not
	 * possible).
	 */
	<T extends GenericEntity> EntityType<T> entityType();

	<T extends EntityReference> T reference();

	<T extends EntityReference> T globalReference();

	/**
	 * Returns if the instance is enhanced which means that it support {@link PropertyAccessInterceptor} driven
	 * cross-cutting concerns. If false it is a plain instance
	 * 
	 * @return - true if the instance is enhanced, false otherwise.
	 */
	boolean isEnhanced();

	/**
	 * Returns if the instance has a type that derives from {@link ValueDescriptor}
	 * 
	 * @return - true if the instance is of a {@link ValueDescriptor} type, false otherwise.
	 */
	boolean isVd();

	/**
	 * Returns an id which is unique for given instance for the entire runtime. This id has no correlation to the actual
	 * entity and only serves the purpose of unambiguously identifying entities and a stable ordering on them.
	 * <p>
	 * The use-case which led us to introduce this was the implementation of indices in Smood, since we wanted a
	 * "navigable"-like interface for our maps, but only had the "sorted" implementation, but with a little trick (using
	 * this id) we have found a workaround.
	 * <p>
	 * This is also be used for PreliminaryEntityReferences.
	 */
	long runtimeId();

	/**
	 * Returns the value of the id property, if it is defined for given entity, or <tt>null</tt> otherwise.
	 */
	Object persistenceId();

	/**
	 * Invokes the setter for the id property, if it is defined for given entity, or throws an
	 * {@link UnsupportedOperationException}.
	 */
	void assignPersistenceId(Object id);

	/**
	 * @return - the {@link GmSession} the Entity is attached to or null if not attached.
	 */
	GmSession session();

	/**
	 * Attaches the instance to a {@link GmSession}. Only enhanced entities can actually be attached to a session. If a
	 * session is attached the {@link PropertyAccessInterceptor} are taken from the session.
	 * 
	 * @param session
	 *            - the {@link GmSession} to attach the entity to
	 */
	void attach(GmSession session);

	/**
	 * Detaches the instance from a session if there was any. This session is then returned.
	 * 
	 * @return - the {@link GmSession} the instance was attached to or null if it was not attached.
	 */
	GmSession detach();

	/**
	 * This method allows to clone the assembly being held by the entity instance. The conditionality of the cloning can
	 * be influenced by the {@link CloningContext}. Commonly one uses or derives from StandardCloningContext to do so.
	 * 
	 * @param cloningContext
	 *            - the {@link CloningContext} to use
	 * @return - the newly cloned instance.
	 */
	<T> T clone(CloningContext cloningContext);

	/**
	 * This method allows to traverse the assembly being held by the entity instance. The conditionality of the
	 * traversion can be influenced by the {@link TraversingContext}. Commonly one uses or derives from
	 * StandardTraversingContext to do so.
	 * 
	 * @param traversingContext
	 *            - the {@link TraversingContext} to be used during traversing.
	 */
	void traverse(TraversingContext traversingContext);
}
