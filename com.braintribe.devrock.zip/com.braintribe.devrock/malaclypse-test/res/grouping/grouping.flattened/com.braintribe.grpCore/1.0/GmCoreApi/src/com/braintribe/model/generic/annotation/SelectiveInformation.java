// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.generic.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Specifies how a given entity should be displayed as text (in the client). It is similar to
 * {@link ToStringInformation}, but that one is not meant to be displayed for the user, but for example as an entity
 * print in the logs.
 * 
 * Technically, this also differs from {@link ToStringInformation} by providing an additional regular expression
 * replacement. See for example GmEntityType. Not that this is different than the SelectiveInformation meta data in that
 * it is not localized and the MD does not support the regex replacement.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Inherited
public @interface SelectiveInformation {
	public String value();
	public String regexPattern() default "";
	public String replacement() default "";
}
