// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.provider;

import java.util.Deque;
import java.util.LinkedList;

public class ThreadLocalStackedHolder<T> implements Hub<T> {

	private ThreadLocal<Deque<T>> threadLocal = new ThreadLocal<Deque<T>>();
	
	@Override
	public void receive(T object) throws ReceiverException {
		
		if (object != null) {
			
			if (threadLocal.get() == null) {
				threadLocal.set(new LinkedList<T>());
			}
			
			threadLocal.get().addFirst(object);
			
		} else if (threadLocal.get() != null) {
				
			threadLocal.get().pollFirst();
				
			if (threadLocal.get().isEmpty()) {
				threadLocal.remove();
			}
		}
		
	}

	@Override
	public T provide() throws ProviderException {
		return (threadLocal.get() != null) ? threadLocal.get().peekFirst() : null;
	}
	
}
