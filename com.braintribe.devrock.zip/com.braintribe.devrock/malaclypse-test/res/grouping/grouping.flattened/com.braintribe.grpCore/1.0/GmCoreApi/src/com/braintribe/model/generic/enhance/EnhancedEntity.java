// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.generic.enhance;

import com.braintribe.model.generic.annotation.GmSystemInterface;
import com.braintribe.model.generic.reflection.PropertyAccessInterceptor;
import com.braintribe.model.generic.session.SessionAttachable;

@SuppressWarnings("deprecation")
@GmSystemInterface
public interface EnhancedEntity extends SessionAttachable {

	/**
	 * Returns the flags of given instance.
	 * 
	 * @see EntityFlags
	 */
	int flags();

	void assignFlags(int flags);
	
	/**
	 * TODO javadoc
	 */
	void pushPai(PropertyAccessInterceptor pai);
	
	PropertyAccessInterceptor popPai();
	
	/**
	 * TODO javadoc
	 */
	void assignPai(PropertyAccessInterceptor pai);
}
