// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.generic.reflection;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.pr.AbsenceInformation;
import com.braintribe.model.generic.value.ValueDescriptor;

/**
 * 
 */
public interface Property {

	String getName();

	GenericModelType getType();

	/**
	 * Returns the {@link EntityType} which declared this property. Note that this does not mean, that the property is
	 * not inherited by the returned type, it may have just re-declared it with a different initializer.
	 */
	EntityType<?> getDeclaringType();

	/**
	 * Returns the first type in the hierarchy (when examined with depth-first search) where this property was declared.
	 * This means this property is not inherited by the returned type.
	 */
	EntityType<?> getFirstDeclaringType();

	/** This is false only for properties defined as primitive java types. */
	boolean isNullable();

	/** @return <tt>true</tt> iff this property is {@link GenericEntity#id} */
	boolean isIdentifier();

	/** returns <tt>true</tt> iff this is the {@link GenericEntity#partition} property */
	boolean isPartition();

	/** returns <tt>true</tt> iff this is the {@link GenericEntity#globalId} property */
	boolean isGlobalId();

	/**
	 * @return <tt>true</tt> iff this property is either an {@link #isIdentifier() identifier} or it's the
	 *         {@link #isPartition() partition} property (i.e. is used to uniquely identify an entity)
	 */
	boolean isIdentifying();

	Object getInitializer();

	<T> T get(GenericEntity entity);
	void set(GenericEntity entity, Object value);

	/** Accesses the property directly, bypassing any possible configured {@link PropertyAccessInterceptor}s */
	<T> T getDirectUnsafe(GenericEntity entity);
	void setDirectUnsafe(GenericEntity entity, Object value);

	/** with type-checking */
	<T> T getDirect(GenericEntity entity);
	Object setDirect(GenericEntity entity, Object value);

	/** with AOP, wrap to VdHolder, set directly without type-check */
	<T extends ValueDescriptor> T getVd(GenericEntity entity);
	void setVd(GenericEntity entity, ValueDescriptor value);

	/** no AOP, wraps to VdHolder and sets directly, without AOP or type-check */
	<T extends ValueDescriptor> T getVdDirect(GenericEntity entity);
	Object setVdDirect(GenericEntity entity, ValueDescriptor value);

	AbsenceInformation getAbsenceInformation(GenericEntity entity);
	void setAbsenceInformation(GenericEntity entity, AbsenceInformation ai);

	/**
	 * @return true iff this property is absent, i.e. if the property field references a VdHolder which is marked as an
	 *         absence information.
	 */
	boolean isAbsent(GenericEntity entity);

	/**
	 * @return the default value based on the property type, or <tt>null</tt> if the property is nullable. This means
	 *         that for a property of type Integer the result would be <tt>null</tt>, but for int it would be 0.
	 */
	Object getDefaultValue();

}
