// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.provider;

import java.util.Collections;
import java.util.Map;

public class MapIndexedProvider<I, E> implements IndexedProvider<I, E> {

  private Map<I, E> map;

  public MapIndexedProvider() {
    this.map = Collections.emptyMap();
  }

  public MapIndexedProvider(Map<I, E> map) {
    setMap(map);
  }

  public void setMap(Map<I, E> map) {
    this.map = map;
  }

  @Override
public E provide(I index) throws ProviderException {
    return map.get(index);
  }
}
