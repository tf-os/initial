// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.provider;

/**
 * Holders hold a property.
 * This property is set via the constructor, but can also be set via the {@link #setProperty(Object)} method.
 *
 * @param <E> The type
 */
@SuppressWarnings("deprecation")
public class Holder<E> extends SimpleProvider<E> implements Hub<E>{

	public Holder(E object) {
		super(object);
	}
	
	public Holder() {
		super(null);
	}
	
	public void setProperty(E object) {
		this.object = object;
	}
	
    public E getProperty() {
    	return this.object;
    }

	
	@Override
	public void receive(E object) throws ReceiverException {
		setProperty(object);
	}
}
