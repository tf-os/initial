// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.generic.reflection;

import java.util.List;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.value.EntityReference;

public interface EntityType<T extends GenericEntity> extends EntityTypeDeprecations<T>, CustomType, EnhancableCustomType {

	/**
	 * @return the java interface, which defines the getters and setters for the properties. Following holds:
	 *         <code>this.getJavaType().getName().equals(this.getTypeSignature()) </code>
	 */
	@Override
	Class<T> getJavaType();

	boolean isAbstract();

	/** returns the direct supertypes of this {@link EntityType} */
	List<EntityType<?>> getSuperTypes();

	Iterable<EntityType<?>> getTransitiveSuperTypes(boolean includeSelf, boolean distinct);

	boolean hasExplicitSelectiveInformation();

	/** @return id property of this entity type, or <tt>null</tt> if this type has no id property */
	Property getIdProperty();

	/** Returns an unmodifiable list of all the entity's properties (including those inherited from super types), sorted by name. */
	List<Property> getProperties();

	/**
	 * @return similar to {@link #findProperty(String)}, but throws a {@link GenericModelException} if no property was
	 *         found. Note that this works for all properties, also the inherited ones.
	 */
	Property getProperty(String name) throws GenericModelException;

	/**
	 * @return {@link Property} for given name, or <tt>null</tt> if no such property is defined for this entity type.
	 *         Note that this works for all properties, also the inherited ones.
	 */
	Property findProperty(String name);

	/** @return list with the portion of the properties that have types which allow to reach enums or entities */
	List<Property> getCustomTypeProperties();

	/**
	 * All properties where property.getDeclaringType == this. See {@link Property#getDeclaringType()}.
	 */
	List<Property> getDeclaredProperties();

	GenericModelType getEvaluatesTo();

	/** {@inheritDoc} */
	@Override
	boolean isAssignableFrom(GenericModelType type);

	/** Similar to GenericModelType#isAssignableFrom(GenericModelType), this is here for convenience. */
	boolean isAssignableFrom(EntityType<?> entityType);

	/**
	 * Creates reference on given entity with given id. The reason id is passed separately is that sometimes we want to
	 * create an reference with a different id, most probably when processing ChangeValueManipulations on id properties
	 * and say creating a reference for inverse manipulation based on the previous value, that is no longer set inside
	 * the entity.
	 * 
	 * TODO really think about how the {@link GenericEntity#partition} property is affected.
	 */
	EntityReference createReference(T entity, Object idValue);

	/**
	 * Creates a reference with given globalId. If the provided globalId is null, a preliminary reference is created.
	 */
	EntityReference createGlobalReference(T entity, String globalId);

	<E extends T> E initialize(E entity);

	// #########################################
	// ## . . . . . . new methods . . . . . . ##
	// #########################################

	@Override
	T createPlain();

	@Override
	T create();

	T create(String globalId);

	T create(PropertyAccessInterceptor pai);

	T createPlainRaw();

	T createRaw();

	T createRaw(PropertyAccessInterceptor pai);

	Class<? extends T> plainClass();

	// maybe for JVM only
	Class<? extends T> enhancedClass();

}
