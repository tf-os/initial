// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.provider;

/**
 * An {@link IndexedProvider} that just provides the result of a configured {@link ProviderBasedIndexedProvider#getDelegateProvider()} delegate
 * provider).
 * 
 */
public class ProviderBasedIndexedProvider<I, E> implements IndexedProvider<I, E>, Provider<E> {

	private Provider<E> delegateProvider;

	public ProviderBasedIndexedProvider() {

	}

	public ProviderBasedIndexedProvider(Provider<E> delegateProvider) {
		setDelegateProvider(delegateProvider);
	}

	public Provider<E> getDelegateProvider() {
		if (this.delegateProvider == null) {
			throw new IllegalStateException("Delegate provider not set!");
		}
		return this.delegateProvider;
	}

	public void setDelegateProvider(Provider<E> delegateProvider) {
		this.delegateProvider = delegateProvider;
	}

	/**
	 * Returns the result of {@link #getDelegateProvider()}
	 */
	@Override
	public E provide() throws ProviderException {
		return getDelegateProvider().provide();
	}

	/**
	 * Just ignores the <code>index</code> and returns the result of {@link #provide()}.
	 */
	@Override
	public E provide(I index) throws ProviderException {
		return provide();
	}

}
