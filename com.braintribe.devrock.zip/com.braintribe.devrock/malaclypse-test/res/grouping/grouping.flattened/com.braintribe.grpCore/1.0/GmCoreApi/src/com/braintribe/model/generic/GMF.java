// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.generic;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Supplier;

import com.braintribe.model.generic.pr.AbsenceInformation;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EssentialTypes;
import com.braintribe.model.generic.reflection.GenericModelException;
import com.braintribe.model.generic.reflection.GenericModelType;
import com.braintribe.model.generic.reflection.GenericModelTypeReflection;
import com.braintribe.model.generic.session.CallGmSession;


/**
 * GenericModelFramework
 * 
 * This class is initialized automatically.
 */
public class GMF implements EssentialTypes {

	private static final GenericModelTypeReflection typeReflection;
	private static final GmPlatform platform;

	private static Supplier<String> localeProvider;

	private static AbsenceInformation absenceInformation;

	static {
		platform = GmPlatformProvider.provide();
		typeReflection = platform.getTypeReflection();

		platform.initialize();
	}

	/** @return {@link GmPlatform}, which solely depends on {@link GmPlatformProvider} */
	public static GmPlatform platform() {
		return platform;
	}

	public static void setLocaleProvider(Supplier<String> localeProvider) {
		GMF.localeProvider = localeProvider;
	}

	public static Supplier<String> getLocaleProvider() {
		return localeProvider;
	}

	public static String getLocale() {
		if (localeProvider != null) {
			try {
				return localeProvider.get();
			} catch (RuntimeException e) {
				throw new GenericModelException("error while accessing locale", e);
			}
		} else
			return "default";
	}

	/**
	 * @return instance of {@link AbsenceInformation} which can be used as a standard value (in case no special information needs to be
	 *         stored, nor does this have to be attached to a session).
	 */
	public static AbsenceInformation absenceInformation() {
		if (absenceInformation == null) {
			absenceInformation = typeReflection.<AbsenceInformation> getEntityType(AbsenceInformation.class).createPlain();
		}

		return absenceInformation;
	}

	@SuppressWarnings("unchecked")
	public static <T extends GenericModelTypeReflection> T getTypeReflection() {
		return (T) typeReflection;
	}

	/**
	 * TODO will really mark deprecated later, don't want people to start doing changes cause of the warnings just yet.
	 * 
	 * (at)deprecated use ${Type}.T.create() (if T does not exist, please add it). If you actually have an instance of Class<?> (rather than
	 * a class literal) and thus cannot use the T-literal method, get hold of type reflections, get the {@link EntityType} instance and then
	 * {@link EntityType#create()}.
	 */
	// @Deprecated
	public static <T extends GenericEntity> T createEntity(Class<T> entityClass) {
		EntityType<T> entityType = typeReflection.getEntityType(entityClass);
		return entityType.create();
	}

	/** @deprecated use {@link EntityType#create()} */
	@Deprecated
	public static <T extends GenericEntity> T createEntity(EntityType<T> entityType) {
		return entityType.create();
	}

	@SuppressWarnings("unchecked")
	public static <T> List<T> createPlainList(GenericModelType elementType) {
	   	return (List<T>) typeReflection.getListType(elementType).createPlain();
	}

	@SuppressWarnings("unchecked")
	public static <T> Set<T> createPlainSet(GenericModelType elementType) {
		return (Set<T>) typeReflection.getSetType(elementType).createPlain();
	}
	
	@SuppressWarnings("unchecked")
	public static <K, V> Map<K, V> createPlainMap(GenericModelType keyType, GenericModelType valueType) {
		return (Map<K, V>) typeReflection.getMapType(keyType, valueType).createPlain();
	}

	public static CallGmSession createCallSession() {
		return platform.createCallSession();
	}

}
