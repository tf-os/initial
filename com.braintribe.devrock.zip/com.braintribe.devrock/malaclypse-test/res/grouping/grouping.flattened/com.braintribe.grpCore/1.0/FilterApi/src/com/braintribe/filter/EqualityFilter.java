// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.filter;

/**
 *
 */
public class EqualityFilter<T> implements Filter<T> {

	private T value;
	
	// **************************************************************************
	// Constructor
	// **************************************************************************

	/**
	 * Default constructor
	 */
	public EqualityFilter() {
	}

	// **************************************************************************
	// Getter/Setter
	// **************************************************************************

	/**
	 * @param value the value to set
	 */
	public void setValue(T value) {
		this.value = value;
	}
	
	/**
	 * @return the value
	 */
	public T getValue() {
		return value;
	}
	
	// **************************************************************************
	// Interface methods
	// **************************************************************************

	/**
	 * @see com.braintribe.filter.Filter#matches(java.lang.Object)
	 */
	public boolean matches(T obj) {
		if (obj == value) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		return obj.equals(value);
	}
	
	// **************************************************************************
	// Helper methods
	// **************************************************************************
}
