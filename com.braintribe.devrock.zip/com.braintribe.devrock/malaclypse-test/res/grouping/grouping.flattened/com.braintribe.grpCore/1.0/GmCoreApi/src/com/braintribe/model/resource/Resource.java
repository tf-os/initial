// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.resource;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.Set;

import com.braintribe.model.generic.StandardStringIdentifiable;
import com.braintribe.model.generic.annotation.ForwardDeclaration;
import com.braintribe.model.generic.annotation.SelectiveInformation;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;
import com.braintribe.model.generic.session.GmSession;
import com.braintribe.model.generic.session.exception.GmSessionRuntimeException;
import com.braintribe.model.resource.api.HasResourceReadAccess;
import com.braintribe.model.resource.api.ResourceReadAccess;
import com.braintribe.model.resource.source.ResourceSource;
import com.braintribe.model.resource.specification.ResourceSpecification;
import com.braintribe.model.securitypolicy.HasSecurityPolicy;

/**
 * a representation - the key to get an appropriate stream
 * 
 * mimeType: the MIME type of the actual representation md5: the md5 value of the actual representation file size: guess what - the file
 * size of the actual representation (which is NOT the size of what the enriching process delivers) tag: a classification tag to be used for
 * easy grouping
 * 
 *
 */
@ForwardDeclaration("com.braintribe.gm:resource-model")

@SelectiveInformation("${name}")
public interface Resource extends HasSecurityPolicy, StandardStringIdentifiable {

	final EntityType<Resource> T = EntityTypes.T(Resource.class);

	final String mimeType = "mimeType";
	final String md5 = "md5";
	final String fileSize = "fileSize";
	final String tags = "tags";
	final String resourceSource = "resourceSource";
	final String name = "name";
	final String created = "created";
	final String creator = "creator";
	final String specification = "specification";
	
	// @formatter:off
	String getMimeType();
	void setMimeType(String mimeType);

	String getMd5();
	void setMd5(String md5);
	Long getFileSize();
	void setFileSize(Long fileSize);

	Set<String> getTags();
	void setTags(Set<String> tags);

	ResourceSource getResourceSource();
	void setResourceSource(ResourceSource resourceSource);

	String getName();
	void setName(String name);
	Date getCreated();
	void setCreated(Date created);
	void setCreator(String creator);
	String getCreator();

	ResourceSpecification getSpecification();
	void setSpecification(ResourceSpecification specification);
	// @formatter:on

	default InputStream openStream() {
		GmSession session = session();

		if (!(session instanceof HasResourceReadAccess)) {
			throw new GmSessionRuntimeException(
					"Cannot open resource stream as entity is not attached to a session which supports streaming.");
		}

		ResourceReadAccess resources = ((HasResourceReadAccess) session).resources();

		try {
			return resources.openStream(this);
		} catch (IOException e) {
			throw new RuntimeException("Error while opening stream" + (e.getMessage() != null ? ": " + e.getMessage() : ""), e);
		}
	}

	default void writeToStream(OutputStream outputStream) {
		GmSession session = session();

		if (!(session instanceof HasResourceReadAccess)) {
			throw new GmSessionRuntimeException(
					"Cannot write to resource stream as entity is not attached to a session which supports streaming.");
		}

		ResourceReadAccess resources = ((HasResourceReadAccess) session).resources();
		try {
			resources.writeToStream(this, outputStream);
		} catch (IOException e) {
			throw new RuntimeException("Error while writing to stream" + (e.getMessage() != null ? ": " + e.getMessage() : ""), e);
		}
	}
}
