// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.generic.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Specifies the default value of a property.
 * 
 * Since this is a String value, special care has to be taken that the provided string can be
 * transformed correctly to the target type. Hence, a special encoding has to be used, based on the 
 * type of the property.
 *
 * <ul>
 *  <li>Strings have to be enclosed in single ticks (e.g., 'Hello, world!')</li>
 *  <li>Numbers other than integer need a suffix, indicating their type: 'l' for long, 'f' for float, 'd' for double, and 'b' for BigDecimal</li>
 *  <li>now() signifies the current Date, i.e. the very moment when the value is being assigned</li>
 *  <li>"null" (as a String, without the quotes) means that null should be the initial value</li>
 *  <li>enum(<fully qualified enum classname>,<constant name>) specifies an enum value (e.g. enum(my.Color,green))</li>
 *  <li>true or false for boolean values</li>
 *  <li>Anything enclosed in brackets ([, ]) is parsed as either a list or a map. (Note: this feature is not yet implemented)</li>
 *  <li>Anything in curly brackets ({, }) is parsed as a set. (Note: this feature is not yet implemented)</li>
 * </ul>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD})
public @interface Initializer {
	String value();
}
