// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.provider;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import com.braintribe.filter.Filter;

/**
 * This implementation of {@link IndexedProvider} can be used to
 * return a configured value if a associated filter matches.
 * 
 *
 * @param <I> The type of the index that is used in {@link #provide(Object)}
 * @param <E> The type of the value that is returned for a given index from {@link #provide(Object)} 
 */
public class FilterBasedIndexProvider<I, E> implements IndexedProvider<I, E> {
	private Map<Filter<I>, E> filterMap;
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public FilterBasedIndexProvider() {
		this((Map)Collections.emptyMap());
	}
	
	/**
	 * 
	 * @param filterMap {@link #setFilterMap(Map)}
	 */
	public FilterBasedIndexProvider(Map<Filter<I>, E> filterMap) {
		this.filterMap = filterMap;
	}

	/**
	 * The entries of the map configured by this function will be 
	 * examined in {@link #provide(Object)} in their given order to 
	 * test filter by filter until one is matching. 
	 * The associated value is then returned.
	 * 
	 * Use a {@link LinkedHashMap} to have a defined the order of the entries
	 * @param filterMap The filter map
	 */
	public void setFilterMap(Map<Filter<I>, E> filterMap) {
		this.filterMap = filterMap;
	}
	
	public Map<Filter<I>, E> getFilterMap() {
		return this.filterMap;
	}
	
	@Override
	public E provide(I index) throws ProviderException {
		for (Map.Entry<Filter<I>, E> entry: filterMap.entrySet()) {
			Filter<I> filter = entry.getKey();
			if (filter.matches(index)) return entry.getValue();
		}
		
		return null;
	}
}
