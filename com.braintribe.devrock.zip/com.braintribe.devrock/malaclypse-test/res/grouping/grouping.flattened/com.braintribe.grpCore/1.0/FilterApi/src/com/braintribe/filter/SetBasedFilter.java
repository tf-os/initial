// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.filter;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/**
 * The SetBasedFilter allows to define a set of positives that will
 * then be matches when given as object by a caller.
 *
 * @param <T>
 */
public class SetBasedFilter<T> implements Filter<T> {
	private Set<T> positives;
	
	public SetBasedFilter() {
		this(new HashSet<T>());
	}
	
	public SetBasedFilter(T... positives) {
		this(Arrays.asList(positives));
	}
	
	public SetBasedFilter(Collection<T> positives) {
		this(new HashSet<T>(positives));
	}
	
	public SetBasedFilter(Set<T> positives) {
		this.positives = positives;
	}
	
	public void addPositive(T positive) {
		this.positives.add(positive);
	}
	
	public boolean matches(T obj) {
		return positives.contains(obj);
	}
}
