// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.provider;

import java.util.HashMap;
import java.util.Map;

/**
 * little helper class to cache an indexed provider 
 * 
 *
 * @param <I> The type of the key for the item to be provided
 * @param <E> The type of the actual value provided
 */
public class IndexedProviderCache<I,E> implements IndexedProvider<I, E> {
	private IndexedProvider<I, E> cachedProvider;
	private Map<I,E> result = new HashMap<I,E>();
	
	public IndexedProviderCache( IndexedProvider<I, E> cachedProvider) {
		setCachedProvider(cachedProvider);
	}
	public void setCachedProvider(IndexedProvider<I, E> cachedProvider) {
		this.cachedProvider = cachedProvider;
	}
	
	@Override
	public E provide(I index) throws ProviderException {
		E value = result.get( index);
		if (value == null) {
			value = cachedProvider.provide(index);
			result.put( index, value);
		}
		return value;
	}

}
