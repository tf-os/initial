// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.securitypolicy;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.annotation.ForwardDeclaration;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

/**
 * {@link GenericEntity} subclasses that implement this interface are better supported
 * by generic security calculations
 * 
 */
@ForwardDeclaration("com.braintribe.gm:security-policy-model")
public interface HasSecurityPolicy extends GenericEntity {
	
	final EntityType<HasSecurityPolicy> T = EntityTypes.T(HasSecurityPolicy.class);
	
	public static final String securityPolicy = "securityPolicy";

	public AbstractSecurityPolicy getSecurityPolicy();
	public void setSecurityPolicy(AbstractSecurityPolicy securityPolicy);
}
