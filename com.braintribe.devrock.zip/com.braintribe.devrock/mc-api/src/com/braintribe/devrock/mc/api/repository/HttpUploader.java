// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.devrock.mc.api.repository;

import com.braintribe.devrock.model.repository.MavenHttpRepository;
import com.braintribe.model.artifact.consumable.Artifact;
import com.braintribe.model.artifact.consumable.ArtifactResolution;

public interface HttpUploader {
	ArtifactResolution upload(MavenHttpRepository repository, Artifact artifact);
	ArtifactResolution upload(UploadContext context, MavenHttpRepository repository, Iterable<? extends Artifact> artifacts);
	default ArtifactResolution upload(MavenHttpRepository repository, Iterable<? extends Artifact> artifacts) {
		return upload(UploadContext.build().done(), repository, artifacts);
	}
}
