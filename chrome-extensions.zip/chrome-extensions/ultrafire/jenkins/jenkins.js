const registeredStandardPatternPaths = [
  "cortex-codebase",
  "adx/codebase",
  "psd2/codebase",
  "kostwein/codebase",
  "roodie/codebase",
]

const defaultPropertiesClassic = {
  subPaths: {
    "prs-and-branches/job/": {
      targetPrefix: "periodic/job/",
      targetSuffix: "/job/main/",
      title: "Periodic CI",
      addMenuItem: addMenuItemClassic,
    },
    "periodic/job/": {
      targetPrefix: "prs-and-branches/job/",
      targetSuffix: "/view/change-requests/",
      title: "Pull Requests CI",
      addMenuItem: addMenuItemClassic,
    }
  }
}

const defaultPropertiesBlueOcean = {
  subPaths: {
    "%2Fprs-and-branches%2F": {
      targetPrefix: "periodic/job/",
      targetSuffix: "/job/main/",
      title: "Periodic CI",
      addMenuItem: addMenuItemBlueOcean,
    },
    "%2Fperiodic%2F": {
      targetPrefix: "prs-and-branches/job/",
      targetSuffix: "/view/change-requests/",
      title: "Pull Requests CI",
      addMenuItem: addMenuItemBlueOcean,
    }
  }
}

const registeredPaths = {
  // entries not following the standard pattern could be entered here
  // NOTE that this object is initialized by initPathRegistration() using registeredStandardPatternPaths
}

registeredStandardPatternPaths.forEach(initPathRegistration)

enhance();



function enhance() {
  const parsedPath = parsePath(window.location.pathname);

  if (!parsedPath)
    return;

  parsedPath.addMenuItem(parsedPath.title, parsedPath.urlPath);
}

function parsePath(path) {

  let basePath = null;

  for (p in registeredPaths) {
    if (path.startsWith(p)) {
      basePath = p;
      break;
    }
  }

  if (basePath === null) {
    return null;
  }

  const subPath = path.substring(basePath.length);
  let target = null;
  let prefix = null;

  const registeredSubPaths = registeredPaths[basePath].subPaths;

  for (p in registeredSubPaths) {
    if (subPath.startsWith(p)) {
      target = { ...registeredSubPaths[p] };
      prefix = p;
      break;
    }
  }

  if (target === null) {
    return null;
  }

  const repoSubPath = subPath.substring(prefix.length)
  const repo = repoSubPath.substring(0, repoSubPath.indexOf("/"))

  const targetBasePath = registeredPaths[basePath].targetBasePath || basePath;

  target.urlPath = targetBasePath + target.targetPrefix + repo + target.targetSuffix;

  return target
}

function initPathRegistration(p) {
  // "adx/codebase" -> "/job/adx/job/codebase/job/"
  const pathClassicUI = "/job/" + p.replace(/[/]/g, "/job/") + "/job/";
  const pathBlueOcean = "/blue/organizations/jenkins/" + p.replace(/[/]/g, "%2F")

  registeredPaths[pathClassicUI] = { ...defaultPropertiesClassic }
  registeredPaths[pathBlueOcean] = {
    ...defaultPropertiesBlueOcean,
    targetBasePath: pathClassicUI,
  }
}

function addMenuItemClassic(title, url) {
  const tasksMenu = document.getElementById("tasks")

  if (!tasksMenu) {
    console.log("Can't add menu entry for " + title + " because no menu was detected in DOM.")
    return;
  }

  // Menu items look like this:
  /*<div class="task ">
      <span class="task-link-wrapper ">
        <a href="/job/cortex-codebase/job/periodic/job/tribefire.cortex/../../" title="Up" class="task-link ">
          <span class="task-icon-link"><img src="/static/f00b7ab2/images/24x24/up.png" alt="" style="width: 24px; height: 24px; " class="icon-up icon-md"></span>
          <span class="task-link-text">Up</span>
        </a>
      </span>
    </div>*/

  const newTask = tasksMenu.firstChild.cloneNode(true)
  newTask.classList.add("ultrafire-injected")

  tasksMenu.appendChild(newTask);

  const link = newTask.getElementsByTagName("a")[0];
  link.href = url;
  link.title = title;

  const img = link.getElementsByTagName("img")[0];
  img.src = chrome.runtime.getURL('jenkins/jenkins-icon.jpg')

  const textSpan = link.getElementsByTagName("span")[1]
  textSpan.textContent = title;
}

function repeatUntilPossible(condition, action) {
  if (condition()) {
    action();
  } else {
    window.requestAnimationFrame(() => repeatUntilPossible(condition, action));
  }
};

function addMenuItemBlueOcean(title, url, menu) {
  if (!menu) {
    const headerNavQuery = "#outer > div > span > div > section > div.Header-topNav > div > nav"
    repeatUntilPossible(
      () => document.querySelector(headerNavQuery + " > a.pipeline"),
      () => addMenuItemBlueOcean(title, url, document.querySelector(headerNavQuery))
    )
    return;
  }

  const newItem = document.createElement("a");
  menu.appendChild(newItem);

  newItem.href = url;
  newItem.textContent = title;

  newItem.classList.add("ultrafire-injected")
}


