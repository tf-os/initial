// NOTES:
// Icons taken from: https://iconarchive.com/show/noto-emoji-travel-places-icons-by-google/42697-fire-icon.html

chrome.contextMenus.create({
	title: "About Ultrafire",
	contexts: ["browser_action", "page_action"],
	onclick: (info, tab) => chrome.tabs.create({ windowId: window.id, url: getUltrafireUrl() })
});

function getUltrafireUrl() {
	return "https://github.com/[TODO]/chrome-extensions/blob/main/ultrafire";
}

chrome.commands.onCommand.addListener(function (command) {
	notifyActiveTab(command)
});

chrome.contextMenus.create({
	title: "See doc on GitHub",
	contexts: ["page"],
	documentUrlPatterns: [ "https://documentation.tribefire.com/*" ],
	onclick: (info, tab) => notifyTab(tab.id, "go_to_github")
});

function notifyActiveTab(message) {
	// Send a message to the active tab
	chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
		var activeTab = tabs[0];
		notifyTab(activeTab.id, message);
	});
}

function notifyTab(tabId, message) {
	chrome.tabs.sendMessage(tabId, { "message": message });
}

