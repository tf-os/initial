# The Project

Ultrafire :fire: is the state of the art, multiple award winning **chrome extension** that enhances the tribefire development experience by light years and increases productivity more than a YouTube blocker.

NOTE That even though this browser extension is primarily targeted for chrome it is possible to install it in various other browsers like **Firefox** and get the majority of the features working. If you want to use it in another browser and you can't work out how please contact us for help.

## How to install?

* Clone this GIT repository to your machine, in say "${git}/chrome-extensions".

### Chrome (or other Chromium based browser like Brave).

* Navigate to extensions (either type `about:extensions` or click on the `three dots/dashes` top right, then `More Tools` and `Extensions`)
* Make sure to have `Developer Mode` enabled (top right)
* Click on the `Load unpacked` button.
* Select the `ultrafire` folder (`${git}/chrome-extensions/ultrafire`).

### Firefox

* Type `about:debugging`
* Click on `This Firefox`
* Click on the `Load Temporary Add-on...` button.
* Select the `manifest.json` file in `${git}/chrome-extensions/ultrafire`.

## Features

### GitHub search enhancements

When performing a search of the codebase on GitHub, `Ultrafire` extends the result site with links to the artifact of the corresponding match.

Example: [Search for TribefireModuleContract](https://github.com/search?q=TribefireModuleContract+org%3A[TODO]&type=Code)

### Add BT CI links to GitHub repositories (some of them)

When browsing a repository on GitHub, `Ultrafire` adds **Periodic CI** and **PR CI** links to your top menu.

Example: [tribefire.cortex repo](https://github.com/[TODO]/tribefire.cortex)

NOTE That this might not work for all the repos, as there is no standard to derive the CI URL from the repo URL, but for core artifacts it works.

### Links from Periodic CI to PR one and vice versa

When browsing the core CI (jenkins/cortex-codebase) as well as some project CIs that follow a similar pattern you will find a new menu entry in the left menu. When you are in the PR CI it will link to the periodic one, when you are in a periodic pipeline it will link to the PR one. This works also when you are in a deeper path e.g. checking out a specific build or test results.

Example: [tribefire.cortex PRs overview](https://ci.[TODO].com/job/cortex-codebase/job/prs-and-branches/job/tribefire.cortex/view/change-requests/)
Example: [tribefire.cortex periodic runs](https://ci.[TODO].com/job/cortex-codebase/job/periodic/job/tribefire.cortex/)

This feature works in the classic view as well as in Blue Ocean.

### Links from POM dependencies to their GitHub folder

When viewing a POM of an artifact on GitHub, the artifact dependencies within the same org become a link to the respective artifact.

### See doc on GitHub

Available on [https://documentation.tribefire.com](https://documentation.tribefire.com).

Go to a document like [https://documentation.tribefire.com/tribefire.cortex.documentation/tribefire-home-doc/tribefire_home_page.html](https://documentation.tribefire.com/tribefire.cortex.documentation/tribefire-home-doc/tribefire_home_page.html). Right click and chose *See doc on GitHub*. This will open the corresponding markdown file on GitHub in a new tab.

This feature is useful when you directly want to edit a markdown file, e.g. when you found a mistake or a typo.

### Move to next logical URL

When you press `CTRL+SHIFT+UP`/`CTRL+SHIFT+DOWN`, your browser opens a new URL derived from the current one by increasing/decreasing the last numerical part of the URL.

For example, if you are browsing:
```
my-url.com/data/11/main.html
````
and you press `CTRL+SHIFT+UP`, the site will change to:
```
my-url.com/data/12/main.html
```

I.e. 11 changed to 12.

This is super useful when navigating the CI, for moving between PRs, multiple runs within a PR or individual periodic builds.

You can **change these shortcuts** in the chrome extensions settings at [chrome://extensions/shortcuts](chrome://extensions/shortcuts)

---

*If you like this extension and want to support it, send your gratitude, ideas for future features and/or candy to (in alphabetical order) NOR and PGA.*
