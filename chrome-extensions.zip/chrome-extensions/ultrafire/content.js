chrome.runtime.onMessage.addListener(
	function (request, sender, sendResponse) {
		console.log("Recieved ", request)
		if (request.message === "increase") {
			increaseLastNumberInUrlPath(1)

		} else if (request.message === "decrease") {
			increaseLastNumberInUrlPath(-1)

		} else if (request.message === "go_to_github") {
			let githubUrl = getDocGithubUrl()
			if (!githubUrl)
				console.log("Github links currently only work on documentation.tribefire.com")
			else
				window.open(githubUrl)
		}
	}
);

function increaseLastNumberInUrlPath(step) {
	let url = window.location.pathname;
	let lastNumber = url.match(/[1-9]\d*(?=[^0-9]*$)/)[0] // ignores leading zeroes

	console.log("Hello from your Chrome extension!")
	console.log(url, lastNumber)

	let posOfLastNumber = url.lastIndexOf(lastNumber)

	let newUrl = url.substring(0, posOfLastNumber) + (parseInt(lastNumber) + step) + url.substring(posOfLastNumber + lastNumber.length);

	console.log(lastNumber.length, posOfLastNumber, newUrl)

	window.location.pathname = newUrl
}

function getDocGithubUrl() {
	if (window.location.host != "documentation.tribefire.com")
		return;

	let path = window.location.pathname.substring(1)
	let [repo, asset, ...splitDocPath] = path.split("/")
	let docPath = splitDocPath.join("/").replace(/\.html$/, ".md");

	return "https://github.com/[TODO]/" + repo + "/tree/main/" + asset + "/src/" + docPath;
}

