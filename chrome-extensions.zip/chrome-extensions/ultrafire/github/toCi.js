ciLink();
document.addEventListener('turbo:load', ciLink);

function ciLink() {
  const path = window.location.pathname.substring(1);

  const [organization, repo] = path.split("/")

  if (!repo)
    return;

  const baseUrl = getJenkinsBaseFolder(repo);
  if (!baseUrl)
    return;

  const navNode = document.querySelector("nav.js-repo-nav > ul");

  // :scope means we are only searching for children of navNode, cause otherwise we search the full document
  const existingLinks = navNode.querySelectorAll(":scope .jenkins-link")
  if (existingLinks.length > 0)
    return;

  const periodicUrl = getPeriodicUrl(baseUrl, repo)
  const prUrl = getPrUrl(baseUrl, repo)

  appendCiLink(navNode, periodicUrl, "Periodic CI");
  appendCiLink(navNode, prUrl, "PR CI");
}

function appendCiLink(parent, href, title) {
  const aNode = document.createElement("a");
  aNode.href = href;
  aNode.text = title
  aNode.classList.add("UnderlineNav-item", "hx_underlinenav-item", "no-wrap", "js-responsive-underlinenav-item", "ultrafire-injected", "jenkins-link");
  aNode.style.backgroundImage = "url('" + chrome.runtime.getURL('jenkins/jenkins-icon.jpg') + "')";
  aNode.setAttribute("data-tab-item", "settings-tab")

  const liNode = document.createElement("li");
  liNode.classList.add("d-flex");
  liNode.appendChild(aNode);

  parent.appendChild(liNode);
}

function getPrUrl(baseUrl, repo) {
  return baseUrl + "/job/prs-and-branches/job/" + repo + "/view/change-requests/"
}

function getPeriodicUrl(baseUrl, repo) {
  return baseUrl + "/job/periodic/job/" + repo + "/job/main"
}

function getJenkinsBaseFolder(repo) {
  if (repo.startsWith("tribefire") || repo.startsWith("com.braintribe")) {
    return "https://ci.[TODO].com/job/cortex-codebase";
  }

  return null;
}