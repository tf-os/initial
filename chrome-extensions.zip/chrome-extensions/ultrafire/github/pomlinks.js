class LinkInfo {
  constructor() {
    this.artifactId = null;
    this.groupId = null;
    this.artifactIdLine = null;
  }
}

createPomlinks()
document.addEventListener('turbo:load', createPomlinks);

function createPomlinks() {
  if (!window.location.pathname.endsWith("pom.xml"))
    return;

  // Github displays a file as a table with two columns.
  // The first column are the line numbers, the second the content (marked with css class 'js-file-line').
  let pomLines = document.querySelectorAll("td.js-file-line");



  let linkInfo = new LinkInfo();

  const linkInfos = [];

  for (line of pomLines) {
    let text = line.innerText;

    if (text.includes("<dependency>") || text.includes("<exclusion>")) {
      linkInfo = pushLinkInfo();

    } else if (text.includes("</dependency>") || text.includes("</exclusion>")) {
      createLink(linkInfo)
      linkInfo = popLinkInfo();

    } else if (text.includes("<artifactId>")) {
      linkInfo.artifactId = valueBetweenTags();
      linkInfo.artifactIdLine = line;

    } else if (text.includes("<groupId>")) {
      linkInfo.groupId = valueBetweenTags();
    }

    function valueBetweenTags() {
      return text.match(/>(.*)</)[1];
    }
  }

  function pushLinkInfo() {
    const result = new LinkInfo();
    linkInfos.push(result);
    return result;
  }

  function popLinkInfo() {
    linkInfos.pop();
    return linkInfos[linkInfos.length-1];
  }
}

function createLink(linkInfo) {
  const { artifactId, groupId, artifactIdLine } = linkInfo;

  if (!(artifactId && groupId && artifactIdLine))
    return;
  if (!isTribefireGroup())
    return;

  // Such a line is expected to look like that (starting with some whitespace):
  //                &lt;artifactId&gt;foo-bar&lt;/artifactId&gt;
  let lineHtml = artifactIdLine.innerHTML;
  let i = lineHtml.indexOf("&lt;")

  let href = "https://github.com/[TODO]/" + groupId + "/blob/main/" + artifactId;

  artifactIdLine.innerHTML = lineHtml.substring(0, i) + "<a class='ultrafire-injected' href='" + href + "'>" + lineHtml.substring(i) + "</a>"

  function isTribefireGroup() {
    return groupId.startsWith("com.braintribe.") || groupId.startsWith("tribefire.")
  }
}
