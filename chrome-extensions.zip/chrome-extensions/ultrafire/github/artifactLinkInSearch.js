enhance();
document.addEventListener('turbo:load', enhance);

function enhance() {
	if (window.location.pathname === "/search")
		/* Add artifact link for every single search result item. */
		document.querySelectorAll(".code-list-item").forEach(addArtifact);
}

function addArtifact(listItem) {
	if (listItem.querySelector(".ultrafire-injected")) {
		console.log("FOUND INJECTED")
		return;
	}
	/*
	Rather than parsing the structure of a result-list item we simply observe it has the following structure:
		<link to org repo>
		<link to matching file>
		<preview of the matching file>
	So we simply take the second link within the item, assuming it's the link to the matching file, parse the artifact information out of it,
	create a link to the artifact and insert it as this link's sibling.
	*/
	const fileLink = listItem.getElementsByTagName("a")[1];
	const { title, href } = fileLink;

	const indexOfSlash = title.indexOf("/");
	if (indexOfSlash == -1)
		return;

	const artifact = title.substring(0, indexOfSlash);

	const rootUrlLength = href.length - title.length;
	const rootUrl = href.substring(0, rootUrlLength + artifact.length);

	fileLink.insertAdjacentHTML("afterend", " <br/> <a href='" + rootUrl + "' class='ultrafire-injected'><b>[<i>" + artifact + "</i>]</b></a>");
}