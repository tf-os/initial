const serverless = require("serverless-http");

const express = require("express");
const serveStatic = require("serve-static");
// const path = require("path");
const history = require("connect-history-api-fallback");
const { makeMiddleware } = require("./chrome-lambda.js");

app = express();

app.use(
  makeMiddleware({
    debug: true,
    timeout: 50000,
    useCache: true,
  })
);

const staticFileMiddleware = serveStatic("app"); // serveStatic(path.join(__dirname, "dist"));

app.use(history());
app.use(staticFileMiddleware);

module.exports.handler = serverless(app);
