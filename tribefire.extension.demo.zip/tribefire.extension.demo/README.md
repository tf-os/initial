# tribefire.extension.demo# Demo Cartridge


*Demo cartridge* serves the purpose of showcasing certain features of Tribefire by allowing them to be tested directly via Tribefire instance.  
It is also meant to introduce developers on how to code those features and organize their cartridge code in recommended way.

To get to know more about what cartridges are, click on the following [link](tribefire-demo-doc/src/cartridge.md).

<!-- TODO: Replace this with docs about functionalities  -->
You can read more about demo cartridge and it's features [here](https://documentation.tribefire.com/#!/2.0/docs/demo_cartridge.html).
