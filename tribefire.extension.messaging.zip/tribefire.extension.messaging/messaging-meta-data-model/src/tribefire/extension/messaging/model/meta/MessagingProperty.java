// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.messaging.model.meta;

import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;
import com.braintribe.model.meta.data.PropertyMetaData;

/**
 * Marks properties containing identification, contains 'GETer' request entityType to extract objects for comparison
 * using Experts using identification provided by metadata and loaded object type to query. Either getterType or
 * objectType should be present to be able to load the object state.
 */
public interface MessagingProperty extends PropertyMetaData {
	EntityType<MessagingProperty> T = EntityTypes.T(MessagingProperty.class);

	String getterEntityType = "getterEntityType";
	String loadedObjectType = "loadedObjectType";

	String getGetterEntityType();
	void setGetterEntityType(String getterEntityType);

	String getLoadedObjectType();
	void setLoadedObjectType(String loadedObjectType);
}
