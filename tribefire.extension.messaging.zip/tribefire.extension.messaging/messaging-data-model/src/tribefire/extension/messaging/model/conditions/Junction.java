// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.messaging.model.conditions;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.annotation.Abstract;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

import java.util.List;
import java.util.stream.Stream;

@Abstract
public interface Junction extends Condition {

	EntityType<Junction> T = EntityTypes.T(Junction.class);

	JunctionType junctionType();
	<C extends Condition> List<C> operands();

	@Override
	default boolean matches(GenericEntity entity) {
		List<Condition> operands = operands();
		Stream<Condition> operandsSteam = operands.stream();

		JunctionType junctionType = junctionType();
		return switch (junctionType) {
			case disjunction -> operandsSteam.anyMatch(o -> o.matches(entity));
			case conjunction -> operandsSteam.allMatch(o -> o.matches(entity));
			default -> throw new IllegalArgumentException("Unsupported JunctionType: "+junctionType);
		};
	}

}
