// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.messaging.etcd;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

public interface EtcdMessageEnvelope extends GenericEntity {

	final EntityType<EtcdMessageEnvelope> T = EntityTypes.T(EtcdMessageEnvelope.class);

	public final static String body = "body";
	public final static String messageId = "messageId";
	public final static String addresseeNodeId = "addresseeNodeId";
	public final static String addresseeAppId = "addresseeAppId";
	public final static String expiration = "expiration";

	String getBody();
	void setBody(String body);

	String getMessageId();
	void setMessageId(String messageId);
	
	String getAddresseeNodeId();
	void setAddresseeNodeId(String addresseeNodeId);
	
	String getAddresseeAppId();
	void setAddresseeAppId(String addresseeAppId);
	
	Long getExpiration();
	void setExpiration(Long expiration);
	
	
}
