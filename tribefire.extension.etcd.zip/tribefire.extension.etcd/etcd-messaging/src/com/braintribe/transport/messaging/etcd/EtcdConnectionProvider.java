// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.transport.messaging.etcd;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

import com.braintribe.logging.Logger;
import com.braintribe.transport.messaging.api.MessagingConnectionProvider;
import com.braintribe.transport.messaging.api.MessagingContext;
import com.braintribe.transport.messaging.api.MessagingException;
import com.braintribe.utils.StringTools;

/**
 * <p>
 * {@link MessagingConnectionProvider} implementation for providing {@link EtcdConnection}(s).
 * 
 * @see MessagingConnectionProvider
 * @see EtcdConnection
 */
public class EtcdConnectionProvider implements MessagingConnectionProvider<EtcdConnection> {

	private static final Logger logger = Logger.getLogger(EtcdConnectionProvider.class);

	private com.braintribe.model.messaging.etcd.EtcdMessaging providerConfiguration;
	private MessagingContext messagingContext;

	private Set<EtcdConnection> connections = new HashSet<>();
	private ReentrantLock connectionsLock = new ReentrantLock();

	public EtcdConnectionProvider() {
	}

	public void setConnectionConfiguration(com.braintribe.model.messaging.etcd.EtcdMessaging providerConfiguration) {
		this.providerConfiguration = providerConfiguration;
	}

	public MessagingContext getMessagingContext() {
		return messagingContext;
	}

	public void setMessagingContext(MessagingContext messagingContext) {
		this.messagingContext = messagingContext;
	}

	@Override
	public EtcdConnection provideMessagingConnection() throws MessagingException {

		EtcdConnection connection = new EtcdConnection(providerConfiguration);
		connection.setMessagingContext(messagingContext);

		connectionsLock.lock();
		try {
			connections.add(connection);
		} finally {
			connectionsLock.unlock();
		}

		return connection;

	}

	@Override
	public synchronized void close() {
		connectionsLock.lock();
		try {
			for (EtcdConnection con : connections) {
				try {
					con.close();
				} catch (Exception e) {
					logger.error("Could not close connection: " + con, e);
				}
			}
		} finally {
			connectionsLock.unlock();
		}
	}

	@Override
	public String toString() {
		return description();
	}

	@Override
	public String description() {
		if (providerConfiguration == null) {
			return "etcd Messaging (non-configured)";
		} else {
			List<String> endpointUrls = providerConfiguration.getEndpointUrls();
			return "etcd Messaging (" + StringTools.join(", ", endpointUrls) + ")";
		}
	}
}
