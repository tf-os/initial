# Facilities for CRON-job type scheduling

Mainly based on the quartz library.



Note:
Still depended at least from:

tribefire.cortex:
- worker-module-api and
- tribefire-platform-commons-api

tribefire.cortex.services: tribefire-web-platform



