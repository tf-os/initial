// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.jobscheduling.job_scheduling_initializer;

import com.braintribe.model.meta.GmMetaModel;
import com.braintribe.model.processing.session.api.collaboration.PersistenceInitializationContext;
import com.braintribe.wire.api.module.WireTerminalModule;

import tribefire.cortex.initializer.support.api.WiredInitializerContext;
import tribefire.cortex.initializer.support.impl.AbstractInitializer;
import tribefire.extension.jobscheduling.job_scheduling_initializer.wire.JobSchedulingInitializerWireModule;
import tribefire.extension.jobscheduling.job_scheduling_initializer.wire.contract.JobSchedulingInitializerContract;

public class JobSchedulingInitializer extends AbstractInitializer<JobSchedulingInitializerContract> {

	@Override
	public WireTerminalModule<JobSchedulingInitializerContract> getInitializerWireModule() {
		return JobSchedulingInitializerWireModule.INSTANCE;
	}

	@Override
	public void initialize(PersistenceInitializationContext context, WiredInitializerContext<JobSchedulingInitializerContract> initializerContext,
			JobSchedulingInitializerContract initializerMainContract) {

		GmMetaModel configuredPlatformApiModel = initializerMainContract.configuredPlatformApiModel();
		GmMetaModel jobApiModel = initializerMainContract.jobApiModel();

		configuredPlatformApiModel.getDependencies().add(jobApiModel);
	}
}
