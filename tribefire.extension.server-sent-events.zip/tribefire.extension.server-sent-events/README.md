# tribefire.extension.server-sent-events

This module will provide an endpoint to offer server-sent events to clients.

You can find the documentation in the `sse-doc` asset. 