// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.sse.processing.util;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import com.braintribe.common.lcd.Numbers;
import com.braintribe.model.service.api.PushRequest;

import tribefire.extension.sse.api.model.event.Statistics;

// IDEAS:
// - Top clientIds or clientId patterns
// - Ratio of seen/unseen events

public class StatisticsCollector {

	private AtomicLong totalPushCount = new AtomicLong(0);

	private AtomicInteger currentClientCount = new AtomicInteger(0);
	private AtomicLong totalPingsSentToClients = new AtomicLong();
	private AtomicLong totalEventsSentToClients = new AtomicLong();

	private AtomicLong totalBytesTransferred = new AtomicLong();
	private AtomicLong totalEventBytesTransferred = new AtomicLong();

	private long start = System.currentTimeMillis();

	public void registerPushRequest(@SuppressWarnings("unused") PushRequest request) {
		totalPushCount.incrementAndGet();
	}

	public void registerPollConnection(@SuppressWarnings("unused") String connectionId, @SuppressWarnings("unused") String clientId,
			@SuppressWarnings("unused") String lastSeenId, @SuppressWarnings("unused") String clientIp, @SuppressWarnings("unused") String username) {
		currentClientCount.incrementAndGet();

	}

	public void unregisterPollConnection(@SuppressWarnings("unused") String connectionId) {
		currentClientCount.decrementAndGet();
	}

	public void registerServletPing(@SuppressWarnings("unused") String connectionId, int messageSizeInBytes) {
		totalPingsSentToClients.incrementAndGet();
		totalBytesTransferred.addAndGet(messageSizeInBytes);
	}

	public void registerServletEvents(@SuppressWarnings("unused") String connectionId, int numberOfEvents, int messageSizeInBytes) {
		totalEventsSentToClients.addAndGet(numberOfEvents);
		totalBytesTransferred.addAndGet(messageSizeInBytes);
		totalEventBytesTransferred.addAndGet(messageSizeInBytes);
	}

	public Statistics getStatistics() {
		Statistics result = Statistics.T.create();

		result.setTotalPushRequestsProcessed(totalPushCount.get());

		int count = currentClientCount.get();
		if (count < 0) {
			count = 0;
			currentClientCount.set(0);
		}
		result.setConnectedClients(count);

		result.setNumberOfPingsSent(totalPingsSentToClients.get());

		long sizeInBytes = totalBytesTransferred.get();
		result.setTotalBytesTransferred(sizeInBytes);

		result.setEventBytesTransferred(totalEventBytesTransferred.get());

		long durationInSeconds = (System.currentTimeMillis() - start) / Numbers.MILLISECONDS_PER_SECOND;
		if (durationInSeconds > 0) {
			double bytesPerSecond = ((double) sizeInBytes) / ((double) durationInSeconds);
			result.setAverageThroughputKbPerSecond(bytesPerSecond / Numbers.KILOBYTE);
		} else {
			result.setAverageThroughputKbPerSecond(0d);
		}

		long totalEventsSent = totalEventsSentToClients.get();
		long eventsSizeInBytes = totalEventBytesTransferred.get();
		if (totalEventsSent > 0) {
			double averageSize = ((double) eventsSizeInBytes) / ((double) totalEventsSent);
			result.setAverageEventsMessageSize(averageSize);
		} else {
			result.setAverageEventsMessageSize(0d);
		}

		result.setNumberOfEventsSent(totalEventsSent);

		return result;
	}
}
