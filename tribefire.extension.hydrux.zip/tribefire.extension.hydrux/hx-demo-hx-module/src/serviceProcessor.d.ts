import * as hx from "../tribefire.extension.hydrux.hydrux-api-2.1~/hydrux-api.js";
export declare function bindServiceProcessor(context: hx.IHxModuleBindingContext): void;
