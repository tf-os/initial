import * as hx from "../tribefire.extension.hydrux.hydrux-api-2.1~/hydrux-api.js";
export declare function bindPushNotifications(context: hx.IHxModuleBindingContext): void;
