import * as hx from "../tribefire.extension.hydrux.hydrux-api-2.1~/hydrux-api.js";

export const contract: hx.IHxModuleContract = {
    bind(context: hx.IHxModuleBindingContext): void {

        const componentBinder = context.componentBinder();

    }
}
