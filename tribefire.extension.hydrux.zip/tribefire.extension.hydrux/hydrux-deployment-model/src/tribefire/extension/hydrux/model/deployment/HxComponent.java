// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.hydrux.model.deployment;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.annotation.Abstract;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

import tribefire.extension.js.model.deployment.UxModule;

/**
 * Base type for JS UX elements. It is returned by the defined UX module contract (resolvable via {@link UxModule#getPath()}) . Each UX element is
 * modeled in order to support type safety and expressive coding.
 *
 * @see HxApplication
 * @see HxView
 * @see HxController
 */
@Abstract
public interface HxComponent extends GenericEntity {

	EntityType<HxComponent> T = EntityTypes.T(HxComponent.class);

	/**
	 * The module is referenced via its global id
	 */
	UxModule getModule();
	void setModule(UxModule module);

	/**
	 * The scope for this component. This is typically <tt>null</tt>, which simply means the scope is inherited from the scope of the caller.
	 * <p>
	 * For details about scopes see {@link HxScope}.
	 */
	HxScope getScope();
	void setScope(HxScope scope);

}
