# JS Libraries File Structure

Let's have a look again at the file structure from our [example](./js-lib-intro.md#assembling-the-dependencies)