# Hydrux - The name

`Hydrux` is one of the few remaining unused cool words that end with `UX`.

The base of the word is in honor of `Hydra`, a fine lady from `Lerna`, `Greece`, known for her slightly unconventional looks and exceptional regeneration capabilities.

This beautiful name was chosen for similarity between the infamous `Hydra` and the intended architecture of a Hydrux-based application with a single platform and multiple modules.

Some people conspire the name implies endorsement of psychedelics consumption. This, however, are unfounded rumors, and all attempts at finding any evidence went up in smoke.

**Hail Hydrux!**

[Back to Hydrux Introduction](./hx-intro.md)