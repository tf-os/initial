# tribefire.extension.distributedsmoodaccess
SmooodAccess that synchronizes with other instances in a distributed environment over SQL DB
