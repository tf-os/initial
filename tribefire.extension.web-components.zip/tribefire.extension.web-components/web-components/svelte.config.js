const sveltePreprocess = require('svelte-preprocess');

export const preprocessOptions = {
  customElement: true,
  sourcemap: true,
};
