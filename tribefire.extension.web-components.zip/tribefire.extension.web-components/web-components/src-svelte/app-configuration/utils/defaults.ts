export let DEFAULT_INDENTATION = '  ';
export let DEFAULT_ENTRY_VALUE = '';