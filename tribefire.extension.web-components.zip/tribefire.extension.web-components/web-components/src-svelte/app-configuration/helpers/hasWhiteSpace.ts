export function hasWhiteSpace(s: string): boolean {
  return /\s/g.test(s);
}
