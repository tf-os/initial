export const AppLocalization = $T.tribefire.extension.appconfiguration.model.AppLocalization;
export const AppLocalizationEntry = $T.tribefire.extension.appconfiguration.model.AppLocalizationEntry;

export const AppTheme = $T.tribefire.extension.appconfiguration.model.AppTheme;
export const AppThemeEntry = $T.tribefire.extension.appconfiguration.model.AppThemeEntry;

export const AppDescriptor = $T.tribefire.extension.appconfiguration.model.AppDescriptor;
export const AppDescriptorEntry = $T.tribefire.extension.appconfiguration.model.AppDescriptorEntry;
