let autoId = 0;

export const generateNextUniqueId = () => ++autoId;