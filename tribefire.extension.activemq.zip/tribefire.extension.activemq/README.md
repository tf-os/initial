# tribefire.extension.activemq

This cartridge has a documentation asset.