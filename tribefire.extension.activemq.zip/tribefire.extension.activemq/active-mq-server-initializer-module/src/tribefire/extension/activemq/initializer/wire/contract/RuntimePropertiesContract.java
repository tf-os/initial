// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.activemq.initializer.wire.contract;

import com.braintribe.wire.api.annotation.Default;

import tribefire.cortex.initializer.support.wire.contract.PropertyLookupContract;

public interface RuntimePropertiesContract extends PropertyLookupContract {
	
	@Default("false")
	boolean AMQ_DEPLOYMENT_START();
	
	@Default("0.0.0.0")
	String AMQ_SERVER_BINDADDRESS();

	@Default("61616")
	int AMQ_SERVER_PORT();

	@Default("activemq-data")
	String AMQ_SERVER_DATA_DIRECTORY();

	String AMQ_SERVER_BROKER_NAME();

	@Default("true")
	boolean AMQ_SERVER_USE_JMX();

	@Default("activemq-db")
	String AMQ_SERVER_PERSISTENCE_DB_DIRECTORY();
	
	@Default("70")
	Integer AMQ_SERVER_HEAP_USAGE_IN_PERCENT();
	
	Long AMQ_SERVER_DISK_USAGE_LIMIT();
	
	Long AMQ_SERVER_TEMP_USAGE_LIMIT();
	
	Boolean AMQ_SERVER_CREATE_VM_CONNECTOR();
	
	@Default("false")
	boolean AMQ_SERVER_PERSISTENT();
	
	String AMQ_CLUSTER_NODES();
	
	String AMQ_DISCOVERY_MULTICAST_URI();
	String AMQ_DISCOVERY_MULTICAST_GROUP();
	String AMQ_DISCOVERY_MULTICAST_NETWORK_INTERFACE();
	String AMQ_DISCOVERY_MULTICAST_ADDRESS();
	String AMQ_DISCOVERY_MULTICAST_INTERFACE();
	
}
