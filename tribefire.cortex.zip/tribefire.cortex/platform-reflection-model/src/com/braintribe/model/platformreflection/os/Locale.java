// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.platformreflection.os;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

public interface Locale extends GenericEntity {

	EntityType<Locale> T = EntityTypes.T(Locale.class);

	String getName();
	void setName(String name);

	String getDisplayName();
	void setDisplayName(String displayName);

	String getCountry();
	void setCountry(String country);

	String getDisplayCountry();
	void setDisplayCountry(String displayCountry);

	String getLanguage();
	void setLanguage(String language);

	String getDisplayLanguage();
	void setDisplayLanguage(String displayLanguage);

}
