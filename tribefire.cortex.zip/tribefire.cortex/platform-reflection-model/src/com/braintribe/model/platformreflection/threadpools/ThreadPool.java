// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.platformreflection.threadpools;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

public interface ThreadPool extends GenericEntity {

	EntityType<ThreadPool> T = EntityTypes.T(ThreadPool.class);

	String getName();
	void setName(String name);

	Integer getActiveThreads();
	void setActiveThreads(Integer activeThreads);

	Long getTotalExecutions();
	void setTotalExecutions(Long totalExecutions);

	Long getAverageRunningTimeMs();
	void setAverageRunningTimeMs(Long averageRunningTimeMs);

	Integer getCorePoolSize();
	void setCorePoolSize(Integer corePoolSize);

	Integer getMaxPoolSize();
	void setMaxPoolSize(Integer maxPoolSize);

	Integer getPoolSize();
	void setPoolSize(Integer poolSize);

	Integer getPendingTasksInQueue();
	void setPendingTasksInQueue(Integer pendingTasksInQueue);

	Double getAveragePendingTimeInMs();
	void setAveragePendingTimeInMs(Double averagePendingTimeInMs);

	Long getTimeSinceLastExecutionMs();
	void setTimeSinceLastExecutionMs(Long timeSinceLastExecutionMs);

	Long getMaximumEnqueuedTimeInMs();
	void setMaximumEnqueuedTimeInMs(Long maximumEnqueuedTimeInMs);

	Long getMinimumEnqueuedTimeInMs();
	void setMinimumEnqueuedTimeInMs(Long minimumEnqueuedTimeInMs);

}
