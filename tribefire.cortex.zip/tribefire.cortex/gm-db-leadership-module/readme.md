# gm-db-leadership-module

## bindHardwired()

### Denotation Transformers

#### Morphers:

Source Type | Target Type
-|-
IncrementalAccess | DbLeadershipManager

#### Edr2CC Enrichers 

Following two enrichers are **only relevant for the platform leadership**, recognized by "`tribefire-leadership-db`" bindId.

`DbLeadershipAccessEdr2ccEnricher`: For leadership related `IncrementalAccess` this configures its `name`, `globalid`, `externalId` and configuration `model`, with no extra configuration, just a dependency to the standard `leadership-model`.

`DbLeadershipManagerEdr2ccEnricher`: For leadership related `DbLeadershipManager` this configures its `name`, `globalid` and `externalId`.

## bindDeployables()

Denotation Type | Deployable Component
-|-
`DbLeadershipManager` | `LeadershipManager`

