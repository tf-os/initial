// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.cortex.gm_db_leadership.wire.space;

import com.braintribe.common.artifact.ArtifactReflection;
import com.braintribe.gm.model.reason.Maybe;
import com.braintribe.model.accessdeployment.IncrementalAccess;
import com.braintribe.model.generic.reflection.Model;
import com.braintribe.model.leadership.Candidate;
import com.braintribe.model.lockingdeployment.LockManager;
import com.braintribe.model.meta.GmMetaModel;
import com.braintribe.model.processing.deployment.api.ExpertContext;
import com.braintribe.model.processing.deployment.api.binding.DenotationBindingBuilder;
import com.braintribe.wire.api.annotation.Import;
import com.braintribe.wire.api.annotation.Managed;

import tribefire.cortex._GmDbLeadershipModule_;
import tribefire.cortex.model.leadershipdeployment.db.DbLeadershipManager;
import tribefire.module.api.DenotationEnricher;
import tribefire.module.api.DenotationEnrichmentResult;
import tribefire.module.api.DenotationTransformationContext;
import tribefire.module.api.PlatformBindIds;
import tribefire.module.wire.contract.ClusterBindersContract;
import tribefire.module.wire.contract.TribefireModuleContract;
import tribefire.module.wire.contract.TribefireWebPlatformContract;

/**
 * @see #bindHardwired()
 * @see #bindDeployables(DenotationBindingBuilder)
 */
@Managed
public class GmDbLeadershipModuleSpace implements TribefireModuleContract {

	@Import
	private TribefireWebPlatformContract tfPlatform;

	@Import
	private ClusterBindersContract clusterBinders;

	private static final String EDR_2_CC_LEADERSHIP_ACCESS_NAME = "Db Leadership Access";
	private static final String EDR_2_CC_LEADERSHIP_ACCESS_ID = "edr2cc:access:db-leadership";

	private static final String EDR_2_CC_LEADERSHIP__NAME = "Db Leadership";
	private static final String EDR_2_CC_LEADERSHIP_ID = "edr2cc:leadership:gm-db";

	// ###############################################
	// ## . . . . . Hardwired deployables . . . . . ##
	// ###############################################

	@Override
	public void bindHardwired() {
		tfPlatform.hardwiredExperts().denotationTransformationRegistry() //
				.registerStandardMorpher(IncrementalAccess.T, DbLeadershipManager.T, this::accessToLeadershipManager);

		tfPlatform.hardwiredExperts().denotationTransformationRegistry() //
				.registerEnricher("DbLeadershipAccessEdr2ccEnricher", IncrementalAccess.T, this::enrichLeadershipAccess);

		tfPlatform.hardwiredExperts().denotationTransformationRegistry() //
				.registerEnricher("DbLeadershipManagerEdr2ccEnricher", DbLeadershipManager.T, this::enrichDbLeadershipManager);
	}

	private Maybe<DbLeadershipManager> accessToLeadershipManager(DenotationTransformationContext context, IncrementalAccess access) {
		DbLeadershipManager result = context.create(DbLeadershipManager.T);
		result.setAccess(access);

		return Maybe.complete(result);
	}

	/**
	 * Binds a {@link DenotationEnricher} for an {@link IncrementalAccess} related to the platform leadership (recognized by the bindId:
	 * {@value PlatformBindIds#TRIBEFIRE_LEADERSHIP_DB_BIND_ID}.
	 * <p>
	 * The enricher assumes the instance is completely empty and sets its:
	 * <ul>
	 * <li>name to {@value #EDR_2_CC_LEADERSHIP_ACCESS_NAME}
	 * <li>globalId to {@value #EDR_2_CC_LEADERSHIP_ACCESS_ID}
	 * <li>externalId to {@value #EDR_2_CC_LEADERSHIP_ACCESS_ID}
	 * <li>configuration model
	 * </ul>
	 */
	private DenotationEnrichmentResult<IncrementalAccess> enrichLeadershipAccess(DenotationTransformationContext context, IncrementalAccess access) {
		if (!isLeadershipBindId(context.denotationId()))
			return DenotationEnrichmentResult.nothingNowOrEver();

		StringBuilder sb = new StringBuilder();

		if (access.getName() == null) {
			access.setName(EDR_2_CC_LEADERSHIP_ACCESS_NAME);
			sb.append(" name to [" + EDR_2_CC_LEADERSHIP_ACCESS_NAME + "]");
		}

		if (access.getExternalId() == null) {
			access.setExternalId(EDR_2_CC_LEADERSHIP_ACCESS_ID);
			sb.append(" externalId to [" + EDR_2_CC_LEADERSHIP_ACCESS_ID + "]");
		}

		if (access.getGlobalId() == null) {
			access.setGlobalId(access.getExternalId());
			sb.append(" globalId to [" + access.getExternalId() + "]");
		}

		if (access.getMetaModel() == null) {
			access.setMetaModel(rawConfiguredModel(context));
			sb.append(" config model based on [" + leadershipModel().name() + "].");
		}

		if (sb.length() == 0)
			return DenotationEnrichmentResult.nothingNowOrEver();
		else
			return DenotationEnrichmentResult.allDone(access, "Configured " + sb.toString());
	}

	private GmMetaModel rawConfiguredModel(DenotationTransformationContext context) {
		ArtifactReflection currentArtifact = _GmDbLeadershipModule_.reflection;

		String name = currentArtifact.groupId() + ":configuration-leadership-model";
		String globalId = Model.modelGlobalId(name);

		GmMetaModel configuredModel = context.create(GmMetaModel.T);
		configuredModel.setGlobalId(globalId);
		configuredModel.setName(name);
		configuredModel.setVersion(currentArtifact.version());
		configuredModel.getDependencies().add(leadershipGmModel(context));
		return configuredModel;
	}

	private GmMetaModel leadershipGmModel(DenotationTransformationContext context) {
		return context.getEntityByGlobalId(leadershipModel().globalId());
	}

	private Model leadershipModel() {
		return Candidate.T.getModel();
	}

	private DenotationEnrichmentResult<DbLeadershipManager> enrichDbLeadershipManager( //
			DenotationTransformationContext context, DbLeadershipManager leadership) {

		if (!isLeadershipBindId(context.denotationId()))
			return DenotationEnrichmentResult.nothingNowOrEver();

		StringBuilder sb = new StringBuilder();

		if (leadership.getName() == null) {
			leadership.setName(EDR_2_CC_LEADERSHIP__NAME);
			sb.append(" name to [" + EDR_2_CC_LEADERSHIP__NAME + "]");
		}

		if (leadership.getExternalId() == null) {
			leadership.setExternalId(EDR_2_CC_LEADERSHIP_ID);
			sb.append(" externalId to [" + EDR_2_CC_LEADERSHIP_ID + "]");
		}

		if (leadership.getGlobalId() == null) {
			leadership.setGlobalId(leadership.getExternalId());
			sb.append(" globalId to [" + leadership.getExternalId() + "]");
		}

		if (sb.length() == 0)
			return DenotationEnrichmentResult.nothingNowOrEver();
		else
			return DenotationEnrichmentResult.allDone(leadership, "Configured " + sb.toString());
	}

	private boolean isLeadershipBindId(String denotationId) {
		return PlatformBindIds.TRIBEFIRE_LEADERSHIP_DB_BIND_ID.equals(denotationId)
				|| PlatformBindIds.TRIBEFIRE_LEADERSHIP_MANAGER_BIND_ID.equals(denotationId);
	}

	// ###############################################
	// ## . . . . . . . Deployables . . . . . . . . ##
	// ###############################################

	/**
	 * Binds a deployment expert for {@link DbLeadershipManager}.
	 */
	@Override
	public void bindDeployables(DenotationBindingBuilder bindings) {
		bindings.bind(DbLeadershipManager.T) //
				.component(clusterBinders.leadershipManager()) //
				.expertFactory(ctx -> deployLeadershipManager(ctx));
	}

	private com.braintribe.model.processing.leadership.DbLeadershipManager deployLeadershipManager(ExpertContext<DbLeadershipManager> ctx) {
		DbLeadershipManager deployable = ctx.getDeployable();

		com.braintribe.model.processing.leadership.DbLeadershipManager bean = new com.braintribe.model.processing.leadership.DbLeadershipManager();
		bean.setStorage(ctx.resolve(deployable.getAccess(), IncrementalAccess.T));
		bean.setLockManager(resolveLockManager(ctx, deployable));

		bean.setLocalInstanceId(tfPlatform.platformReflection().instanceId());
		bean.setRequestEvaluator(tfPlatform.requestUserRelated().evaluator());

		bean.setUserSessionScoping(tfPlatform.masterUserAuthContext().userSessionScoping());

		bean.setSessionIdSupplier(tfPlatform.systemUserRelated().userSessionIdSupplier());
		// Original in the platform
		// bean.setSessionIdSupplier(authContext.internalUser().userSessionIdProvider());

		return bean;
	}

	private com.braintribe.model.processing.lock.api.LockManager resolveLockManager(ExpertContext<DbLeadershipManager> ctx,
			DbLeadershipManager deployable) {

		LockManager lockManagerDeployable = deployable.getLockManager();
		if (lockManagerDeployable != null)
			return ctx.resolve(lockManagerDeployable, LockManager.T);
		else
			return tfPlatform.locking().manager();
	}

}
