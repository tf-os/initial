// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.processing.deployment.api;


/**
 * 
 */
public class DeploymentTraceEvent {

	public static final String UNDEPLOY_NOT_ALLOWED = "undeploy.not.allowed";
	
	public static String preDeploy(Object actionState) {
		return "deployment.action." + actionState;
	}
	
	public static String deploySuccessful(Object actionState) {
		return "deployment.successful." + actionState;
	}
	
	public static String deployFailed(Object actionState) {
		return "deployment.failure." + actionState;
	}
	
}
