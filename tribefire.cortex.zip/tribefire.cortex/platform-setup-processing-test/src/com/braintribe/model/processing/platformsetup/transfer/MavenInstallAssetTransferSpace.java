// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.processing.platformsetup.transfer;

import java.io.File;

import com.braintribe.model.platformsetup.api.request.TransferAsset;
import com.braintribe.model.processing.accessrequest.api.AccessRequestContext;
import com.braintribe.model.processing.platformsetup.AbstractAssetTransfer;
import com.braintribe.model.processing.platformsetup.MavenInstallAssetTransfer;
import com.braintribe.testing.tools.TestTools;
import com.braintribe.wire.api.annotation.Managed;
import com.braintribe.wire.api.annotation.Scope;
import com.braintribe.wire.api.space.WireSpace;

@Managed
public class MavenInstallAssetTransferSpace implements WireSpace {

	@Managed(Scope.prototype)
	public AbstractAssetTransfer mavenInstallAssetTransfer(AccessRequestContext<? extends TransferAsset> context, File baseFolder) {
		
		File localRepo = TestTools.newTempDirBuilder().relativePath("_BT", "TEST", "MavenInstall").buildFile();
		
		MavenInstallAssetTransfer bean = new MavenInstallAssetTransfer(context, baseFolder, localRepo, true);
		
		return bean;
	}
	
}
