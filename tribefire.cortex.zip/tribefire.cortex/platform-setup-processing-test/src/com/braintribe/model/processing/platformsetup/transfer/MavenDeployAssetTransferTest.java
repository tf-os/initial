// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.processing.platformsetup.transfer;

import java.io.File;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.braintribe.model.platformsetup.api.request.TransferAsset;
import com.braintribe.model.processing.accessrequest.api.AccessRequestContext;
import com.braintribe.model.processing.platformsetup.MavenDeployAssetTransfer;
import com.braintribe.testing.tools.TestTools;

//@Category(TribefireServices.class)
@Ignore // TODO
public class MavenDeployAssetTransferTest {
	private static File baseFolder;
	
	private static AccessRequestContext<? extends TransferAsset> context;
	
	@BeforeClass
	public static void setup() {
		
		baseFolder = TestTools.newTempDirBuilder().relativePath("_BT", "TEST", "baseFolder").buildFile();
		
		context = buildContext();
		
	}
	
	@Test
	public void test() {
		
		MavenDeployAssetTransfer bean = new MavenDeployAssetTransfer(context, baseFolder, true);
//		bean.setDebug(true);
		bean.transfer();
		
	}
	
	private static AccessRequestContext<? extends TransferAsset> buildContext() {
		
		InstallAssetRequestContext context = new InstallAssetRequestContext();
		return context;
		
	}
	
	
}
