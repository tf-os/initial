// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.process.model.data.tracing;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;


public interface ExceptionTrace extends GenericEntity {

	EntityType<ExceptionTrace> T = EntityTypes.T(ExceptionTrace.class);

	String exception = "exception";
	String message = "message";
	String stackTrace = "stackTrace";
	
	String getException();
	void setException(String exception);

	String getMessage();
	void setMessage(String message);

	String getStackTrace();
	void setStackTrace(String stackTrace);

}
