// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.qa.tribefire.test;

import java.util.List;

import com.braintribe.model.generic.StandardIdentifiable;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;
import com.braintribe.model.resource.Resource;

public abstract interface Child extends StandardIdentifiable {

	EntityType<Child> T = EntityTypes.T(Child.class);
	public static final String name = "name";
	public static final String tasks = "tasks";
	public static final String logo = "logo";

	public abstract String getName();

	public abstract void setName(String paramString);

	public abstract List<Task> getTasks();

	public abstract void setTasks(List<Task> paramList);

	public abstract Resource getLogo();

	public abstract void setLogo(Resource paramResource);
}
