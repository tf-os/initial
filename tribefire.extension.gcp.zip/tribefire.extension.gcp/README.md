# tribefire.extension.gcp

Version 2.8: Updated to Google Cloud Storage version 2.6.1