// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.processing.validation;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.generic.annotation.Initializer;
import com.braintribe.model.generic.annotation.meta.Description;
import com.braintribe.model.generic.annotation.meta.Mandatory;
import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;

@Description("The validation message for the end-user.")
public interface ValidationMessage extends GenericEntity {

	EntityType<ValidationMessage> T = EntityTypes.T(ValidationMessage.class);

	@Description("The corresponding model element.")
	@Mandatory
	GenericEntity getElement();
	void setElement(GenericEntity element);

	@Description("The message.")
	@Mandatory
	String getMessage();
	void setMessage(String message);

	@Description("The message level (i.e. INFO, WARNING, ERROR...).")
	@Initializer("enum(com.braintribe.model.processing.validation.ValidationMessageLevel,INFO)")
	ValidationMessageLevel getLevel();
	void setLevel(ValidationMessageLevel level);
}
