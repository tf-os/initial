// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.processing.webrpc.client.test;

import java.net.URL;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.http.HttpServlet;

import org.junit.AfterClass;
import org.junit.BeforeClass;

import com.braintribe.model.processing.rpc.test.RpcTestBase;
import com.braintribe.model.processing.rpc.test.wire.contract.RpcTestContract;
import com.braintribe.model.processing.rpc.test.wire.contract.WebRpcTestContract;
import com.braintribe.model.processing.webrpc.client.test.commons.ServerControl;
import com.braintribe.wire.api.context.WireContext;

/**
 * {@link RpcTestBase} for WEB RPC tests.
 * 
 */
public abstract class WebRpcTestBase extends RpcTestBase {

	protected static WireContext<WebRpcTestContract> context;

	protected static URL rpcUrl;

	// ============================= //
	// ======== LIFE CYCLE ========= //
	// ============================= //

	@BeforeClass
	public static void initialize() throws Exception {

		context = WebRpcTestContract.context();

		HttpServlet servlet = context.contract().server();
		List<Filter> filters = context.contract().filters();

		rpcUrl = ServerControl.startServer(servlet, filters, "/test-app", "/rpc");

	}

	@AfterClass
	public static void destroy() throws Exception {
	
		if (context != null) {
			context.shutdown();
			System.out.println("SHUTDOWN "+context);
		}

		ServerControl.shutdownServer();

	}

	// ============================= //
	// =========== BEANS =========== //
	// ============================= //

	@Override
	public RpcTestContract rpcTestBeans() {
		return context.contract();
	}

}
