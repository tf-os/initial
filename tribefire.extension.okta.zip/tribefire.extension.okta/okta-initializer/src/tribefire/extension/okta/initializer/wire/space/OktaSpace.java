// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.okta.initializer.wire.space;

import java.util.Set;

import com.braintribe.logging.Logger;
import com.braintribe.model.deployment.http.client.GmHttpClient;
import com.braintribe.model.deployment.http.client.HttpClient;
import com.braintribe.model.deployment.http.meta.HttpConsumes;
import com.braintribe.model.deployment.http.meta.HttpDefaultFailureResponseType;
import com.braintribe.model.deployment.http.meta.HttpPath;
import com.braintribe.model.deployment.http.meta.HttpProcessWith;
import com.braintribe.model.deployment.http.meta.methods.HttpGet;
import com.braintribe.model.deployment.http.meta.methods.HttpPost;
import com.braintribe.model.deployment.http.meta.params.HttpHeaderParam;
import com.braintribe.model.deployment.http.meta.params.HttpQueryParam;
import com.braintribe.model.deployment.http.processor.DynamicHttpServiceProcessor;
import com.braintribe.model.extensiondeployment.meta.PreProcessWith;
import com.braintribe.model.extensiondeployment.meta.ProcessWith;
import com.braintribe.model.generic.typecondition.origin.IsDeclaredIn;
import com.braintribe.model.meta.data.MetaData;
import com.braintribe.model.meta.data.constraint.Unmodifiable;
import com.braintribe.model.meta.selector.DeclaredPropertySelector;
import com.braintribe.model.meta.selector.EntityTypeSelector;
import com.braintribe.utils.lcd.StringTools;
import com.braintribe.wire.api.annotation.Import;
import com.braintribe.wire.api.annotation.Managed;
import com.braintribe.wire.api.context.WireContext;

import tribefire.cortex.initializer.support.wire.space.AbstractInitializerSpace;
import tribefire.extension.okta.deployment.model.OktaAccess;
import tribefire.extension.okta.deployment.model.OktaAuthorizationPreProcessor;
import tribefire.extension.okta.deployment.model.OktaConfiguredTokenAuthenticationSupplier;
import tribefire.extension.okta.deployment.model.OktaOauthTokenAuthenticationSupplier;
import tribefire.extension.okta.initializer.wire.contract.ExistingInstancesContract;
import tribefire.extension.okta.initializer.wire.contract.OktaContract;
import tribefire.extension.okta.initializer.wire.contract.RuntimePropertiesContract;
import tribefire.extension.okta.model.OktaError;
import tribrefire.extension.okta.common.OktaCommons;

@Managed
public class OktaSpace extends AbstractInitializerSpace implements OktaContract, OktaCommons {

	private static final Logger logger = Logger.getLogger(OktaSpace.class);

	@Import
	WireContext<?> wireContext;

	@Import
	RuntimePropertiesContract runtime;

	@Import
	ExistingInstancesContract existing;

	// ***************************************************************************************************
	// Contract
	// ***************************************************************************************************

	@Managed
	@Override
	public MetaData[] oktaRequestProcessingMds() {
		MetaData[] bean = new MetaData[] { processWithOktaHttpProcessor(), httpProcessWithOktaClient() };
		return bean;
	}

	@Managed
	@Override
	public HttpGet httpGet() {
		HttpGet bean = create(HttpGet.T);
		return bean;
	}

	@Managed
	@Override
	public HttpPost httpPost() {
		HttpPost bean = create(HttpPost.T);
		return bean;
	}

	@Managed
	@Override
	public HttpPath httpPathForListUsers() {
		HttpPath bean = create(HttpPath.T);
		bean.setPath(OKTA_HTTP_PATH_USERS);
		return bean;
	}

	@Managed
	@Override
	public HttpPath httpPathForGetUser() {
		HttpPath bean = create(HttpPath.T);
		bean.setPath(OKTA_HTTP_PATH_USER);
		return bean;
	}

	@Managed
	@Override
	public HttpPath httpPathForGetUserGroups() {
		HttpPath bean = create(HttpPath.T);
		bean.setPath(OKTA_HTTP_PATH_USER_GROUPS);
		return bean;
	}

	@Managed
	@Override
	public HttpPath httpPathForListGroups() {
		HttpPath bean = create(HttpPath.T);
		bean.setPath(OKTA_HTTP_PATH_GROUPS);
		return bean;
	}

	@Managed
	@Override
	public HttpPath httpPathForListGroupMembers() {
		HttpPath bean = create(HttpPath.T);
		bean.setPath(OKTA_HTTP_PATH_LIST_GROUP_MEMBERS);
		return bean;
	}

	@Managed
	@Override
	public HttpPath httpPathForGetGroup() {
		HttpPath bean = create(HttpPath.T);
		bean.setPath(OKTA_HTTP_PATH_GROUP);
		return bean;
	}

	@Managed
	@Override
	public HttpPath httpPathForListAppUsers() {
		HttpPath bean = create(HttpPath.T);
		bean.setPath(OKTA_HTTP_PATH_LIST_APP_USERS);
		return bean;
	}

	@Managed
	@Override
	public HttpPath httpPathForListAppGroups() {
		HttpPath bean = create(HttpPath.T);
		bean.setPath(OKTA_HTTP_PATH_LIST_APP_GROUPS);
		return bean;
	}

	@Managed
	@Override
	public HttpPath httpPathForGetOauthAccessToken() {
		HttpPath bean = create(HttpPath.T);
		bean.setPath(OKTA_HTTP_PATH_GET_OAUTH_ACCESS_TOKEN);
		return bean;
	}

	@Managed
	@Override
	public HttpQueryParam httpQueryParamAsIsIfDeclared() {
		HttpQueryParam bean = create(HttpQueryParam.T);
		bean.setSelector(declaredPropertySelector());
		bean.setConflictPriority(0d);
		return bean;
	}

	@Managed
	@Override
	public HttpQueryParam httpQueryParamForQuery() {
		HttpQueryParam bean = create(HttpQueryParam.T);
		bean.setParamName("q");
		bean.setConflictPriority(1d);
		return bean;
	}

	@Managed
	@Override
	public HttpQueryParam httpQueryParamForGrantType() {
		HttpQueryParam bean = create(HttpQueryParam.T);
		bean.setParamName("grant_type");
		bean.setConflictPriority(1d);
		return bean;
	}

	@Managed
	@Override
	public HttpQueryParam httpQueryParamForScope() {
		HttpQueryParam bean = create(HttpQueryParam.T);
		bean.setParamName("scope");
		bean.setConflictPriority(1d);
		return bean;
	}

	@Managed
	@Override
	public HttpQueryParam httpQueryParamForClientAssertionType() {
		HttpQueryParam bean = create(HttpQueryParam.T);
		bean.setParamName("client_assertion_type");
		bean.setConflictPriority(1d);
		return bean;
	}

	@Managed
	@Override
	public HttpQueryParam httpQueryParamForClientAssertion() {
		HttpQueryParam bean = create(HttpQueryParam.T);
		bean.setParamName("client_assertion");
		bean.setConflictPriority(1d);
		return bean;
	}

	@Managed
	@Override
	public HttpConsumes httpConsumesXWwwFormUrlEncoded() {
		HttpConsumes bean = create(HttpConsumes.T);
		bean.setMimeType("application/x-www-form-urlencoded");
		bean.setConflictPriority(1d);
		return bean;
	}

	@Managed
	@Override
	public HttpHeaderParam httpHeaderParamForAuthorization() {
		HttpHeaderParam bean = create(HttpHeaderParam.T);
		bean.setParamName(OKTA_HTTP_PARAM_AUTHORIZATION);
		return bean;
	}

	@Managed
	@Override
	public HttpDefaultFailureResponseType httpDefaultFailureResponseType() {
		HttpDefaultFailureResponseType bean = create(HttpDefaultFailureResponseType.T);
		bean.setResponseType(lookup("type:" + OktaError.T.getTypeSignature()));
		return bean;
	}

	@Managed
	@Override
	public Unmodifiable unmodifiableIfDeclaredInOktaModel() {
		Unmodifiable bean = create(Unmodifiable.T);
		bean.setSelector(decalredInOktaModelSelector());
		return bean;
	}

	@Managed
	@Override
	public OktaAccess oktaAccess() {
		OktaAccess bean = create(OktaAccess.T);
		bean.setExternalId(DEFAULT_OKTA_ACCESS_EXTERNALID);
		bean.setName(DEFAULT_OKTA_ACCESS_NAME);
		bean.setMetaModel(existing.oktaModel());
		bean.setServiceModel(existing.oktaApiModel());
		return bean;
	}

	// ***************************************************************************************************
	// Helper
	// ***************************************************************************************************

	private DeclaredPropertySelector declaredPropertySelector() {
		DeclaredPropertySelector bean = create(DeclaredPropertySelector.T);
		return bean;
	}
	@Managed
	private EntityTypeSelector decalredInOktaModelSelector() {
		EntityTypeSelector bean = create(EntityTypeSelector.T);
		bean.setTypeCondition(isDecalredInOktaModelCondition());
		return bean;
	}

	@Managed
	private IsDeclaredIn isDecalredInOktaModelCondition() {
		IsDeclaredIn bean = create(IsDeclaredIn.T);
		bean.setModelName(OKTA_DATA_MODEL_NAME);
		return bean;
	}

	@Managed
	private ProcessWith processWithOktaHttpProcessor() {
		ProcessWith bean = create(ProcessWith.T);
		bean.setProcessor(dynamicHttpProcessor());
		return bean;
	}

	@Managed
	private HttpProcessWith httpProcessWithOktaClient() {
		HttpProcessWith bean = create(HttpProcessWith.T);
		bean.setClient(oktaHttpClient());
		return bean;
	}

	@Managed
	private DynamicHttpServiceProcessor dynamicHttpProcessor() {
		DynamicHttpServiceProcessor bean = create(DynamicHttpServiceProcessor.T);
		bean.setName(OKTA_HTTP_PROCESSOR_NAME);
		bean.setExternalId(OKTA_HTTP_PROCESSOR_EXTERNALID);
		return bean;
	}

	@Managed
	private HttpClient oktaHttpClient() {
		GmHttpClient bean = create(GmHttpClient.T);
		bean.setName(OKTA_HTTP_CONNECTOR_NAME);
		bean.setExternalId(OKTA_HTTP_CONNECTOR_EXTERNALID);
		String oktaUrl = runtime.OKTA_SERVICE_BASE_URL();
		if (oktaUrl == null) {
			logger.warn("OKTA_SERVICE_BASE_URL is not configured which is required to get the Okta HTTP Client functional.");
		}
		bean.setBaseUrl(oktaUrl);
		return bean;
	}

	@Managed
	@Override
	public PreProcessWith preProcessWithAuthorization() {
		PreProcessWith bean = create(PreProcessWith.T);
		bean.setProcessor(authorizationPreProcessor());
		return bean;
	}

	@Managed
	private OktaAuthorizationPreProcessor authorizationPreProcessor() {
		OktaAuthorizationPreProcessor bean = create(OktaAuthorizationPreProcessor.T);
		bean.setExternalId(OKTA_AUTHORIZATION_PREPROCESSOR_EXTERNALID);
		bean.setName(OKTA_AUTHORIZATION_PREPROCESSOR_NAME);
		if (useOauthToken()) {
			bean.setAuthenticationSupplier(oauthAuthenticationSupplier());
		} else if (useConfiguredToken()) {
			bean.setAuthenticationSupplier(configuredTokenAuthenticationSupplier());
		} else {
			logger.error("Missing configuration: Neither OAuth nor SSWS token is configured.");
		}
		return bean;
	}

	private OktaOauthTokenAuthenticationSupplier oauthAuthenticationSupplier() {
		OktaOauthTokenAuthenticationSupplier bean = OktaOauthTokenAuthenticationSupplier.T.create();

		String clientId = runtime.OKTA_HTTP_OAUTH_CLIENT_ID();
		String audience = runtime.OKTA_HTTP_OAUTH_AUDIENCE();
		if (StringTools.isBlank(audience)) {
			String serviceBaseUrl = runtime.OKTA_SERVICE_BASE_URL();
			if (!StringTools.isBlank(serviceBaseUrl)) {
				audience = serviceBaseUrl.replace("/api/v1", "/oauth2/v1/token");
			}
		}
		Integer expirationInS = runtime.OKTA_HTTP_OAUTH_EXPIRATION_S();
		Set<String> scopes = runtime.OKTA_HTTP_OAUTH_SCOPES();

		bean.setKeyModulusN(runtime.OKTA_HTTP_OAUTH_KEY_MODULUS_N_ENCRYPTED());
		bean.setPrivateExponentD(runtime.OKTA_HTTP_OAUTH_PRIVATE_EXPONENT_D_ENCRYPTED());
		bean.setClientId(clientId);
		bean.setAudience(audience);
		if (expirationInS != null && expirationInS >= 0) {
			bean.setExpirationDurationInSeconds(expirationInS);
		}
		if (scopes != null && !scopes.isEmpty()) {
			bean.setScopes(scopes);
		}

		return bean;
	}

	private OktaConfiguredTokenAuthenticationSupplier configuredTokenAuthenticationSupplier() {
		OktaConfiguredTokenAuthenticationSupplier bean = OktaConfiguredTokenAuthenticationSupplier.T.create();
		bean.setAuthorizationScheme(runtime.OKTA_HTTP_AUTHORIZATION_SCHEME());
		bean.setAuthorizationToken(runtime.OKTA_HTTP_AUTHORIZATION_TOKEN());
		return bean;
	}

	private boolean useOauthToken() {
		if (!StringTools.isAllBlank(runtime.OKTA_HTTP_OAUTH_KEY_MODULUS_N_ENCRYPTED(), runtime.OKTA_HTTP_OAUTH_PRIVATE_EXPONENT_D_ENCRYPTED())) {
			return true;
		}
		return false;
	}
	private boolean useConfiguredToken() {
		if (!StringTools.isBlank(runtime.OKTA_HTTP_AUTHORIZATION_TOKEN())) {
			return true;
		}
		return false;
	}
}
