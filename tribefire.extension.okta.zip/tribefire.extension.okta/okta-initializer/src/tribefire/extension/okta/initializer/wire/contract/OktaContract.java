// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.okta.initializer.wire.contract;

import com.braintribe.model.deployment.http.meta.HttpConsumes;
import com.braintribe.model.deployment.http.meta.HttpDefaultFailureResponseType;
import com.braintribe.model.deployment.http.meta.HttpPath;
import com.braintribe.model.deployment.http.meta.methods.HttpGet;
import com.braintribe.model.deployment.http.meta.methods.HttpPost;
import com.braintribe.model.deployment.http.meta.params.HttpHeaderParam;
import com.braintribe.model.deployment.http.meta.params.HttpQueryParam;
import com.braintribe.model.extensiondeployment.meta.PreProcessWith;
import com.braintribe.model.meta.data.MetaData;
import com.braintribe.model.meta.data.constraint.Unmodifiable;
import com.braintribe.wire.api.space.WireSpace;

import tribefire.extension.okta.deployment.model.OktaAccess;

public interface OktaContract extends WireSpace {

	HttpGet httpGet();
	HttpPost httpPost();

	HttpPath httpPathForListUsers();
	HttpPath httpPathForGetUser();
	HttpPath httpPathForGetUserGroups();
	HttpPath httpPathForListGroups();
	HttpPath httpPathForListGroupMembers();
	HttpPath httpPathForGetGroup();
	HttpPath httpPathForListAppUsers();
	HttpPath httpPathForListAppGroups();

	HttpPath httpPathForGetOauthAccessToken();
	HttpQueryParam httpQueryParamForClientAssertion();
	HttpQueryParam httpQueryParamForClientAssertionType();
	HttpQueryParam httpQueryParamForScope();
	HttpQueryParam httpQueryParamForGrantType();
	HttpConsumes httpConsumesXWwwFormUrlEncoded();

	HttpQueryParam httpQueryParamAsIsIfDeclared();
	HttpHeaderParam httpHeaderParamForAuthorization();
	HttpQueryParam httpQueryParamForQuery();
	HttpDefaultFailureResponseType httpDefaultFailureResponseType();

	MetaData[] oktaRequestProcessingMds();

	Unmodifiable unmodifiableIfDeclaredInOktaModel();
	OktaAccess oktaAccess();
	PreProcessWith preProcessWithAuthorization();

}
