// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.okta.initializer;

import com.braintribe.model.generic.GenericEntity;
import com.braintribe.model.processing.meta.editor.ModelMetaDataEditor;
import com.braintribe.model.processing.session.api.collaboration.PersistenceInitializationContext;
import com.braintribe.wire.api.module.WireTerminalModule;

import tribefire.cortex.initializer.support.api.WiredInitializerContext;
import tribefire.cortex.initializer.support.impl.AbstractInitializer;
import tribefire.extension.okta.api.model.AuthorizedOktaRequest;
import tribefire.extension.okta.api.model.OktaRequest;
import tribefire.extension.okta.api.model.auth.GetOauthAccessToken;
import tribefire.extension.okta.api.model.user.GetGroup;
import tribefire.extension.okta.api.model.user.GetUser;
import tribefire.extension.okta.api.model.user.GetUserGroups;
import tribefire.extension.okta.api.model.user.ListAppGroups;
import tribefire.extension.okta.api.model.user.ListAppUsers;
import tribefire.extension.okta.api.model.user.ListGroupMembers;
import tribefire.extension.okta.api.model.user.ListGroups;
import tribefire.extension.okta.api.model.user.ListUsers;
import tribefire.extension.okta.initializer.wire.OktaInitializerWireModule;
import tribefire.extension.okta.initializer.wire.contract.ExistingInstancesContract;
import tribefire.extension.okta.initializer.wire.contract.OktaContract;
import tribefire.extension.okta.initializer.wire.contract.OktaMainContract;
import tribefire.extension.okta.initializer.wire.contract.RuntimePropertiesContract;

public class OktaInitializer extends AbstractInitializer<OktaMainContract> {

	@Override
	public WireTerminalModule<OktaMainContract> getInitializerWireModule() {
		return OktaInitializerWireModule.INSTANCE;
	}

	@Override
	public void initialize(PersistenceInitializationContext context, WiredInitializerContext<OktaMainContract> initializerContext,
			OktaMainContract mainContract) {

		applyModelMetaData(mainContract);
		applyApiModelMetaData(mainContract);

		OktaContract okta = mainContract.okta();
		RuntimePropertiesContract runtime = mainContract.runtime();

		if (runtime.ENABLE_OKTA_ACCESS()) {
			okta.oktaAccess();
		}

	}

	private void applyModelMetaData(OktaMainContract mainContract) {
		OktaContract okta = mainContract.okta();
		ExistingInstancesContract existingInstances = mainContract.existingInstances();
		ModelMetaDataEditor editor = mainContract.modelApi().newMetaDataEditor(existingInstances.oktaModel()).done();

		editor.onEntityType(GenericEntity.T).addPropertyMetaData(okta.unmodifiableIfDeclaredInOktaModel());
	}

	private void applyApiModelMetaData(OktaMainContract mainContract) {
		OktaContract okta = mainContract.okta();
		ExistingInstancesContract existingInstances = mainContract.existingInstances();

		ModelMetaDataEditor editor = mainContract.modelApi().newMetaDataEditor(existingInstances.oktaApiModel()).done();
		editor.onEntityType(OktaRequest.T).addMetaData(okta.oktaRequestProcessingMds());
		editor.onEntityType(OktaRequest.T).addMetaData(okta.httpDefaultFailureResponseType());
		editor.onEntityType(AuthorizedOktaRequest.T).addMetaData(okta.preProcessWithAuthorization());

		editor.onEntityType(AuthorizedOktaRequest.T).addPropertyMetaData(AuthorizedOktaRequest.authorization, okta.httpHeaderParamForAuthorization());

		editor.onEntityType(ListUsers.T).addMetaData(okta.httpGet(), okta.httpPathForListUsers());
		editor.onEntityType(ListUsers.T).addPropertyMetaData(okta.httpQueryParamAsIsIfDeclared());
		editor.onEntityType(ListUsers.T).addPropertyMetaData(ListUsers.query, okta.httpQueryParamForQuery());
		editor.onEntityType(GetUser.T).addMetaData(okta.httpGet(), okta.httpPathForGetUser());
		editor.onEntityType(GetUserGroups.T).addMetaData(okta.httpGet(), okta.httpPathForGetUserGroups());
		editor.onEntityType(ListGroups.T).addMetaData(okta.httpGet(), okta.httpPathForListGroups());
		editor.onEntityType(ListGroups.T).addPropertyMetaData(ListGroups.query, okta.httpQueryParamForQuery());
		editor.onEntityType(ListGroupMembers.T).addMetaData(okta.httpGet(), okta.httpPathForListGroupMembers());
		editor.onEntityType(GetGroup.T).addMetaData(okta.httpGet(), okta.httpPathForGetGroup());
		editor.onEntityType(ListAppUsers.T).addMetaData(okta.httpGet(), okta.httpPathForListAppUsers());
		editor.onEntityType(ListAppGroups.T).addMetaData(okta.httpGet(), okta.httpPathForListAppGroups());

		editor.onEntityType(GetOauthAccessToken.T).addMetaData(okta.httpPost(), okta.httpPathForGetOauthAccessToken(),
				okta.httpConsumesXWwwFormUrlEncoded());
		editor.onEntityType(GetOauthAccessToken.T).addPropertyMetaData(GetOauthAccessToken.grantType, okta.httpQueryParamForGrantType());
		editor.onEntityType(GetOauthAccessToken.T).addPropertyMetaData(GetOauthAccessToken.scope, okta.httpQueryParamForScope());
		editor.onEntityType(GetOauthAccessToken.T).addPropertyMetaData(GetOauthAccessToken.clientAssertionType,
				okta.httpQueryParamForClientAssertionType());
		editor.onEntityType(GetOauthAccessToken.T).addPropertyMetaData(GetOauthAccessToken.clientAssertion, okta.httpQueryParamForClientAssertion());

	}

}
