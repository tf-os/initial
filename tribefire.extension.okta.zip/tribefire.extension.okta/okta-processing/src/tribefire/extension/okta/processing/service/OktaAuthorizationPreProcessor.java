// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.okta.processing.service;

import com.braintribe.cfg.Configurable;
import com.braintribe.cfg.Required;
import com.braintribe.model.processing.service.api.ServicePreProcessor;
import com.braintribe.model.processing.service.api.ServiceRequestContext;

import tribefire.extension.okta.api.model.AuthorizedOktaRequest;
import tribefire.extension.okta.processing.auth.AuthenticationSupplier;
import tribrefire.extension.okta.common.OktaCommons;

public class OktaAuthorizationPreProcessor implements ServicePreProcessor<AuthorizedOktaRequest>, OktaCommons {

	private AuthenticationSupplier authenticationSupplier;

	// ***************************************************************************************************
	// Setters
	// ***************************************************************************************************

	@Required
	@Configurable
	public void setAuthenticationSupplier(AuthenticationSupplier authenticationSupplier) {
		this.authenticationSupplier = authenticationSupplier;
	}

	// ***************************************************************************************************
	// Processing
	// ***************************************************************************************************

	@Override
	public AuthorizedOktaRequest process(ServiceRequestContext requestContext, AuthorizedOktaRequest request) {
		String authorization = request.getAuthorization();
		if (authorization == null && authenticationSupplier != null) {
			authenticationSupplier.authorizeRequest(request);
		}
		return request;
	}

}
