# tribefire.extension.library

Usage notes: you need to configure repository access before using this extension. Please configure the following properties variables in tomcat/conf/tribefire.properties:

 - LIBRARY_ARTIFACTORY_URL: repository URL
 - LIBRARY_RAVENHURST_URL: Revenhurst URL for the repository
 - LIBRARY_REPOSITORY_USERNAME: user name for access
 - LIBRARY_REPOSITORY_PASSWORD: password for access
