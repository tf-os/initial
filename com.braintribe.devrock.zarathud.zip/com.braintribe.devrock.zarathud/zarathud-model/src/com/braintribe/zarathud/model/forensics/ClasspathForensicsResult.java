// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.zarathud.model.forensics;

import java.util.List;

import com.braintribe.model.generic.reflection.EntityType;
import com.braintribe.model.generic.reflection.EntityTypes;
import com.braintribe.zarathud.model.forensics.data.ClasspathDuplicate;

/**
 * the result of the forensics run on the classpath
 *
 */
public interface ClasspathForensicsResult extends ForensicsResult {
	
	EntityType<ClasspathForensicsResult> T = EntityTypes.T(ClasspathForensicsResult.class);
	
	String duplicates = "duplicates";
	
	/**
	 * @return - a {@link List} of {@link ClasspathDuplicate}
	 */
	List<ClasspathDuplicate> getDuplicates();
	void setDuplicates( List<ClasspathDuplicate> duplicates);
	
	
}
