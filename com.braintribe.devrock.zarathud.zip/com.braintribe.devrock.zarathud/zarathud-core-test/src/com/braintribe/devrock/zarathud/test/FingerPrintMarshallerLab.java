// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.devrock.zarathud.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import org.junit.Test;
import org.junit.experimental.categories.Category;

import com.braintribe.devrock.zed.forensics.fingerprint.persistence.FingerPrintMarshaller;
import com.braintribe.testing.category.KnownIssue;

/**
 * unfinished for now.. 
 *
 */
@Category(KnownIssue.class)

public class FingerPrintMarshallerLab {

	private File contents = new File( "res/fingerprints");
	
	public void test(File file) {
		FingerPrintMarshaller marshaller = new FingerPrintMarshaller();
		try (InputStream in = new FileInputStream(file)){
			
			Object obj = marshaller.unmarshall( in);
		}
		catch (Exception e) {
			
		}
	}
	
	@Test
	public void test() {
		File testFile = new File( contents, "simple.prints.txt");
		
	}
	

}
