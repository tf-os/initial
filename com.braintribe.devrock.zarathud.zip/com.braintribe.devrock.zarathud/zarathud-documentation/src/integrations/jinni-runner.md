# Running an analysis via Jinni

In Jinni (provided the integration is active), you can call Zed as well. In its basic configuration, it will show you the extracted data and the ratings of the forensic modules in Zed. The rated problems are written into a file, see [forensics](./forensics/forensics.md).

The request is as follows:

```
Jinni zed <condensed name of terminal> -v[taciturn/terse/verbose/garrulous] -o<output directory, default ‘.’>
```


examples:

```
jinni zed -t my-group:my-artifact#1.0 -v terse -o C:\dev\a -w

jinni zed -t tribefire.ext.demo:my-model#1.0 -o C\dev\a
```

## request
<table>
    <tr>
        <th>name</th><th>alias</th><th>description</th>
    </tr>
    <tr>
        <td>analyze-artifact</td><td>zed</td><td>run the standard analysis ZedRunnerContract</td>
    </tr>
</table>

<table>
    <tr>
        <th>parameter/th><th>alias/th><th>description/th><th>default</th>
    </tr>
    
<td>terminal</td><td>t</td><td>the condensed qualified name of the artifact to analyze</td>
</tr>
    <tr>
<td>outputDir</td><td>o</td><td>the directory to write the files to</td><td>. (current directory)</td>
</tr>
    <tr>
<td>write</td><td>w</td><td>whether to write out also all assemblies, i.e. extraction, forensic data </td><td>false</td>
</tr>
    <tr>
<td>verbosity</td><td>v</td><td>the different levels of verbosity</td><td>verbose</td>
</tr>
</table>

## verbosity choices 
There are different levels to the detailing of the output
<table>
	<tr>
		<th>verbosity</th><th>description</th>
	</tr>
	<tr>
		<td>taciturn</td><td>minimal output of extracted data, only problems are shown</td>
	</tr>
	<tr>
		<td>terse</td><td>compact output of extracted data</td>
	</tr>
	<tr>
		<td>verbose</td><td>output of all possibly relevant data  </td>
	</tr>
	<tr>
		<td>garrulous</td><td>output of all possible data</td>
	</tr>
</table>


## response
<table>
	<tr>
		<th>property</th><th>type</th><th>description</th><th>output</th>
    </tr>
    <tr>
        <td>fingerPrints</td><td>Resource</td><td>the ratings in expressive form ([see forensics](./forensics/forensics.md))</td><td>always</td>
    </tr>
	<tr>
        <td>extraction</td><td>Resource</td><td>the extraction data (as a generic assembly) in YAML format</td>
    </tr>
	<tr>
        <td>dependencyForensics</td><td>Resource</td><td>the data of the dependency forensics (as a generic assembly)</td><td>if requested - *w*</td>
    </tr>
	<tr>
        <td>classpathForensics</td><td>Resource</td><td>the data of the classpath forensics (as a generic assembly)</td><td>if requested - *w*</td>
    </tr>
	<tr>
        <td>modelForensics</td><td>Resource</td><td>the data of the model forensics (as a generic assembly) </td><td> if requested - *w*</td>
    </tr>
</table>
