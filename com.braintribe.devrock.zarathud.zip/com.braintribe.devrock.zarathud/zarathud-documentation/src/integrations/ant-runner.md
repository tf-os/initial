# Running an analysis via ant target

In ant (devrock-ant-tasks to be precise), you can call Zed's analysis via the integrated task.

```
ant zed -Dtarget=<condensed name of terminal> -Dmode=taciturn/terse/verbose/garrulous -DsolutionFile=<name of solutionfile> -DterminalJar=<jar of terminal> -DpomFile=<pom>  -DoutputDirectory=<directory> -Dwrite=<true|false>
```

this of course requires the following target in the build.xml file:

```xml
	<project ...>
		<target name="init">
			<bt:pom id="pom" file="pom.xml">
			<property name="versionedName" value="${pom.artifactId}-${pom.version}"/>
		</target>

		<target name="produce_cp" depends="init">
			<bt:dependencies pomFile="pom.xml" solutionListFile="solutions" addSelf="false">
				<pom refid="pom"/>
			</bt:dependencies>
		</target>

		<target name="analyze-artifact" depends="produce_cp" solutionListFile="solutions" terminalJar="${versionedName}.jar" >
			<pom refid="pom"/>
		</target>
	</project>
```

## parameters

follows a declarations of the parameters you can pass to the task

<table>
	<tr>
		<th>parameter</th><th>type</th><th>description</th><th>default</th>
	</tr>
	<tr>
		<td>pomFile</td><td>File</td><td>the pom to read</td><td>null</td>
	</tr>
	<tr>
		<td>solutionListFile</td><td>File</td><td>the full classpath of the terminal as produced by bt:dependencies</td>
	</tr>
	<tr>
		<td>terminalJar</td><td>File</td><td>the jar file of the terminal</td>
	</tr>
	<tr>
		<td>outputDirectory</td><td>File</td><td>where to write the files</td><td>. (current directory)</td>
	</tr>
	<tr>
		<td>write</td><td>boolean</td><td>whether to write all files</td><td>false</td>
	</tr>
	<tr>
		<td>verbosity</td><td>ConsoleOutputVerbosity</td><td>verbosity level</td><td>verbose</td>
	</tr>
</table>

>The  *pomFile* argument can be null if the *pom-entity* is attached as in the example above.

>The solution list file is required and must be named

>The terminal jar is required and must be named. 



## verbosity choices 
There are different levels to the detailing of the output
<table>
	<tr>
		<th>verbosity</th><th>description</th>
	</tr>
	<tr>
		<td>taciturn</td><td>minimal output of extracted data, only problems are shown</td>
	</tr>
	<tr>
		<td>terse</td><td>compact output of extracted data</td>
	</tr>
	<tr>
		<td>verbose</td><td>output of all possibly relevant data  </td>
	</tr>
	<tr>
		<td>garrulous</td><td>output of all possible data</td>
	</tr>
</table>


