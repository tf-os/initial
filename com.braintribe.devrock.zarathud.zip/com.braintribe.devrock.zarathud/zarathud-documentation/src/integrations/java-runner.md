# Running an analysis via java

In order to run an analysis with Zed from Java code, all you need is to import Zed's wiring artifact and then get the runner from Wire:

the wiring artifact is
```
com.braintribe.devrock.zarathud:zarathud-wrirings#[1.0,1.1)
```

```java
public Pair<ForensicsRating, Map<FingerPrint, ForensicsRating>> test(String terminal) {
	WireContext<ZedRunnerContract> wireContext = Wire.context( ZedRunnerWireTerminalModule.INSTANCE);

	ResolvingRunnerContext rrc = ResolvingRunnerContext.T.create();
	rrc.setTerminal( terminal);
	rrc.setConsoleOutputVerbosity( com.braintribe.devrock.zarathud.model.context.ConsoleOutputVerbosity.verbose);

	ZedWireRunner zedWireRunner = wireContext.contract().resolvingRunner( rrc);

	return zedWireRunner.run();
}

```

The pair returned contains the overall rating (the worst rating of all [forensics](./../forensics/forensics.md)) as first value and a Map of the fingerprint (see [forensics](./../forensics/forensics.md))) with its associated rating.
