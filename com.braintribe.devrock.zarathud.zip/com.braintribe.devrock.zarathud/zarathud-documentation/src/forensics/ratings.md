#Ratings


<table>
	<tr>
		<th>code</th>
		<th>description</th>
	</tr>
	<tr>
		<td>OK</td><td>nothing to report</td>
	</tr>
	<tr>
		<td>INFO</td><td>some issue to report, but nothing to worry absolutely</td>
		</tr>
	<tr>	
		<td>WARN</td><td>while not a direct problem, you should know about it</td>
		</tr>
	<tr>
		<td>ERROR</td><td>a big, fat fail</td>
		</tr>
</table>

There is a basic rating that is intrinsic to Z - see [forensics](./forensics.md). But there are ways to overload this standard settings.

1. via code
2. via custom Ratings
3. via pull request Ratings


