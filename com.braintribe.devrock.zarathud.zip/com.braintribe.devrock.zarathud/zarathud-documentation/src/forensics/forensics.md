# Forensics

Forensics in Z are modules that analyze what the [extraction](./../extraction.md) has delivered.

All forensic modules use the extracted data as input and - while also providing modelled data - retrieve all problems found. These problems are expressed as [finger prints](./fingerprint.md) that identify the issue and address of where the issue was detected.

Common to all forensics is that they rate issues. There are 4 different ratings

<table>
	<tr>
		<th>code</th>
		<th>description</th>
	</tr>
	<tr>
		<td>**OK**</td><td>nothing to report</td>
	</tr>
	<tr>
		<td>**INFO**</td><td>some issue to report, but nothing to worry absolutely</td>
		</tr>
	<tr>	
		<td>**WARN**</td><td>while not a direct problem, you should know about it</td>
		</tr>
	<tr>
		<td>**ERROR**</td><td>a big, fat fail</td>
		</tr>
</table>


You can influence the ratings of course, but there are standard (default) ratings that Zed applies if not overridden. See about [rating](./ratings.md).

## classpath forensics
Checks for duplicate classes in the classpath, i.e. finds classes with an identical name (package and type name) in separate artifacts in the classpath. Finds not only the presence, but also where they are referenced from.

The following issues may be raised by the classpath forensics:

<table>
	<tr>
		<th>code</th><th>description</th><th>default rating</th>
	</tr>
	<tr>
	<td>ShadowingClassesinClasspath</td><td>duplicate classes in the classpath</td><td>WARN</td>
	</tr>
</table>

>Note : duplicate classes in classpath can be a problem if they are just named the same but contain different code, for instance, it could be of different version. As a class is loaded only once into the JVM, the wrong class may be loaded and thus lead to a runtime problem when accessed.

## dependency forensics
Checks the dependencies of an artifact, i.e. finds all missing (dependencies transitively inherited from the dependency tree, yet not declared as first-level dependencies) and excess (dependencies declared as first-level dependencies, yet not referenced by the terminal) dependencies. While determining the references of classes in the terminal, it also respects 'forward declarations'.

<table>
	<tr>
		<th>code</th><th>description</th><th>default rating</th>
	</tr>
	<tr>
		<td>MissingDependencyDeclarations</td><td>some transitively acquired dependencies are used without declaration</td><td>WARN</td
	</tr>
	<tr>
		<td>ExcessDependencyDeclarations</td><td>some dependencies are declared, but never used directly</td><td>INFO</td>
	</tr>
	<tr>
		<td>ForwardDeclarations</td><td>forward declarations were detected</td><td>OK</td>
	</tr>
</table>

You can influence what Zed considers to be a missing or excessive dependency by adding markers into the pom of some artifacts.


>Missing Dependencies: while not a problem on the compile or runtime side, this poses a problem if an automatic process accesses the dependency list as the terminal was touched - for what ever reason and with what action whatsoever - and it actual direct dependencies are to be touched as well. If dependencies are not properly declared as direct dependencies, they are not detected as such and will lead to untouched artifacts.


>Excess Dependencies : again, not a problem on the compile or runtime side, this also poses a problem if an automatic process accesses the dependency list as the terminal was touched - for what ever reason and with what action whatsoever - and it actual direct dependencies are to be touched as well. Dependencies listed as direct dependencies would be touched (and perhaps their dependencies as well) which leads to unnecessarily touched artifacts.


>ForwardDeclarations : this is not an issue per se, and therefore it's only an INFO. Basically, forward declarations actually 'mask' a dependency. Z needs to understand forward declarations and hence can and does show them.

<table>
	<tr>
		<th>processing instruction</th><th>description</th>
	</tr>
	<tr>
		<td>aggregator</td><td>this dependency leads to an aggregator</td>
	</tr>
	<tr>
		<td>aggregate</td><td>this dependency leads to an aggregate (which is a dependency of an aggregator)</td>
	</tr>
</table>

>Aggregators are artifacts that in itself do not add anything to the terminal, in other words contain no classes on their own. Such a dependency would be considered excess. If you do not want this, a dependency to such an aggregator artifact needs to be tagged as such.


## module forensics
At its current state, the module forensics is just a listing of what the terminal requires to be declared as input, and what the dependencies in turn need to expose as exports - both on the package level.

While zed tries to understand any type reference in the terminal, there are some types it doesn't see at all - thinking of transient types (putting resulting types into a another function, as it's not  really clear how ASM handles such type references. If ASM (or rather the Java compiler) does list them in the respective node-structure, they will be found.

At a later state, zed should also analyze the 'module-info' class, extract the declared data and then compare this data with the data collected - just as it does with the dependencies of the terminal.


## model forensics
Checks the validity of a model.

<table>
	<tr>
		<th>code</th><th>description</th><th>default rating</th>
	</tr>
	<tr>
		<td>MissingGetter</td><td>property without matching getter</td><td>ERROR</td>
	</tr>
	<tr>
		<td>MissingSetter</td><td>property without matching setter</td><td>ERROR</td>
	</tr>
	<tr>
		<td>TypeMismatch</td><td>setter / getter types do not match</td><td>ERROR</td>
	</tr>
	<tr>
		<td>InvalidTypes</td><td>invalid type for a property</td><td>ERROR</td>
	</tr>
	<tr>
		<td>NonConformMethods</td><td>unallowed methods found</td><td>ERROR</td>
	</tr>
	<tr>
		<td>ConformMethods</td><td>allowed methods found</td><td>INFO</td>
	</tr>
	<tr>
		<td>CollectionInCollection</td><td>collection type has collection element type</td><td>ERROR</td>
	</tr>
	<tr>
		<td>PropertyNameLiteralMissing</td><td>property has no corresponding tag field</td><td>WARN</td>
	</tr>
	<tr>
		<td>PropertyNameLiteralTypeMismatch</td><td>property tag has wrong type</td><td>ERROR</td>	
	</tr>
	<tr>
		<td>PropertyNameLiteralMismatch</td><td>property tag's value doesn't match property</td><td>ERROR</td>
	</tr>
	<tr>
		<td>UnexpectedField</td><td>field found in model not related to property</td><td>INFO</td>
	</tr>
	<tr>
		<td>ContainsNoGenericEntities</td><td>no valid types found in a model</td><td>INFO</td>
	</tr>
	<tr>
		<td>InvalidEntitytypeDeclaration</td><td>entity type T literal is invalid</td><td>ERROR</td>
	</tr>
	<tr>
		<td>MissingEntitytypeDeclaration</td><td>entity type T literal is missing</td><td>ERROR</td>
	</tr>
	<tr>
		<td>ContainsNoDeclarationFile</td><td>no model-declaration.xml found</td><td>ERROR</td>
	</tr>
	<tr>
		<td>MissingTypeDeclarations</td><td>some existing types are not listed in the file</td><td>ERROR</td>
	</tr>
	<tr>
		<td>ExcessTypeDeclarations</td><td>types in file that do not exist</td><td>ERROR</td>
	</tr>
	<tr>
		<td>DeclarationFileInvalid</td><td>invalid format (xml error)</td><td>ERROR</td>
	</tr>
	<tr>
		<td>NonCanonic</td><td>model has Java parts that are not capable of transformation into other model forms</td><td>INFO</td>
	</tr>
</table>



>Non canonic : a model is canonic if it is isomorph, i.e. when it can be transposed across different valid formats, or simply said: if it survives a roundtrip via the modeler. Basically, it means that it must valid in the first place and may not contain conform methods.

>Conform / Non-Conform methods : Conform methods are methods that you can add to a model in its Java form (as Zed gets it to see) and that do not interfere with the getter/setter. For instance *default* and *static* methods are valid extensions, aka *conform* methods, as long as their names to not use the prefixes for getter/setter. Non-conform methods are all other methods that are not getter/setter.

>Unexpected field: **Why only info? add...**
