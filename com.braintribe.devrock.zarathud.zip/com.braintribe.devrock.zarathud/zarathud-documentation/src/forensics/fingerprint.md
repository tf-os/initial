# Finger prints

Finger prints in Z identify the place of a problem and the type of the problem. They can be expressed in an expressive form, but are of course modelled as well.

in the expressive form, they look like this:

```
group:com.braintribe.devrock/artifact:analysis-artifact-model/type:com.braintribe.model.artifact.analysis.AnalysisArtifact/property:Dependers/issue:PropertyNameLiteralMissing=info
```

Basically, the finger print can contain as many slots as are required. For the time being these exist:

<table>
	<tr>
		<th>key</th>
		<th>description</th>
	</tr>
	<tr>
		<td>group</td> 
		<td>the group id of the containing jar</td>
	</tr>
	<tr>
		<td>artifact</td> 
		<td>the artifact id of the containing jar</td>
	</tr>
	<tr>
		<td>package</td> 
		<td>the Java package</td>
	</tr>
	<tr>
		<td>type</td> 
		<td>the Java type or Generic Entity (of a model)</td>
	</tr>
	<tr>
		<td>property</td> <td>the property (of a model)</td>
	</tr>
	<tr>
		<td>method</td> <td>the Java method</td>
	</tr>
	<tr>
		<td>issue</td> <td>the issue - see [forensic codes](./forensics.md)</td>
	</tr>
</table>


Finger prints (as returned by the forensic modules) are associated with their rating.

a typical output looks like this

```
group:com.braintribe.gm/artifact:exchange-model/issue:ForwardDeclarations=ok
group:com.braintribe.gm/artifact:exchange-model/package:com.braintribe.model.exchange/type:ExchangePackage/property:Payloads/issue:PropertyNameLiteralMissing=info
group:com.braintribe.gm/artifact:exchange-model/package:com.braintribe.model.exchange/type:ExchangePayload/property:ExternalReferences/issue:PropertyNameLiteralMissing=info
group:com.braintribe.gm/artifact:exchange-model/package:com.braintribe.model.exchange/type:ExchangePackage/property:Exported/issue:PropertyNameLiteralMissing=info
group:com.braintribe.gm/artifact:exchange-model/package:com.braintribe.model.exchange/type:GenericExchangePayload/property:Assembly/issue:PropertyNameLiteralMissing=info
group:com.braintribe.gm/artifact:exchange-model/package:com.braintribe.model.exchange/type:ExchangePackage/property:ExportedBy/issue:PropertyNameLiteralMissing=info
```

the expressive parser will output the slots of a finger print from left to right with increasing detail until it specifies the exact location of the issue.
