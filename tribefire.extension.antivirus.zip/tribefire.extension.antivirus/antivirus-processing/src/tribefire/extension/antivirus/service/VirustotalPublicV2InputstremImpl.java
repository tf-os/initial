// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

//package tribefire.extension.antivirus.service;
//
//
//import java.io.IOException;
//import java.io.InputStream;
//import java.util.ArrayList;
//import java.util.List;
//
//import org.apache.http.entity.mime.content.InputStreamBody;
//import org.apache.http.entity.mime.content.StringBody;
//
//import com.kanishka.net.exception.RequestNotComplete;
//import com.kanishka.net.model.MultiPartEntity;
//import com.kanishka.net.model.RequestMethod;
//import com.kanishka.net.model.Response;
//import com.kanishka.virustotal.dto.ScanInfo;
//import com.kanishka.virustotal.exception.APIKeyNotFoundException;
//import com.kanishka.virustotal.exception.QuotaExceededException;
//import com.kanishka.virustotal.exception.UnauthorizedAccessException;
//import com.kanishka.virustotalv2.VirustotalPublicV2Impl;
//import com.kanishka.virustotalv2.VirustotalStatus;
//
//public class VirustotalPublicV2InputstremImpl extends VirustotalPublicV2Impl {
//	
////	private static final String API_KEY_FIELD = "apikey";
//
//    private static final String RESOURCE_FIELD = "resource";
//    
//    public VirustotalPublicV2Impl(String host, Integer port) throws APIKeyNotFoundException {
//        initialize();
//        httpRequestObject = new BasicHTTPRequestImpl(new InetSocketAddress(host, port));
//    }
//
//	public VirustotalPublicV2InputstremImpl() throws APIKeyNotFoundException {
//		super();
//	}
//	
//	public ScanInfo scanFile(InputStream inputStream, String fileName, String vt_apikey) throws
//    IOException, UnauthorizedAccessException,
//    QuotaExceededException {
//		Response responseWrapper = new Response();
//    ScanInfo scanInfo = new ScanInfo();
//
//    InputStreamBody inputStreamBody = new InputStreamBody(inputStream, "application/octet-stream", fileName != null ? fileName : "file");
//    MultiPartEntity file = new MultiPartEntity("file", inputStreamBody);
//    MultiPartEntity apikey = new MultiPartEntity("apikey",
//            new StringBody(vt_apikey));
//    List<MultiPartEntity> multiParts = new ArrayList<MultiPartEntity>();
//    multiParts.add(file);
//    multiParts.add(apikey);
//    Integer statusCode = -1;
//    try {
//        responseWrapper = httpRequestObject.request(URI_VT2_FILE_SCAN,
//                null, null, RequestMethod.GET, multiParts);
//        statusCode = responseWrapper.getStatus();
//    } catch (RequestNotComplete e) {
//        statusCode = e.getHttpStatus().getStatusCode();
//        if (statusCode == VirustotalStatus.FORBIDDEN) {
//            //fobidden
//            throw new UnauthorizedAccessException(ERR_MSG_INVALID_API_KEY,
//                    e);
//        }
//    }
//    if (statusCode == VirustotalStatus.SUCCESSFUL) {
//        //valid response
//        String serviceResponse = responseWrapper.getResponse();
//        scanInfo = gsonProcessor.fromJson(serviceResponse, ScanInfo.class);
//    } else if (statusCode == VirustotalStatus.API_LIMIT_EXCEEDED) {
//        //limit exceeded
//        throw new QuotaExceededException(ERR_MSG_EXCEED_MAX_REQ_PM);
//    }
//    return scanInfo;
//}
//
//}
