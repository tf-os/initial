// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package tribefire.extension.antivirus.service.connector.virustotal;
//package tribefire.extension.antivirus.service.expert.virustotal;
//
//import org.apache.http.entity.mime.content.ContentBody;
//
//public class ContentPart {
//	
//	private String name;
//    private ContentBody content;
//    
//    public ContentPart(String name, ContentBody content) {
//    	this.name = name;
//    	this.content = content;
//    }
//    
//	public String getName() {
//		return name;
//	}
//	public void setName(String name) {
//		this.name = name;
//	}
//	public ContentBody getContent() {
//		return content;
//	}
//	public void setContent(ContentBody content) {
//		this.content = content;
//	}
//}
