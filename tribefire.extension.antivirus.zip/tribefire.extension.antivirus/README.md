# tribefire.extension.antivirus

jinni.sh setup-local-tomcat-platform --setupDependency tribefire.extension.antivirus:antivirus-setup#1.0 --installationPath /opt/tf-setups/antivirus --debugProject tribefire.extension.antivirus:antivirus-debug : options --verbose