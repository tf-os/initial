
1. In Control Center, go to Custom Accesses and click New. 
2. Select **accessType** and configure it as follows:
    Name | Value | Description
    ------|-------|------------
3. Click **Apply**, then **Commit**.
4. Right-click your new access and select **Deploy**.