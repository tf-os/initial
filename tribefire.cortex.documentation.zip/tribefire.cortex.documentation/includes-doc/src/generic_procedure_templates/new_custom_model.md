1. In Control Center, navigate to the **Custom Models** entry point, and click **New**. 
2. Create a new model with the following properties:
	Name | Group Id | Version | Dependencies
	------|----------|--------|--------------

1. Using Modeler, create a new **entity** entity and add the following properties:
    Property | Value
    ---------|--------
> For information on using Modeler, see Using Modeler. 
3. Commit your changes.