## Using Access Control

Every entity instance whose entity type extends `HasAcl` has an `acl` property where you can assign (also with GME) instances of ACL.