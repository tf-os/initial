For information on how to install tribefire, see  [Quick Installation](asset://tribefire.cortex.documentation:development-environment-doc/quick_installation_devops.md).
