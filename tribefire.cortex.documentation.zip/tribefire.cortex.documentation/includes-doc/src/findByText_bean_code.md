```java
@Managed
public FindByTextProcessor findByTextProcessor() {
    FindByTextProcessor bean = new FindByTextProcessor();
    return bean;
}
```