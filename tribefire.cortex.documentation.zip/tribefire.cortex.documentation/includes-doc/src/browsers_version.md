Internet Explorer 10 or higher
Chrome 30 or higher
Safari 6.1.1 or higher
Firefox 25 or higher