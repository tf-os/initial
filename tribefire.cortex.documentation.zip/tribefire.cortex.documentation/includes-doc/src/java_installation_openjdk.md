1. Navigate to <https://openjdk.java.net/install/index.html>, download, and install the OpenJDK [](asset://tribefire.cortex.documentation:includes-doc/java_openjdk_version.md?INCLUDE)
 package.
2. Make sure that the `JAVA_HOME` and the `PATH` system environment variables are set to the root (directory which contains the `bin` folder) directory of your Java installation. You can check it by opening a command prompt and running the `javac -version` command.
