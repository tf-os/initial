# Quick Installation

A quick local installation lets you start developing with tribefire in no time.

[](asset://tribefire.cortex.documentation:includes-doc/quick_installation_include.md?INCLUDE)