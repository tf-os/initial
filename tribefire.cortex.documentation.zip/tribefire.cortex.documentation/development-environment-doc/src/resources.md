# Resources

[](asset://tribefire.cortex.documentation:includes-doc/resources.md?INCLUDE)

> For more information about the installation, see [Quick Installation](asset://tribefire.cortex.documentation:development-environment-doc/quick_installation_devops.md).