# Using Control Center

Get to know how to use Control Center.

## General

Control Center and Explorer are two main UI clients used in tribefire, allowing you to configure your instance of tribefire and browse your data.

For more information, see [Control Center](asset://tribefire.cortex.documentation:concepts-doc/features/ui-clients/control_center.md) and [Explorer](asset://tribefire.cortex.documentation:concepts-doc/features/ui-clients/explorer.md).

## Using Control Center and Explorer
<iframe width="560" height="315" src="https://www.youtube.com/embed/Yi8REfgU0OY" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
