Open the Control Center:

In the right upper corner of the _tribefire-control-center_ click on the cogwheel and choose the item _Switch to > Platform Setup_.
This will open the access where you can manage assets.
