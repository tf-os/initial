# TRIBEFIRE DOCUMENTATION

Tribefire is a platform that integrates, translates, and normalizes any kind of data to make it executable, extensible and expressive.