# Accessing Control Center

The Control Center, like all other tribefire components, is deployed as a webapp to a running instance of tribefire.

## General

To load the Control Center, you load the client by entering the address of the machine hosting tribefire followed by `tribefire-control-center`.

For example,if tribefire is running on your local machine, you access it by typing: `http://localhost:8080/tribefire-control-center`.

The client is then loaded and a login screen displayed, where you can then login to Control Center using the login `cortex` and password `cortex`.

<iframe width="560" height="315" src="https://www.youtube.com/embed/nUB3Kk-R7TI" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
