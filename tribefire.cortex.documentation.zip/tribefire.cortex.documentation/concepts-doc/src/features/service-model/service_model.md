# Service Model

## General
Like any object in tribefire, services are also modeled. Because of this, the same principles which are applied to models that define data can be applied to models that define services. This leads to a microservices-like approach as each service is provided using a model and its own API. Even though they are separate from each other, a service model usually depends on the business model.

>For more information on models, see [Models](../models/models.md) and [Models-in-details](../models/models_in_detail.md).

## Service and Business Models Separation

[](asset://tribefire.cortex.documentation:includes-doc/service_model_include.md?INCLUDE)


## What's Next?

For information on best practices for creating service models, see [Creating a Service Model - Best Practices](asset://tribefire.cortex.documentation:concepts-doc/features/service-model/creating_a_service_model_best_practices.md)

