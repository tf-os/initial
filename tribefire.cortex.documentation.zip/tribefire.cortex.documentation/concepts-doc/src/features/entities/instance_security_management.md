# Instance Level Security Management

You can control the access to specific instances of entities in tribefire using the efficient instance level security functionality.

## General

There are several variants of instance-level security in tribefire:

* Efficient Instance Level Security (EILS)
* Efficient Transitive Instance Level Security (ETILS)

They all offer similar functionality, the only difference is that while EILS provides simple grant or deny permissions to a particular instance, ETILS inherits permissions from sub-nodes.

A good example of instance-level security is a folder structure, where you configure access for each folder individually. In tribefire context, the word **efficient** refers to a concrete implementation with a simple model allowing efficient checking of these settings. Technically speaking, we limit the possibilities of what can be configured, so that the checks can be done using efficient queries.

The word **transitive** means that security settings for one instance depend on settings of other instances. For example, a folder might inherit such settings from all the files it contains.

## Type vs. Instance-level Security

In general, there are two different levels of security in tribefire - type and instance.

* Type-level security places restrictions on all the instances of a certain entity type.
* Instance-level security places restrictions on individual entity instances of entity types. You can configure instance-level security on every entity in tribefire. For type-level security, we recommend that you use the Visible or Hidden metadata.

> See [Visible or Hidden](asset://tribefire.cortex.documentation:concepts-doc/metadata/prompt/visible.md) for more information.

## Prerequisites to Instance Level Security

The following are the prerequisites to enabling instance-level security:

* Each entity type you wish to control instances of must be a subtype of `HasEfficientAccessPolicies` or `HasEfficientTransitiveAccessPolicies`.
* The same entity type must have the metadata [Efficient Transitive Access Policies](asset://tribefire.cortex.documentation:concepts-doc/metadata/efficient_transitive_access_policies.md) defined.
* The roles or groups to be granted or denied the access to must be defined beforehand.

Once configured, you must restart your tribefire host.

## Available Policies

Your entity type must be a subtype of one of the security policy interfaces to enable instance-level security. There are several available policies:

Policy    | Description  
------- | -----------
`HasEfficientAccessPolicies`  | Adds the properties used to store the allowed and denied roles.
`HasEfficientTransitiveAccessPolicies`  | Adds the properties used to store the allowed and denied roles and adds the transitivity layer with which you can have security settings inherited from one instance to another.

## Property Inheritance

You already know that a given entity must be a subtype of the `HasEfficientTransitiveAccessPolicies` or `HasEfficientAccessPolicies` entity to support instance-level security. This adds the properties used for storing the allowed or denied roles, and this type is also recognized by the framework as one where security checks should be done.

Each entity with `HasEfficientAccessPolicies` or `HasEfficientTransitiveAccessPolicies` as a supertype, inherits the following properties:

Property    | Description  
------- | -----------
`grantedFor`  | Grants the access to an instance of an entity type for a specified group or role.
`deniedFor`  | Denies the access to an instance of an entity type for a specified group or role.

If your entity type is a subtype of `HasEfficientTransitiveAccessPolicies`, it also inherits the `effectiveGrantedFor` and `effectiveDeniedFor` properties, but they are not editable by the user. Those properties contain the aggregated information from all the nodes they should inherit the security information from.

Let's assume we have a folder called parent with 2 files inside, `file1` and `file2`. The properties are configured as follows:

Node    | grantedFor   | deniedFor
------- | ----------- | -----
`parent`  | <empty> | <empty>
`file1`  | role1 | <empty>
`file2` | role2 | <empty>

Assuming the `parent` folder inherits the settings from files it contains, the aggregated information is as follows:

Node    | effectiveGrantedFor   | effectiveDeniedFor
------- | ----------- | ------
`parent`  | role1, role2 | <empty>
`file1`  | role1 | <empty>
`file2` | role2 | <empty>

This means that user with either of the roles can access the `parent` folder, but `role1` is only able to access `file1` inside and `role2` is only able to access `file2`.

## Available Strategies

You must first enable the `EfficientTransitiveAccessPolicies` metadata on an entity type to use the instance-level security functionality. One of the options you must configure in that metadata is the `ilsStrategy` property.

> For more information, see [Efficient Transitive Access Policies](asset://tribefire.cortex.documentation:concepts-doc/metadata/efficient_transitive_access_policies.md)

## Transitivity

Making your entity type a subtype of `HasEfficientTransitiveAccessPolicies` allows you to set up inheritance of security settings from one instance to another. First however, you must configure the transitive behavior.

To configure the transitivity of the security policies, you must configure two paths from one entity type to another, one as outgoing and one as incoming. You have to do it for both entity types. To configure such a path, there is an entity metadata `com.braintribe.model.meta.data.security.IlsPath`. There are two types of that metadata:

* `IlsPropertyPath`
* `IlsInversePropertyPath`

You use those metadata depending on which side the owner of the relation is on.

 Let us consider an example. You have a `Document` entity with `Pages`, and `Page` has a property owner of type `Document`. If you want each page to inherit the policies from the owner `Document`, you must set up the metadata in the following way:

 Entity Type    | Metadata   | Metadata Properties
 ------- | ----------- | ------
 `Document`  | IlsInversePropertyPath | property: Page.owner <br/> direction:outgoing <br/> type: etils
 `Page`  | IlsPropertyPath | property: Page.owner <br/> direction: outgoing <br/> type: etils 

## Access Configuration with a `SecurityAspect`
In order for the above settings to take effect, you must assign the `SecurityAspect` to your access. For the purpose of updating the transitive policies, you also need to assign the `StateProcessingAspect`, containing the `EtilsAggregatingStateChangeProcessor`.

### Assigning the `SecurityAspect`

1. Open tribefire and go to the **Control Center**.
2. Open the access to be configured (use the left-hand navigation menu or the Quick Access search bar).
3. In `aspectConfiguration`, click **Assign**. The `AspectConfiguration` query opens.
4. Select the default `AspectConfiguration` from Types. The configuration view opens, where you can add new aspects.
5. Select **Add**, then add the `Default Security Aspect` from the **Values** menu.
6. Commit your changes.
7. Redeploy your asset.

### Assigning the `StateProcessingAspect`

1. Open tribefire and go to the **Control Center**.
2. Open the access to be configured (use the left-hand navigation menu or the Quick Access search bar).
3. In `aspectConfiguration`, click **Assign**. The `AspectConfiguration` query opens.
4. Select the default `AspectConfiguration` from Types. The configuration view opens, where you can add new aspects.
5. Select **Add**, then add the `StateProcessingAspect` from the **Values** menu.
6. Commit your changes.
7. Redeploy your asset.