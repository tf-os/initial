# Available Connection Pools

[](asset://tribefire.cortex.documentation:includes-doc/connection_pools.md?INCLUDE) 

> For more information, see [Creating Registry Bound Deployables](asset://tribefire.cortex.documentation:tutorials-doc/configuration/creating_registry_bound_deployables.md). 