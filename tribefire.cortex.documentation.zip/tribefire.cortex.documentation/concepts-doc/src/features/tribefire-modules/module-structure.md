# Tribefire module structure

TODO describe the meaning of the files inside a TF module project