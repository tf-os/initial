[](asset://tribefire.extension.hibernate:hibernate-doc/hibernate-mapping/embedded.md?INCLUDE)
