[](asset://tribefire.extension.hibernate:hibernate-doc/hibernate-mapping/entity_level.md?INCLUDE)
