[](asset://tribefire.extension.hibernate:hibernate-doc/hibernate-mapping/property_level.md?INCLUDE)
