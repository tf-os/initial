# SimplifiedAssignment

This metadata allows you to configure whether a simplified UI is used when assigning a property where this metadata is configured in.

Metadata Property Name  | Type Signature  
------- | -----------
`SimplifiedAssignment` | `com.braintribe.model.meta.data.prompt.SimplifiedAssignment`

## General

If the SimplifiedAssignment metadata is configured, then a simplified assignment UI is used.
