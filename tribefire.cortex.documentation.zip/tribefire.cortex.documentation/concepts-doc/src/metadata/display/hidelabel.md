# HideLabel

This metadata property allows you to configure the whether the name of a property within the details view will be hidden.


Metadata Property Name  | Type Signature  
------- | -----------
`HideLabel` | `com.braintribe.model.meta.data.display.HideLabel`

## General

You can configure the visibility of a property name by creating or not an instance of `HideLabel`, and setting it to de desired property.
