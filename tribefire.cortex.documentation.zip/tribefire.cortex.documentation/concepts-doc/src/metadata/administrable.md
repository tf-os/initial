# Administrable

[](asset://tribefire.cortex.documentation:includes-doc/administrable_general.md?INCLUDE)

> For more information, see [Access Control List](asset://tribefire.cortex.documentation:concepts-doc/features/access_control.md).

[](asset://tribefire.cortex.documentation:includes-doc/administrable_general_section.md?INCLUDE)


> Note that configuring this MD on any sub-type of `HasAcl` has no effect, the MD is only resolved on `HasAcl` level. For more information, see [Using Access Control](asset://tribefire.cortex.documentation:tutorials-doc/control-center/using_access_control.md).
