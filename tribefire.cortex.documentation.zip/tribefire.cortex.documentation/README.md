# tribefire.cortex.documentation
This repository contains documentation assets which do not belong to a specific group, but serve as general or unifying documentation assets.
