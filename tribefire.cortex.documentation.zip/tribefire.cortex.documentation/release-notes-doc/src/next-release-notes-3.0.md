# Next Release Notes - tribefire 3.0

This document serves as the foundation for the release notes of the next major tribefire release, i.e. tribefire `3.0`.
It's used to collect information about new features, changes & improvements, fixes and updates.

## New Features

## Changes & Improvements

## Fixes

## Updates