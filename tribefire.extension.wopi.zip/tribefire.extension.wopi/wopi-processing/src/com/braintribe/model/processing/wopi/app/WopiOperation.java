// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.model.processing.wopi.app;

/**
 * 
 * Exposed operations
 */
public enum WopiOperation {
	// PutRelativeFile
	PUT_RELATIVE,
	// Lock
	LOCK,
	// Unlock
	UNLOCK,
	// RefreshLock
	REFRESH_LOCK,
	// DeleteFile
	DELETE,
	// PutFile
	PUT,
	// GetLock
	GET_LOCK,

	// ???
	COBALT,
	READ_SECURE_STORE,
	GET_RESTRICTED_LINK,
	REVOKE_RESTRICTED_LINK,
}
