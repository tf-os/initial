// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.codec.dom.plain;

import java.util.HashSet;
import java.util.Set;

public class DomSetCodec<T> extends DomCollectionCodec<T, Set<T>> {

	public DomSetCodec() {
		super("set", null);
	}
	
	public DomSetCodec(String tagName) {
		super(tagName);
	}
	
	public DomSetCodec(String parentTagName, String tagName) {
		super(parentTagName, tagName);
	}
	
	@Override
	protected Set<T> createCollection() {
		return new HashSet<T>();
	}
	
	@Override
	@SuppressWarnings({ "rawtypes" })
	public Class<Set<T>> getValueClass() {
		return (Class)Set.class;
	}
}
