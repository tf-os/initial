// This library is free software; you can redistribute it and/or modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.
// 
// This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License along with this library; See http://www.gnu.org/licenses/.

package com.braintribe.codec.string;

import com.braintribe.codec.Codec;
import com.braintribe.codec.CodecException;

public class PassThroughCodec<T> implements Codec<T, T> {
	private Class<T> valueClass;
	
	public PassThroughCodec(Class<T> valueClass) {
		this.valueClass = valueClass;
	}
	
	@Override
	public T decode(T encodedValue) throws CodecException {
		return encodedValue;
	}
	
	@Override
	public T encode(T value) throws CodecException {
		return value;
	}
	
	@Override
	public Class<T> getValueClass() {
		return valueClass;
	}
}
