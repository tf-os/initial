# tribefire.extension.hikari
Hikari JDBC connection pool
