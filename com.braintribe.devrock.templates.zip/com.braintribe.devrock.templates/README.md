# com.braintribe.devrock.templates

Provides the ArtifactTemplateProcessor that will handle CreateArtifact requests of various types. 

The purpose of the processor is to generate new file-system artifacts based on templates. 

Dependencies for additional CreateArtifact requests can be generated via dependencies.groovy script files. 

The CreateArtifacts requests serves as an important extension for jinni. 