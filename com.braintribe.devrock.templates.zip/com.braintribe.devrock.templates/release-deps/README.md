# Release Dependencies
This artifact is used to list the artifacts that should be included in a release.
This is done via dependencies, i.e. all artifacts this artifact depends on (directly or transitively) will be included.

When adding or removing a template, do not forget to update this artifact's dependencies.
