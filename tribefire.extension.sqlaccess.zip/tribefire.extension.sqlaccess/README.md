# SQL Access

THIS IS NOT IMPLEMENTED, JUST SOME PRELIMINARY CODE OF QUESTIONABLE VALUE

That being said, the idea was to have an `SQL`-backed `IncrementalAccess` which supports all possible models, unlike `HibernateAccess`, which can only map certain type of models, but has e.g. problems with too general property types (`GenericEntity` or even `Object`) or complicated dependency hierarchies.

